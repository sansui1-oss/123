# iPhone 移植工程：尚未编译验证

这份文件夹是修改后的完整源码，不是可直接安装的 IPA。基于上游提交 c2357f3f88f5fe633f87a0874c85df6e437761e2。

已添加 Flutter 3.47.7 官方模板的 iOS 工程、iOS 15 最低版本、照片添加与 Face ID 权限说明、Keychain 配置、本地媒体连接例外，并开放已有视频、相册和应用锁插件的 iOS 入口。

## 没有 Mac：用 GitHub 编译

1. 在自己的 GitHub 账号建立仓库，将此目录内容上传。必须保留 `.github/workflows/ios-ipa.yml`，它是隐藏目录里的构建文件。
2. 进入仓库的 Actions 页面，启用工作流。
3. 选择 **iOS unsigned IPA → Run workflow**。
4. 成功后，在该次任务底部 Artifacts 下载 **HentaiPark-iOS-unsigned**；解压得到 `HentaiPark-unsigned.ipa`。
5. 使用自己的证书或可信的侧载工具签名后安装。未签名 IPA 不能直接安装；不要向他人提供 Apple ID 密码或签名私钥。

GitHub 运行需要你的账号操作。此包没有上传到你的账号，也没有代替你运行过上述构建。不保证首次编译通过；失败时请提供失败步骤的报错，以便继续修复。

## 有 Mac

安装 Flutter 3.47.7、Xcode 与 CocoaPods，然后在源码目录执行：

```bash
flutter config --no-enable-swift-package-manager
flutter pub get
flutter build ios --release --no-codesign
python3 tools/ios/package_ipa.py
```

输出 `test/distribution/HentaiPark-unsigned.ipa`。也可以打开 `ios/Runner.xcworkspace`，设置自己的签名 Team 后连接 iPhone 调试。

## 当前验证与限制

已检查 iOS XML/plist、模板变量、Git 差异空白；打包脚本的 Payload 路径、可执行权限保留、模拟器包拒绝检查通过。打包测试使用夹具，不是实际 IPA。

未完成 Flutter 静态检查、依赖解析、Xcode 编译、签名安装和 iPhone 实机验证。Linux 没有 Xcode，且 Flutter 初始化在访问云元数据地址时被自动审批拦截，因此未继续运行。没有通过改变网络路径绕过拦截。

安卓后台下载服务、防截屏、音量键翻页、HLS 转 MP4、原生触摸验证和游戏原生桥未移植。iOS Cookie/WebView 登录、站点验证、JS 运行时、媒体格式、书库和备份恢复均需实机验收；部分源可能无法使用。当前不宣称全部原版功能可用。
