import 'dart:async';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/app_log.dart';
import '../../core/localization.dart';
import '../../core/models.dart';
import '../../core/tag_blocklist.dart';
import '../../core/voice.dart';
import '../../engine/desktop_shutdown.dart';
import '../../engine/home_cache.dart';
import '../../engine/source_manager.dart';
import '../../library/downloads.dart';
import '../../library/library.dart';
import '../comments/comments_page.dart';
import '../game/game_resources.dart';
import '../game/online_game_page.dart';
import '../kit/adaptive_sheet.dart';
import '../nav.dart';
import '../theme.dart';
import '../voice/voice_attachment_page.dart';
import '../voice/voice_directory_page.dart';
import '../widgets/common.dart';
import '../widgets/content_translation.dart';
import '../widgets/error_view.dart';
import '../widgets/expandable_description.dart';
import '../widgets/paged_grid.dart';
import '../widgets/related_works.dart';
import 'detail_action_bar.dart';
import 'detail_actions.dart';
import 'detail_download.dart';
import 'detail_header.dart';
import 'detail_sections.dart';
import 'detail_tags.dart';
import 'detail_versions.dart';
import 'single_page_view.dart';
import 'thumbnail_grid.dart';

/// A work's page: header, one primary action, then description, tags, chapters, previews and
/// related works. Layout pieces live in detail_header.dart and detail_sections.dart.

class DetailPage extends StatefulWidget {
  const DetailPage({
    super.key,
    required this.source,
    required this.id,
    this.preview,
    this.coverHeroTag,
    this.sourceManager,
  });
  final String source;
  final String id;
  final WorkItem? preview;
  final Object? coverHeroTag;
  final SourceManager? sourceManager;

  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> with RouteAware {
  WorkDetail? _detail;
  Object? _error;
  bool _showBlocked = false;
  bool _reversed = false;
  bool _refreshing = false;
  final Set<String> _selected = {};
  final _resourcesKey = GlobalKey();
  CancelToken? _request;
  StreamSubscription<String>? _authentication;
  PageRoute<dynamic>? _route;
  bool _refreshOnReturn = false;
  SourceManager get _manager => widget.sourceManager ?? SourceManager.instance;

  SourceManifest? get _m => _manager.manifest(widget.source);
  String get _uid => '${widget.source}:${widget.id}';
  bool get _isVideo => _item.mediaKind != null
      ? _item.mediaKind!.isPlayable
      : _m?.isPlayable ?? DownloadManager.instance.task(_uid)?.isVideo ?? false;
  bool get _opensExternally => _isVideo && _m?.opensExternally == true;
  bool get _webVideo => _isVideo && _m?.usesWebVideo == true;
  bool get _isLive => _m?.isLive == true;
  bool get _voiceArchive =>
      _m?.can('voiceDirectory') == true && _detail?.json['voiceRoot'] is Map;
  bool get _isGame =>
      _item.mediaKind != null ? _item.isGame : _m?.isGame == true;
  bool get _onlineGame =>
      _m?.category == SourceCategory.onlineGame ||
      _item.json['contentDomain'] == SourceCategory.onlineGame.name;

  @override
  void initState() {
    super.initState();
    PendingDisposals.instance.add(
      Library.instance.loadChapters(_uid).then<void>((_) {}),
    );
    _load();
    _authentication = _manager.authenticationChanges.listen((source) {
      if (source != widget.source || !mounted) return;
      if (_route?.isCurrent == false) {
        _refreshOnReturn = true;
        return;
      }
      _detail = null;
      unawaited(_load());
    });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final route = ModalRoute.of(context);
    if (identical(route, _route)) return;
    Nav.routeObserver.unsubscribe(this);
    _route = route is PageRoute<dynamic> ? route : null;
    if (_route case final route?) Nav.routeObserver.subscribe(this, route);
  }

  @override
  void didPushNext() {
    if (!_refreshing) return;
    _request?.cancel('detail route covered');
    _refreshing = false;
    _refreshOnReturn = true;
  }

  @override
  void didPopNext() {
    if (!_refreshOnReturn) return;
    _refreshOnReturn = false;
    unawaited(_load());
  }

  /// Keeps the stored chapter list (and with it read state and library updates) in step with the site.
  Future<void> _syncChapters(WorkDetail d) async {
    if (_opensExternally || _webVideo || _isGame || _isLive || _voiceArchive) {
      return;
    }
    final chapters = _isVideo
        ? d.videoEpisodes
        : d.chapters ?? [Chapter(chapterKeyOf(d.singleChapterId), tr('全本'))];
    try {
      await Library.instance.syncChapters(
        d.toItem(),
        chapters,
        oneShot: _isVideo ? !d.hasVideoEpisodes : d.chapters == null,
        complete: d.chaptersComplete,
      );
    } catch (e) {
      AppLog.error(e, event: 'chapter_sync', site: widget.source);
    }
  }

  Future<void> _load() async {
    _request?.cancel('detail reloaded');
    final request = _request = CancelToken();
    setState(() {
      _error = null;
      _refreshing = true;
    });
    if (widget.source == localSource) {
      // Imported files: everything is on disk, there is no site to ask.
      final d = DownloadManager.instance.offlineDetail(
        widget.source,
        widget.id,
      );
      setState(
        () => d == null
            ? _error = SourceError('NOT_FOUND', '本地文件已被删除')
            : _detail = d,
      );
      _refreshing = false;
      if (d != null) {
        Library.instance.recordVisit(d.toItem());
        PendingDisposals.instance.add(_syncChapters(d));
      }
      return;
    }
    try {
      final d = await _manager.detail(
        widget.source,
        widget.id,
        preview: widget.preview,
        cancelToken: request,
        onCached: (cached) {
          if (mounted && identical(_request, request) && !request.isCancelled) {
            setState(() {
              _detail = cached;
            });
          }
        },
      );
      if (!mounted || request.isCancelled || !identical(_request, request)) {
        return;
      }
      setState(() {
        _detail = d;
        _refreshing = false;
      });
      Library.instance.recordVisit(d.toItem());
      PendingDisposals.instance.add(_syncChapters(d));
    } catch (e) {
      if (!mounted || request.isCancelled || !identical(_request, request)) {
        return;
      }
      _refreshing = false;
      if (HomeCache.invalidatesContent(e)) {
        _detail = null;
      }
      // Offline (or the site is down): fall back to the downloaded copy when there is one.
      final offline = DownloadManager.instance.offlineDetail(
        widget.source,
        widget.id,
      );
      if (offline != null) {
        setState(() {
          _detail = offline;
          _error = e;
        });
        context.toast(
          tr('无法连接{source}，已打开离线下载的内容', {'source': _m?.name ?? ''}),
        );
        return;
      }
      setState(() => _error = e);
    }
  }

  @override
  void dispose() {
    Nav.routeObserver.unsubscribe(this);
    _authentication?.cancel();
    _request?.cancel('detail page closed');
    super.dispose();
  }

  /// 只有一页图片时在详情中直接显示，不再经过章节与预览。
  bool get _singlePage {
    final d = _detail;
    return d != null &&
        _kind == DetailKind.reading &&
        d.pages == 1 &&
        (d.chapters == null || d.chapters!.length == 1);
  }

  DetailKind get _kind {
    if (_onlineGame) return DetailKind.onlineGame;
    if (_isGame) return DetailKind.game;
    if (_opensExternally) return DetailKind.external;
    if (_isVideo) return DetailKind.video;
    final novel =
        (_item.mediaKind == null && _m?.isNovel == true) ||
        DownloadManager.instance.task(_uid)?.isNovel == true ||
        _item.isNovel;
    return novel ? DetailKind.novel : DetailKind.reading;
  }

  WorkItem get _item =>
      _detail?.toItem() ??
      widget.preview ??
      WorkItem({'id': widget.id, 'title': widget.id}, widget.source);

  void _read({Chapter? chapter, int? page}) {
    final d = _detail;
    if (d == null) return;
    if (_opensExternally || _isGame) {
      _openOriginal();
      return;
    }
    if (_voiceArchive) {
      _openVoiceDirectory(d);
      return;
    }
    if (_isVideo) {
      Nav.openVideo(context, d, episodeId: chapter?.id);
      return;
    }
    if (d.hasNoChapters) {
      context.toast(tr('暂无章节'));
      return;
    }
    final history = Library.instance.historyOf(d.uid);
    chapter ??= d.chapterToOpen(history?.chapterId);
    final chapterId = chapter?.id ?? d.singleChapterId;
    final state = Library.instance.chapterState(d.uid, chapterId);
    final startPage =
        page ??
        (history?.chapterId == chapterId
            ? history!.page
            : state == null || state.read
            ? 0
            : state.lastPage);
    Nav.openReader(context, d, chapter: chapter, startPage: startPage);
  }

  void _continue() {
    if (_onlineGame) {
      final detail = _detail;
      if (detail != null) {
        Nav.push(context, OnlineGamePage(work: detail, manager: _manager));
      }
      return;
    }
    if (_isGame) {
      final target = _resourcesKey.currentContext;
      if (target != null) {
        Scrollable.ensureVisible(
          target,
          duration: Motion.of(context, Motion.medium),
        );
      } else if (_detail != null) {
        showAdaptiveSheet<void>(
          context: context,
          isScrollControlled: true,
          builder: (_) => SafeArea(
            child: FractionallySizedBox(
              heightFactor: .85,
              child: SingleChildScrollView(
                child: GameResources(work: _detail!),
              ),
            ),
          ),
        );
      }
      return;
    }
    final d = _detail;
    if (d == null) return;
    if (_opensExternally) {
      _openOriginal();
      return;
    }
    if (_voiceArchive) {
      final history = Library.instance.historyOf(d.uid);
      final saved = history == null
          ? null
          : WorkDetail(history.item.json, d.source);
      if (saved != null &&
          history?.chapterId != null &&
          saved.videoEpisodes.any((track) => track.id == history!.chapterId)) {
        Nav.openVideo(context, saved, episodeId: history!.chapterId);
      } else {
        _openVoiceDirectory(d);
      }
      return;
    }
    if (_isVideo) {
      Nav.openVideo(context, d);
      return;
    }
    _read();
  }

  void _openVoiceDirectory(WorkDetail work) {
    final raw = work.json['voiceRoot'];
    try {
      if (raw is! Map) throw const FormatException();
      final root = VoiceNode.fromJson(raw.cast<String, dynamic>());
      if (root.playable) {
        unawaited(Nav.openVideo(context, work));
        return;
      }
      if (root.kind != VoiceNodeKind.directory) {
        unawaited(
          Nav.push(
            context,
            VoiceAttachmentPage(
              work: work,
              node: root,
              sourceManager: _manager,
            ),
          ),
        );
        return;
      }
      unawaited(
        Nav.push(
          context,
          VoiceDirectoryPage(work: work, root: root, sourceManager: _manager),
        ),
      );
    } on FormatException {
      context.toast(tr('媒体数据无效'));
    }
  }

  @override
  Widget build(BuildContext context) {
    return TranslationPage(
      child: Scaffold(
        body: ListenableBuilder(
          listenable: Listenable.merge([
            Library.instance.work(_uid),
            DownloadManager.instance,
            TagBlocklist.changes,
          ]),
          builder: (context, _) {
            final rules = TagBlocklist.current();
            final blocked = _detail != null
                ? rules.matchDetail(_detail!)
                : [?rules.matchItem(_item)];
            final visibility = IconButton(
              tooltip: tr(_showBlocked ? '隐藏已屏蔽内容' : '显示已屏蔽内容'),
              icon: Icon(
                _showBlocked
                    ? Icons.visibility_outlined
                    : Icons.visibility_off_outlined,
              ),
              onPressed: () => setState(() => _showBlocked = !_showBlocked),
            );
            if (blocked.isNotEmpty && !_showBlocked) {
              return CustomScrollView(
                slivers: [
                  SliverAppBar(
                    pinned: true,
                    title: Text(tr('已屏蔽作品')),
                    actions: [visibility],
                  ),
                  SliverToBoxAdapter(
                    child: BlockedNotice(
                      tags: blocked,
                      onReveal: () => setState(() => _showBlocked = true),
                    ),
                  ),
                ],
              );
            }
            return CustomScrollView(
              slivers: [
                DetailHeader(
                  item: _item,
                  actions: [visibility],
                  detail: _detail,
                  manifest: _m,
                  coverHeroTag: widget.coverHeroTag,
                  overview: [
                    if (_refreshing && _detail != null)
                      const LoadingIndicator(),
                    if (_error != null)
                      SourceErrorView(
                        error: _error!,
                        source: widget.source,
                        onRetry: _load,
                        compact: true,
                      ),
                    DetailActionBar(
                      item: _item,
                      detail: _detail,
                      kind: _kind,
                      singlePage: _singlePage,
                      allowDownload: !_isLive,
                      onPrimary: _opensExternally && !_canOpenOriginal
                          ? null
                          : _continue,
                      onDownload: () => downloadWork(
                        context,
                        _detail,
                        _item,
                        isVideo: _isVideo,
                      ),
                      onMore: () => _more(context),
                    ),
                    if (_detail != null)
                      ..._overview(context, _detail!)
                    else if (_error == null)
                      DetailBodySkeleton(source: widget.source),
                  ],
                  body: [
                    if (_detail != null) ..._body(context, _detail!),
                    const SliverToBoxAdapter(child: SizedBox(height: Gap.xxl)),
                  ],
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Uri? get _originalUri {
    final uri = Uri.tryParse(_detail?.url ?? '');
    return uri != null &&
            (uri.scheme == 'https' || uri.scheme == 'http') &&
            uri.host.isNotEmpty &&
            uri.userInfo.isEmpty
        ? uri
        : null;
  }

  bool get _canOpenOriginal => _originalUri != null;

  Future<void> _openOriginal() async {
    final uri = _originalUri;
    if (uri == null) return;
    try {
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened && mounted) context.toast(tr('无法打开原站，请稍后重试'));
    } catch (_) {
      if (mounted) context.toast(tr('无法打开原站，请稍后重试'));
    }
  }

  Future<void> _more(BuildContext context) => showDetailMore(
    context,
    detail: _detail!,
    item: _item,
    onOpenOriginal: _canOpenOriginal ? _openOriginal : null,
  );

  int _unread(List<Chapter> chapters) => chapters
      .where((ch) => Library.instance.chapterState(_uid, ch.id)?.read != true)
      .length;

  void _toggleSelect(String id) {
    HapticFeedback.selectionClick();
    setState(
      () => _selected.contains(id) ? _selected.remove(id) : _selected.add(id),
    );
  }

  Widget _chapterHeader(BuildContext context, List<Chapter> chapters) {
    if (_selected.isNotEmpty) {
      void done() => setState(_selected.clear);
      return ChapterSelectionBar(
        count: _selected.length,
        isVideo: _isVideo,
        allowDownload: !_isLive,
        onClear: done,
        onSelectAll: () =>
            setState(() => _selected.addAll(chapters.map((c) => c.id))),
        onDownload: () async {
          if (DownloadManager.instance.hasRestoreFailure(_item.uid)) {
            context.toast(tr('下载记录恢复失败，请前往下载页处理'));
            return;
          }
          if (_m?.kind == MediaKind.voice) {
            for (final chapter in chapters.where(
              (c) => _selected.contains(c.id),
            )) {
              DownloadManager.instance.enqueueBundle(
                _item,
                node: {
                  'id': chapter.id,
                  'name': chapter.title,
                  'type':
                      (_detail!.json['voiceTrackKinds'] as Map?)?[chapter.id] ??
                      (_detail!.voiceMediaForm == VoiceMediaForm.videoOnly
                          ? 'video'
                          : 'audio'),
                  'subtitleIds': _detail!.voiceSubtitles[chapter.id] ?? [],
                },
              );
            }
            context.toast(tr('已加入下载队列'));
            done();
            return;
          }
          final selected = chapters
              .where((c) => _selected.contains(c.id))
              .toList();
          if (_isVideo) {
            await downloadEpisodes(context, _detail!, _item, selected);
            if (mounted) done();
            return;
          }
          DownloadManager.instance.enqueue(_item, selected);
          context.toast(tr('已加入下载队列'));
          done();
        },
        onMarkRead: (read) {
          Library.instance.markRead(_uid, _selected.toList(), read);
          done();
        },
        onMarkPreviousRead: _selected.length == 1
            ? () {
                final i = chapters.indexWhere((c) => c.id == _selected.first);
                Library.instance.markRead(
                  _uid,
                  chapters.take(i).map((c) => c.id).toList(),
                  true,
                );
                done();
              }
            : null,
      );
    }
    final unread = _unread(chapters);
    return SectionHeader(
      _isVideo
          ? tr('选集 · {count}', {'count': chapters.length})
          : tr('章节 · {count}{unread}', {
              'count': chapters.length,
              'unread': unread > 0 ? tr('（未读 {count}）', {'count': unread}) : '',
            }),
      padding: const EdgeInsets.symmetric(
        horizontal: Gap.page,
        vertical: Gap.m,
      ),
      trailing: ToolbarButton(
        onPressed: () => setState(() => _reversed = !_reversed),
        child: SelectionContainer.disabled(
          child: Text(_reversed ? tr('倒序') : tr('正序')),
        ),
      ),
    );
  }

  List<Widget> _overview(BuildContext context, WorkDetail d) {
    return [
      CommentsEntry(
        source: widget.source,
        workId: d.id,
        manager: _manager,
        count: d.comments,
        available: d.commentsAvailable,
        context: {'url': d.url},
      ),
      if (d.variants.isNotEmpty || d.workCode.isNotEmpty)
        DetailVersions(work: d, manifest: _m),
      if (d.description.isNotEmpty) ExpandableDescription(text: d.description),
      if (d.tagGroups.isNotEmpty ||
          d.authors.isNotEmpty ||
          d.uploader.isNotEmpty)
        TagSection(detail: d, source: widget.source),
    ];
  }

  List<Widget> _body(BuildContext context, WorkDetail d) {
    final isVideo = _isVideo;
    final chapters = _opensExternally || _webVideo || _isGame || _isLive
        ? null
        : isVideo && d.hasVideoEpisodes
        ? d.videoEpisodes
        : d.chapters;
    final ordered = chapters == null
        ? null
        : (_reversed ? chapters.reversed.toList() : chapters);
    final current = Library.instance.historyOf(d.uid)?.chapterId;
    final isNovel = _m?.isNovel == true || d.isNovel;
    if (_singlePage) {
      return [
        SliverToBoxAdapter(
          child: SinglePageView(
            key: ObjectKey(d),
            detail: d,
            onOpen: () => _read(),
          ),
        ),
        if (d.series.isNotEmpty)
          SliverToBoxAdapter(
            child: WorkRecommendations(title: tr('同系列'), items: d.series),
          ),
        if (d.related.isNotEmpty ||
            d.relatedSections.isNotEmpty ||
            _m?.can('related') == true)
          SliverToBoxAdapter(
            child: RelatedWorks(
              showBlocked: _showBlocked,
              key: ObjectKey(d),
              detail: d,
              sourceManager: _manager,
            ),
          ),
      ];
    }
    return [
      if (_isGame && !_onlineGame)
        SliverToBoxAdapter(
          child: GameResources(key: _resourcesKey, work: d),
        ),
      if (d.hasNoChapters && !isVideo && !_isGame && !_opensExternally)
        SliverToBoxAdapter(
          child: EmptyState(
            compact: true,
            icon: Icons.format_list_bulleted_rounded,
            title: tr('暂无章节'),
            message: tr('站点还没有列出章节，稍后再来看看。'),
            actions: [
              TextButton(
                onPressed: _load,
                child: SelectionContainer.disabled(child: Text(tr('刷新'))),
              ),
            ],
          ),
        ),
      if (ordered != null && ordered.isNotEmpty) ...[
        SliverToBoxAdapter(child: _chapterHeader(context, chapters!)),
        SliverList.separated(
          itemCount: ordered.length,
          separatorBuilder: (_, _) =>
              const Divider(indent: Gap.page, endIndent: Gap.page),
          itemBuilder: (context, i) {
            final ch = ordered[i];
            return ChapterRow(
              chapter: ch,
              uid: d.uid,
              isVideo: isVideo,
              isNovel: isNovel,
              current: current == ch.id,
              selected: _selected.contains(ch.id),
              onTap: () => _selected.isNotEmpty
                  ? _toggleSelect(ch.id)
                  : _read(chapter: ch),
              onLongPress: () => _toggleSelect(ch.id),
            );
          },
        ),
      ],
      if (!isVideo &&
          !_isGame &&
          (d.thumbnails.isNotEmpty || _m?.can('thumbnails') == true))
        SliverToBoxAdapter(
          child: ThumbnailSection(
            detail: d,
            onOpen: (page) => _read(page: page),
          ),
        ),
      if (d.series.isNotEmpty)
        SliverToBoxAdapter(
          child: WorkRecommendations(title: tr('同系列'), items: d.series),
        ),
      if (d.related.isNotEmpty ||
          d.relatedSections.isNotEmpty ||
          _m?.can('related') == true)
        SliverToBoxAdapter(
          child: RelatedWorks(
            showBlocked: _showBlocked,
            key: ObjectKey(d),
            detail: d,
            sourceManager: _manager,
          ),
        ),
    ];
  }
}
