/// Allows only WKWebView's initial in-memory document navigation. Once consumed
/// or loaded, every navigation is denied, including navigation to the same URL.
class RuntimeNavigationPolicy {
  RuntimeNavigationPolicy({required this.isIOS, required this.origin});

  final bool isIOS;
  final Uri origin;
  bool _consumed = false;

  void documentLoaded() => _consumed = true;

  bool allow(Uri? url, {required bool mainFrame, required bool hasGesture}) {
    if (!isIOS || _consumed || !mainFrame || hasGesture || url == null) {
      return false;
    }
    if (url != origin && url != Uri.parse('about:blank')) return false;
    _consumed = true;
    return true;
  }
}
