import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:path/path.dart' as p;

import '../core/app_log.dart';
import '../core/async_tasks.dart';
import '../core/models.dart';
import '../core/storage.dart';

class HomeCacheResult {
  const HomeCacheResult(this.data, {this.stale = false});
  final Map<String, dynamic> data;
  final bool stale;
}

/// 管理可重建的作品与访问地址缓存，与媒体文件、离线下载分开计量和清理。
class HomeCache {
  HomeCache({
    Directory? directory,
    DateTime Function()? clock,
    this.budget = 32 * 1024 * 1024,
  })
    // 保留可注入的公开 directory 参数，生产环境使用独立 AppPaths 目录。
    // ignore: prefer_initializing_formals
    : _directory = directory,
       _clock = clock ?? DateTime.now;
  static final instance = HomeCache();
  static const lifetime = Duration(minutes: 15);
  static bool invalidatesContent(Object error) =>
      error is SourceError &&
      {'LOGIN_REQUIRED', 'AUTH', 'NOT_FOUND'}.contains(error.code);
  final Directory? _directory;
  final DateTime Function() _clock;
  final int budget;
  final _disk = SerialExecutor();
  final _pending = <String, Future<HomeCacheResult>>{};
  final _refreshes = <String, int>{};
  int _requestSequence = 0;
  int _generation = 0;
  final _sourceGenerations = <String, int>{};
  Directory get directory =>
      _directory ?? Directory(p.join(AppPaths.cache.path, 'home_metadata'));

  static Object? _canonical(Object? value) {
    if (value is Map) {
      final keys = value.keys.map((k) => k.toString()).toList()..sort();
      return {for (final key in keys) key: _canonical(value[key])};
    }
    if (value is List) return value.map(_canonical).toList();
    return value;
  }

  Future<HomeCacheResult> request(
    List<Object?> identity,
    Future<Map<String, dynamic>> Function() load, {
    bool refresh = false,
    String requestGroup = 'foreground',
    bool Function(Map<String, dynamic>)? shouldCache,
    Map<String, dynamic> Function(Map<String, dynamic>)? serialize,
    void Function(Map<String, dynamic>)? onCached,
    String? source,
  }) {
    if (source != null && !RegExp(r'^[a-zA-Z0-9_-]+$').hasMatch(source)) {
      throw ArgumentError.value(source, 'source');
    }
    // 网络/会话原值只参与摘要，不进入文件名、正文或诊断日志。
    final key = sha256
        .convert(utf8.encode(jsonEncode(_canonical([source, ...identity]))))
        .toString();
    final generation = _generation;
    final sourceGeneration = _sourceGenerations[source] ?? 0;
    bool current() =>
        generation == _generation &&
        sourceGeneration == (_sourceGenerations[source] ?? 0);
    final pendingKey =
        '${directory.path}/$generation/$source/$sourceGeneration/$key/$refresh/$requestGroup/${onCached == null ? 0 : ++_requestSequence}';
    final existing = _pending[pendingKey];
    if (existing != null) return existing;
    final sequence = ++_requestSequence;
    return _pending[pendingKey] ??=
        _request(
          key,
          current,
          load,
          refresh,
          shouldCache,
          serialize,
          sequence,
          onCached,
          requestGroup == 'foreground' || refresh,
          source,
        ).whenComplete(() {
          _pending.remove(pendingKey);
          if (!_pending.keys.any((pending) => pending.contains('/$key/'))) {
            _refreshes.remove(key);
          }
        });
  }

  Future<HomeCacheResult> _request(
    String key,
    bool Function() current,
    Future<Map<String, dynamic>> Function() load,
    bool refresh,
    bool Function(Map<String, dynamic>)? shouldCache,
    Map<String, dynamic> Function(Map<String, dynamic>)? serialize,
    int sequence,
    void Function(Map<String, dynamic>)? onCached,
    bool foreground,
    String? source,
  ) async {
    final root = source == null
        ? directory
        : Directory(p.join(directory.path, source));
    final file = File(p.join(root.path, '$key.json'));
    final cached = await _disk.run(() async {
      try {
        if (!await file.exists()) return null;
        if (await file.length() > budget) {
          await file.delete();
          return null;
        }
        final entry = jsonDecode(await file.readAsString());
        if (entry is! Map ||
            entry['written'] is! int ||
            entry['written'] < -8640000000000000 ||
            entry['written'] > 8640000000000000 ||
            entry['data'] is! Map) {
          return null;
        }
        await file.setLastModified(_clock());
        return (
          written: DateTime.fromMillisecondsSinceEpoch(entry['written']),
          data: (entry['data'] as Map).cast<String, dynamic>(),
        );
      } on FileSystemException {
        return null;
      } on FormatException {
        return null;
      }
    });
    if (cached != null && current()) {
      AppLog.debug({
        'event': 'metadata_cache',
        'site': source,
        'outcome': 'success',
      });
      onCached?.call(cached.data);
    }
    if (onCached == null &&
        !refresh &&
        current() &&
        cached != null &&
        !_clock().isBefore(cached.written) &&
        _clock().difference(cached.written) < lifetime) {
      return HomeCacheResult(cached.data);
    }
    Map<String, dynamic> data;
    AppLog.debug({
      'event': 'metadata_refresh',
      'site': source,
      'outcome': 'started',
    });
    // 只读取已有缓存不会让正在进行的最新请求失去写入资格。
    if (foreground && sequence > (_refreshes[key] ?? 0)) {
      _refreshes[key] = sequence;
    } else {
      _refreshes.putIfAbsent(key, () => sequence);
    }
    try {
      data = await load();
    } on SourceError catch (error) {
      if (invalidatesContent(error)) {
        try {
          await _disk.run(() async {
            if (current() &&
                (_refreshes[key] ?? 0) == sequence &&
                await file.exists()) {
              await file.delete();
            }
          });
        } on FileSystemException {
          /* 不掩盖原始权限错误。 */
        }
      }
      if ({'NETWORK', 'TIMEOUT'}.contains(error.code) &&
          !refresh &&
          cached != null &&
          current()) {
        return HomeCacheResult(cached.data, stale: true);
      }
      rethrow;
    }
    if (shouldCache?.call(data) == false) return HomeCacheResult(data);
    final bytes = utf8.encode(
      jsonEncode({
        'written': _clock().millisecondsSinceEpoch,
        'data': serialize?.call(data) ?? data,
      }),
    );
    // 缓存写入失败不得使已成功的主页网络读取失败。
    try {
      await _disk.run(() async {
        if (!current() ||
            (_refreshes[key] ?? 0) != sequence ||
            bytes.length > budget) {
          return;
        }
        await root.create(recursive: true);
        await writeFileAtomic(
          file,
          bytes,
          canCommit: () => current() && (_refreshes[key] ?? 0) == sequence,
        );
        await _trim(directory);
      });
    } on FileSystemException {
      /* 可重建缓存，保留网络结果。 */
    }
    return HomeCacheResult(data);
  }

  Future<List<(File, FileStat)>> _files(Directory root) async {
    if (!await root.exists()) return [];
    final files = <(File, FileStat)>[];
    await for (final entity in root.list(recursive: true, followLinks: false)) {
      if (entity is! File || !entity.path.endsWith('.json')) continue;
      try {
        files.add((entity, await entity.stat()));
      } on FileSystemException {
        /* 并发清理。 */
      }
    }
    return files;
  }

  Future<void> _trim(Directory root) async {
    final files = await _files(root)
      ..sort((a, b) => a.$2.modified.compareTo(b.$2.modified));
    var bytes = files.fold(0, (sum, file) => sum + file.$2.size);
    for (final file in files) {
      if (bytes <= budget) break;
      await file.$1.delete();
      bytes -= file.$2.size;
    }
  }

  Future<int> size() => _disk.run(
    () async =>
        (await _files(directory))
            .fold<int>(0, (sum, file) => sum + file.$2.size),
  );

  Future<void> clear() {
    _generation++;
    final root = directory;
    return _disk.run(() async {
      if (await root.exists()) await root.delete(recursive: true);
    });
  }

  Future<void> clearSource(String source) {
    if (!RegExp(r'^[a-zA-Z0-9_-]+$').hasMatch(source)) {
      throw ArgumentError.value(source, 'source');
    }
    _sourceGenerations[source] = (_sourceGenerations[source] ?? 0) + 1;
    final root = Directory(p.join(directory.path, source));
    return _disk.run(() async {
      if (await root.exists()) await root.delete(recursive: true);
    });
  }
}
