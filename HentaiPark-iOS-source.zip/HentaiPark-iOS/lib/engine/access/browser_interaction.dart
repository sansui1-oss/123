import 'age_confirmation.dart';
import 'challenge.dart';
import 'host.dart';

/// 保留 closed shadow root 的引用，不改变网页请求的 shadow 模式。
/// Android 没有 CDP 接口，必须在节点创建前安装。
const challengeDocumentScript = r'''
(() => {
  if (window !== window.top || window.__parkChallengeInput) return;
  const roots = new WeakMap();
  const attach = Element.prototype.attachShadow;
  Element.prototype.attachShadow = function(...args) {
    const root = Reflect.apply(attach, this, args);
    roots.set(this, root);
    return root;
  };
  const token = [...crypto.getRandomValues(new Uint32Array(4))].join('-');
  let attempts = 0, lastInput = -Infinity;
  const trusted = value => {
    try {
      const u = new URL(value);
      return u.protocol === 'https:' && u.hostname === 'challenges.cloudflare.com' &&
        !u.port && !u.username && !u.password;
    } catch (_) { return false; }
  };
  const snapshot = (expected, take = false) => {
    const attemptToken = token + '-' + attempts;
    if (attempts >= 3 || performance.now() - lastInput < 8000 ||
        (expected && expected !== attemptToken) || document.readyState !== 'complete') return null;
    const frames = [];
    let budget = 10000;
    const visit = (root, depth = 0) => {
      if (depth > 32) { budget = 0; return; }
      for (const el of root.querySelectorAll('*')) {
        if (--budget <= 0) return;
        if (el.tagName === 'IFRAME' && trusted(el.src)) frames.push(el);
        const shadow = roots.get(el) || el.shadowRoot;
        if (shadow) visit(shadow, depth + 1);
      }
    };
    visit(document);
    if (budget <= 0 || frames.length !== 1) return null;
    const frame = frames[0], r = frame.getBoundingClientRect();
    for (let node = frame; node; node = node.parentElement || node.getRootNode().host) {
      const style = getComputedStyle(node);
      if (style.visibility !== 'visible' || style.display === 'none' || Number(style.opacity) === 0) return null;
    }
    if (r.width < 290 || r.width > 310 || r.height < 60 || r.height > 85 ||
        r.x < 0 || r.y < 0 || r.right > innerWidth || r.bottom > innerHeight) return null;
    const x = r.x + 28, y = r.y + r.height / 2;
    let root = document, hit;
    for (let depth = 0; depth <= 32; depth++) {
      hit = root.elementFromPoint(x, y);
      if (!hit) return null;
      const shadow = roots.get(hit) || hit.shadowRoot;
      if (!shadow) break;
      root = shadow;
    }
    if (hit !== frame) return null;
    if (take) { attempts++; lastInput = performance.now(); }
    return {token: attemptToken, url: location.href, frame: frame.src, x, y,
      width: innerWidth, height: innerHeight};
  };
  Object.defineProperty(window, '__parkChallengeInput', {
    value: Object.freeze({snapshot}), configurable: false, writable: false
  });
})();
''';

/// 同一段脚本内检查页面与年龄门，避免先读状态再点击时操作了新文档。
Future<Map?> inspectAccessDocument(
  BrowserInteractionHost controller, {
  required String url,
  required AgeConfirmationConfig? confirmation,
  required bool confirmAdult,
}) async {
  final result = await controller
      .javascript(
        body: r'''
    // Cloudflare 验证页会用 history.replaceState 追加 __cf_chl_* 参数；忽略它们，
    // 否则验证页永远无法被识别，只能等到启动超时。
    const clean = value => {
      try {
        const address = new URL(value);
        for (const key of [...address.searchParams.keys()]) {
          if (key.startsWith('__cf_chl_')) address.searchParams.delete(key);
        }
        return address.href;
      } catch (_) { return value; }
    };
    if (clean(location.href) !== clean(url) || document.readyState !== 'complete') return null;
    const visible = el => el && el.getClientRects().length > 0 &&
      getComputedStyle(el).display !== 'none' && getComputedStyle(el).visibility !== 'hidden';
    const gates = gateSelector ? [...document.querySelectorAll(gateSelector)].filter(visible) : [];
    const ready = !readySelector || !!document.querySelector(readySelector);
    let clicked = false;
    if (confirmAdult && gates.length && clickSelector) {
      // 问答仅接受站点声明且整组精确匹配的题目；未知题目不猜答案、不提交。
      const rows = questionnaire
        ? [...document.querySelectorAll(questionnaire.rowSelector)].filter(visible) : [];
      if (rows.length) {
        const normalize = text => String(text || '').replace(/\s+/g, ' ').trim();
        const answers = new Map(questionnaire.answers.map(row =>
          [normalize(row.question), normalize(row.answer)]));
        const choices = [], groups = new Set();
        let form = null, valid = rows.length <= 32;
        for (const row of rows) {
          const inputs = [...row.querySelectorAll('input[type="radio"]')].filter(input =>
            visible(input) && !input.disabled && gates.some(gate => gate.contains(input)));
          if (!inputs.length) { valid = false; break; }
          const first = inputs[0], range = document.createRange();
          range.setStart(row, 0); range.setEndBefore(first);
          const answer = answers.get(normalize(range.toString()));
          const matched = inputs.filter(input => normalize(input.nextSibling?.textContent) === answer);
          if (!answer || matched.length !== 1 || !first.form ||
              (form && form !== first.form) || !first.name || groups.has(first.name) ||
              inputs.some(input => input.name !== first.name || input.form !== first.form)) {
            valid = false; break;
          }
          form = first.form; groups.add(first.name); choices.push(matched[0]);
        }
        const buttons = [...document.querySelectorAll(questionnaire.submitSelector)].filter(el =>
          visible(el) && !el.disabled && el.form === form && gates.some(gate => gate.contains(el)));
        if (valid && choices.length === rows.length && buttons.length === 1) {
          choices.forEach(input => { if (!input.checked) input.click(); });
          if (choices.every(input => input.checked)) {
            setTimeout(() => { if (buttons[0].isConnected) buttons[0].click(); }, 0); clicked = true;
          }
        }
      } else if (birthDate) {
      // 只有本地成年确认有效，且整组日期控件、确认按钮属于同一年龄门时才填写。
      // 日期是应用统一值，站点不能指定日期或填入用户真实生日。
      const spec = birthDate.dateSelector
        ? [[birthDate.dateSelector, '1999-12-31', 'date']]
        : [[birthDate.yearSelector, '1999', 'part'],
           [birthDate.monthSelector, '12', 'part'],
           [birthDate.daySelector, '31', 'part']];
      const find = selector => [...document.querySelectorAll(selector)].filter(el =>
        visible(el) && !el.disabled && gates.some(gate => gate.contains(el)));
      const matches = spec.map(([selector]) => find(selector));
      const fields = matches.map(items => items[0]);
      const checks = checkSelector ? find(checkSelector).filter(el =>
        el instanceof HTMLInputElement && el.type === 'checkbox') : [];
      const buttons = find(clickSelector).filter(el => el.getAttribute('aria-disabled') !== 'true');
      const form = fields[0]?.form;
      let valid = gates.length === 1 && matches.every(items => items.length === 1) &&
        new Set(fields).size === fields.length && !!form && buttons.length === 1 &&
        buttons[0].form === form && fields.every(el => el.form === form) &&
        (!checkSelector || (checks.length === 1 && checks[0].form === form));
      if (valid) {
        try {
          const action = new URL(form.action, location.href);
          valid = action.protocol === 'https:' && action.origin === location.origin &&
            !action.username && !action.password && ['get', 'post'].includes(form.method.toLowerCase());
        } catch (_) { valid = false; }
      }
      if (valid) {
        valid = spec.every(([_, value, kind], i) => {
          const field = fields[i];
          if (kind === 'date') return field instanceof HTMLInputElement && field.type === 'date';
          if (field instanceof HTMLSelectElement) return [...field.options].some(option =>
            option.value === value && !option.disabled && !option.closest('optgroup')?.disabled);
          return field instanceof HTMLInputElement && ['text', 'number', 'tel'].includes(field.type);
        });
      }
      if (valid) {
        const allowed = new Set([...fields, ...checks]);
        valid = [...form.querySelectorAll('input,select,textarea')].every(el =>
          el.disabled || allowed.has(el) || (el instanceof HTMLInputElement &&
            ['hidden', 'submit', 'button'].includes(el.type)));
      }
      if (valid) {
        const previous = fields.map(field => field.value);
        const wasChecked = checks[0]?.checked;
        fields.forEach((field, i) => {
          field.value = spec[i][1];
          field.dispatchEvent(new Event('input', {bubbles: true}));
          field.dispatchEvent(new Event('change', {bubbles: true}));
        });
        if (checks.length && !checks[0].checked) checks[0].click();
        valid = fields.every((field, i) => field.isConnected && field.value === spec[i][1]) &&
          (!checks.length || checks[0].checked) && form.isConnected && form.checkValidity();
        if (valid) {
          setTimeout(() => {
            if (form.isConnected && buttons[0].isConnected && clean(location.href) === clean(url)) buttons[0].click();
          }, 0);
          clicked = true;
        } else {
          fields.forEach((field, i) => { field.value = previous[i]; });
          if (checks.length && checks[0].checked !== wasChecked) checks[0].click();
        }
      }
      } else {
      // 标准年龄门只操作唯一的复选框和提交按钮，不填写账号等其他表单。
      let checked = !checkSelector;
      if (checkSelector) {
        const checks = [...document.querySelectorAll(checkSelector)].filter(el =>
          visible(el) && el instanceof HTMLInputElement && el.type === 'checkbox' &&
          !el.disabled && gates.some(gate => gate.contains(el)));
        if (checks.length === 1) {
          if (!checks[0].checked) checks[0].click();
          checked = checks[0].checked;
        }
      }
      const buttons = [...document.querySelectorAll(clickSelector)].filter(el =>
        visible(el) && !el.disabled && el.getAttribute('aria-disabled') !== 'true' &&
        gates.some(gate => gate.contains(el)));
      if (checked && buttons.length === 1) {
        setTimeout(() => { if (buttons[0].isConnected) buttons[0].click(); }, 0); clicked = true;
      }
      }
    }
    return {url, title: document.title, html: document.documentElement.outerHTML.slice(0, 4194304),
      gate: gates.length > 0, content: ready, clicked};
    ''',
        arguments: {
          'url': url,
          'gateSelector': confirmation?.gateSelector ?? '',
          'readySelector': confirmation?.readySelector ?? '',
          'clickSelector': confirmation?.clickSelector ?? '',
          'checkSelector': confirmation?.checkSelector ?? '',
          'confirmAdult': confirmAdult,
          'questionnaire': confirmation?.questionnaire,
          'birthDate': confirmation?.birthDate,
        },
      )
      .timeout(const Duration(seconds: 5), onTimeout: () => null);
  // 观察请求可能在页面跳转时丢失回调；返回等待状态，由访问会话总期限
  // 判定失败，不能把单次观察超时当成整次网络请求失败。
  return result is Map ? result : null;
}

/// 仅操作当前文档上唯一的可信标准框；输入成功不代表服务端放行。
Future<bool> clickCloudflareCheckbox(
  BrowserInteractionHost controller, {
  required bool Function() current,
  String? documentUrl,
}) async {
  if (!current() || documentUrl == null) return false;
  if (controller.supportsNativeInput) {
    final token = await controller
        .evaluate('window.__parkChallengeInput?.snapshot()?.token ?? null')
        .timeout(const Duration(seconds: 5));
    if (!current() || token is! String || token.isEmpty) return false;
    final clicked = await controller
        .nativeClick(url: documentUrl, token: token)
        .timeout(const Duration(seconds: 5));
    return current() && clicked;
  }
  if (!controller.supportsCdp) return false;
  Future<dynamic> call(String method, Map<String, dynamic> parameters) =>
      controller.cdp(method, parameters).timeout(const Duration(seconds: 5));
  final tree = await call('DOM.getDocument', {'depth': -1, 'pierce': true});
  final ids = <int>[];
  var budget = 20000;
  void visit(dynamic node, [int depth = 0]) {
    if (node is! Map || --budget < 0 || depth > 64) return;
    if (node['nodeName'] == 'IFRAME') {
      final attrs = node['attributes'] as List? ?? const [];
      for (var i = 0; i + 1 < attrs.length; i += 2) {
        final uri = attrs[i] == 'src' ? Uri.tryParse('${attrs[i + 1]}') : null;
        if (uri != null &&
            challengeFrameNavigationAllowed(uri, isForMainFrame: false) &&
            node['nodeId'] is num) {
          ids.add((node['nodeId'] as num).toInt());
        }
      }
    }
    for (final key in ['children', 'shadowRoots']) {
      for (final child in node[key] as List? ?? const []) {
        visit(child, depth + 1);
      }
    }
    visit(node['contentDocument'], depth + 1);
  }

  visit(tree is Map ? tree['root'] : null);
  if (!current() || budget < 0 || ids.length != 1) return false;
  final resolved = await call('DOM.resolveNode', {'nodeId': ids.single});
  final object = resolved is Map ? resolved['object'] : null;
  final objectId = object is Map ? object['objectId'] : null;
  if (!current() || objectId is! String) return false;
  // 由目标节点所属文档进行命中检查，穿过 closed shadow root；旧文档的
  // objectId 不能在新页面取得成功。移动后再次检查，避免 hover 弹层误点击。
  Future<Map?> check(bool take) async {
    if (!current()) return null;
    final result = await call('Runtime.callFunctionOn', {
      'objectId': objectId,
      'functionDeclaration': r'''function(expected, take) {
        if (!this.isConnected || this.ownerDocument !== document || location.href !== expected ||
            document.readyState !== 'complete') return null;
        const state = window.__parkCdpInputState;
        if (state && (state.attempts >= 3 || performance.now() - state.lastInput < 8000)) return null;
        const u = new URL(this.src);
        if (u.protocol !== 'https:' || u.hostname !== 'challenges.cloudflare.com' ||
            u.port || u.username || u.password) return null;
        const r = this.getBoundingClientRect(), x = r.x + 28, y = r.y + r.height / 2;
        for (let node = this; node; node = node.parentElement || node.getRootNode().host) {
          const style = getComputedStyle(node);
          if (style.visibility !== 'visible' || style.display === 'none' || Number(style.opacity) === 0) return null;
        }
        if (r.width < 290 || r.width > 310 || r.height < 60 || r.height > 85 ||
            r.x < 0 || r.y < 0 || r.right > innerWidth || r.bottom > innerHeight) return null;
        let node = this;
        for (let depth = 0; depth < 64; depth++) {
          const style = getComputedStyle(node);
          if (style.visibility !== 'visible' || style.display === 'none' || Number(style.opacity) === 0) return null;
          const root = node.getRootNode();
          if (!root.elementFromPoint || root.elementFromPoint(x,y) !== node) return null;
          if (root === document) {
            if (take) {
              if (!state) Object.defineProperty(window, '__parkCdpInputState', {value:{attempts:0,lastInput:0}});
              window.__parkCdpInputState.attempts++;
              window.__parkCdpInputState.lastInput = performance.now();
            }
            return {x,y,width:innerWidth,height:innerHeight};
          }
          node = root.host;
          if (!node) return null;
        }
        return null;
      }''',
      'arguments': [
        {'value': documentUrl},
        {'value': take},
      ],
      'returnByValue': true,
    });
    final remote = result is Map ? result['result'] : null;
    final value = remote is Map ? remote['value'] : null;
    return current() && value is Map ? value : null;
  }

  var pressed = false;
  Map? point;
  try {
    point = await check(false);
    if (point == null) return false;
    await call('Input.dispatchMouseEvent', {
      'type': 'mouseMoved',
      'x': point['x'],
      'y': point['y'],
      'buttons': 0,
    });
    final finalPoint = await check(true);
    if (finalPoint == null ||
        !current() ||
        [
          'x',
          'y',
          'width',
          'height',
        ].any((key) => point![key] != finalPoint[key])) {
      return false;
    }
    pressed = true;
    await call('Input.dispatchMouseEvent', {
      'type': 'mousePressed',
      'x': point['x'],
      'y': point['y'],
      'button': 'left',
      'clickCount': 1,
      'buttons': 1,
    });
    final active = current();
    await call('Input.dispatchMouseEvent', {
      'type': 'mouseReleased',
      'x': active ? point['x'] : -1,
      'y': active ? point['y'] : -1,
      'button': 'left',
      'clickCount': 1,
      'buttons': 0,
    });
    pressed = false;
    return current();
  } finally {
    if (pressed) {
      try {
        await call('Input.dispatchMouseEvent', {
          'type': 'mouseReleased',
          'x': -1,
          'y': -1,
          'button': 'left',
          'buttons': 0,
        });
      } catch (_) {}
    }
    try {
      await call('Runtime.releaseObject', {'objectId': objectId});
    } catch (_) {}
  }
}

/// 单个可见文档的自动验证状态；导航后必须重新创建，禁止重放网页请求。
enum BrowserAccessState { waiting, ready, failed }

class BrowserAccessDocument {
  bool _ageClicked = false;
  int _challengeAttempts = 0;
  DateTime? _challengeAttemptAt;
  bool _sawAccessGate = false;

  Future<BrowserAccessState> inspect(
    BrowserInteractionHost controller, {
    required String url,
    required bool Function() current,
    required AgeConfirmationConfig? confirmation,
    required bool confirmAdult,
    int? httpError,
  }) async {
    if (!current()) return BrowserAccessState.waiting;
    final snapshot = await inspectAccessDocument(
      controller,
      url: url,
      confirmation: confirmation,
      confirmAdult: confirmAdult && !_ageClicked,
    );
    if (!current() || snapshot == null || snapshot['url'] != url) {
      return BrowserAccessState.waiting;
    }
    if (snapshot['clicked'] == true) _ageClicked = true;
    final challenge = hasChallengeMarkers(
      snapshot['html']?.toString() ?? '',
      title: snapshot['title']?.toString() ?? '',
    );
    if (challenge || snapshot['gate'] == true) _sawAccessGate = true;
    // 触摸被 WebView 接受不等于验证框已就绪或服务端已放行。
    // 重试受当前文档、重新命中检查、次数和间隔共同约束。
    if (challenge &&
        _challengeAttempts < 3 &&
        (_challengeAttemptAt == null ||
            DateTime.now().difference(_challengeAttemptAt!) >=
                const Duration(seconds: 8))) {
      final clicked = await clickCloudflareCheckbox(
        controller,
        current: current,
        documentUrl: url,
      );
      if (!current()) return BrowserAccessState.waiting;
      if (clicked) {
        _challengeAttempts++;
        _challengeAttemptAt = DateTime.now();
      }
    }
    if (!current() ||
        challenge ||
        snapshot['gate'] == true ||
        (confirmation != null && snapshot['content'] != true)) {
      return BrowserAccessState.waiting;
    }
    return httpError != null && !_sawAccessGate
        ? BrowserAccessState.failed
        : BrowserAccessState.ready;
  }
}
