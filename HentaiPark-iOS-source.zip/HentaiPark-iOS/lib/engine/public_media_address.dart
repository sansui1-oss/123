import 'dart:io';

import '../core/models.dart';

/// Reject non-public addresses, including IPv4-mapped IPv6; direct connections use checked IPs.
/// 198.18.0.0/15 and 2001:2::/48 are accepted: reserved for benchmarking, never assigned
/// to LAN hosts, and Clash, sing-box and Surge map domains into it in fake-ip
/// mode. The system VPN routes those connections by domain, and TLS still
/// verifies the original host name.
bool isPublicMediaAddress(InternetAddress address) {
  final bytes = address.rawAddress;
  if (bytes.length == 16) {
    if (bytes[0] == 0x20 &&
        bytes[1] == 1 &&
        bytes[2] == 0 &&
        bytes[3] == 2 &&
        bytes[4] == 0 &&
        bytes[5] == 0) {
      return true;
    }
    if (bytes.take(10).every((b) => b == 0) &&
        bytes[10] == 255 &&
        bytes[11] == 255) {
      return isPublicMediaAddress(
        InternetAddress.fromRawAddress(bytes.sublist(12)),
      );
    }
    // Only global unicast, excluding documentation and special-purpose prefixes.
    return (bytes[0] & 0xe0) == 0x20 &&
        !(bytes[0] == 0x20 && bytes[1] == 1 && bytes[2] < 2) &&
        !(bytes[0] == 0x20 &&
            bytes[1] == 1 &&
            bytes[2] == 0x0d &&
            bytes[3] == 0xb8) &&
        !(bytes[0] == 0x20 && bytes[1] == 2);
  }
  final a = bytes[0], b = bytes[1];
  return a != 0 &&
      a != 10 &&
      a != 127 &&
      a < 224 &&
      !(a == 100 && b >= 64 && b <= 127) &&
      !(a == 169 && b == 254) &&
      !(a == 172 && b >= 16 && b <= 31) &&
      !(a == 192 && (b == 168 || b == 0 || b == 2)) &&
      !(a == 198 && b == 51 && bytes[2] == 100) &&
      !(a == 203 && b == 0 && bytes[2] == 113);
}

Future<List<InternetAddress>> publicMediaAddresses(String host) async {
  final addresses = await InternetAddress.lookup(host)
      .timeout(const Duration(seconds: 15));
  if (addresses.isEmpty ||
      addresses.any((address) => !isPublicMediaAddress(address))) {
    throw SourceError(
      'CONFIG',
      '媒体主机解析到了内网或保留地址，已拒绝连接',
      diagnostics: {
        'host': host,
        'transport': 'native',
        'reason': 'PRIVATE_ADDRESS',
      },
    );
  }
  return addresses;
}
