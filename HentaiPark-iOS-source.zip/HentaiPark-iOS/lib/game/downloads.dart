import 'dart:async';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:dio/io.dart';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;

import '../core/models.dart';
import '../core/settings.dart';
import '../core/storage.dart';
import '../engine/background_downloads.dart';
import '../engine/cancellation.dart';
import '../engine/media_transport.dart';
import '../engine/network_client.dart';
import '../engine/source_manager.dart';
import '../library/download_scheduler.dart';
import '../library/downloads.dart' show DownloadManager, DownloadStatus;

class GameDownloadTask {
  static String fileName(String value) {
    var name = p
        .basename(value.replaceAll('\\', '/'))
        .replaceAll(RegExp(r'[<>:"/\\|?*\x00-\x1f]'), '_')
        .trim()
        .replaceAll(RegExp(r'[. ]+$'), '');
    if (name.isEmpty || name == '.' || name == '..') name = 'game.bin';
    if (RegExp(
      r'^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)',
      caseSensitive: false,
    ).hasMatch(name)) {
      name = '_$name';
    }
    if (name.length > 180) {
      String prefix(String text, int limit) {
        if (text.length <= limit) return text;
        final last = text.codeUnitAt(limit - 1);
        return text.substring(
          0,
          last >= 0xd800 && last <= 0xdbff ? limit - 1 : limit,
        );
      }

      name = '${prefix(name, 150)}${prefix(p.extension(name), 20)}';
    }
    return name;
  }

  GameDownloadTask._({
    required this.item,
    required this.resourceId,
    required this.channelId,
    required this.filename,
    required this.directory,
    required this.createdAt,
    this.status = DownloadStatus.queued,
    this.bytes = 0,
    this.total = 0,
  });
  factory GameDownloadTask.create(
    WorkItem item,
    GameResource resource,
    GameChannel channel,
    Directory root,
  ) {
    final filename = fileName(channel.label);
    return GameDownloadTask._(
      item: item,
      resourceId: resource.id,
      channelId: channel.id,
      filename: filename.isEmpty ? 'game.bin' : filename,
      directory: p.join(
        root.path,
        'games',
        safeFileName(item.source),
        safeFileName(item.id),
        safeFileName(resource.id),
        safeFileName(channel.id),
      ),
      createdAt: DateTime.now(),
    );
  }
  factory GameDownloadTask.fromJson(Map<String, dynamic> json) {
    final name = json['filename'] as String;
    if (name.isEmpty || name != fileName(name)) {
      throw const FormatException('游戏文件名无效');
    }
    final status = DownloadStatus.values.byName(json['status'] as String);
    final task = GameDownloadTask._(
      item: WorkItem.fromStored((json['item'] as Map).cast<String, dynamic>()),
      resourceId: json['resourceId'] as String,
      channelId: json['channelId'] as String,
      filename: name,
      directory: json['directory'] as String,
      createdAt: DateTime.parse(json['createdAt'] as String),
      status: status == DownloadStatus.done ? status : DownloadStatus.paused,
      bytes: (json['bytes'] as num?)?.toInt() ?? 0,
      total: (json['total'] as num?)?.toInt() ?? 0,
    );
    final expected = p.join(
      'games',
      safeFileName(task.item.source),
      safeFileName(task.item.id),
      safeFileName(task.resourceId),
      safeFileName(task.channelId),
    );
    if (!p.isAbsolute(task.directory) ||
        !p.normalize(task.directory).endsWith('${p.separator}$expected')) {
      throw const FormatException('游戏下载目录无效');
    }
    task.extractionCode = json['extractionCode'] as String? ?? '';
    task.archivePassword = json['archivePassword'] as String? ?? '';
    return task;
  }
  final WorkItem item;
  final String resourceId, channelId, filename, directory;
  final DateTime createdAt;
  DownloadStatus status;
  int bytes, total;
  String? error;
  String extractionCode = '', archivePassword = '';
  String get key => '${item.uid}:$resourceId:$channelId';
  File get file => File(p.join(directory, filename));
  Map<String, dynamic> toJson() => {
    'item': item.toJson(),
    'resourceId': resourceId,
    'channelId': channelId,
    'filename': filename,
    'directory': directory,
    'createdAt': createdAt.toIso8601String(),
    'status': status.name,
    'bytes': bytes,
    'total': total,
    'extractionCode': extractionCode,
    'archivePassword': archivePassword,
  };
}

/// Streams large files without source cookies, memory buffering, or automatic redirects.
class GameFileDownloader {
  GameFileDownloader({Dio? client}) : _client = client ?? _build();
  final Dio _client;
  static Dio _build() =>
      Dio(BaseOptions(connectTimeout: const Duration(seconds: 20)))
        ..httpClientAdapter = IOHttpClientAdapter(
          createHttpClient: () =>
              createHttpClient(proxy: AppSettings.instance.proxy),
        );

  Future<void> download(
    SourceManifest manifest,
    GameResourceLink link,
    File file, {
    required CancelToken cancelToken,
    required void Function(int bytes, int total) onProgress,
  }) async {
    final partial = File('${file.path}.part');
    RandomAccessFile? sink;
    try {
      final policy = MediaPolicy.fromManifest(manifest);
      if (policy.mode != 'native' || link.kind != GameChannelKind.direct) {
        throw SourceError('CONFIG', '该渠道不支持直链下载');
      }
      if (await file.exists()) throw SourceError('CONFIG', '游戏文件已存在');
      var target = Uri.parse(link.url);
      for (var hop = 0; hop < 8; hop++) {
        policy.validate(target);
        if (cancelToken.isCancelled) throw SourceError('CANCELLED', '已取消');
        final requestToken = CancelToken();
        final cancellation = cancelToken.whenCancel.asStream().listen(
          requestToken.cancel,
        );
        try {
          final response = await _client.get<ResponseBody>(
            target.toString(),
            options: Options(
              responseType: ResponseType.stream,
              followRedirects: false,
              validateStatus: (_) => true,
              receiveTimeout: const Duration(seconds: 45),
              headers: {
                'Accept-Encoding': 'identity',
                'Referer': '${policy.origin}/',
              },
            ),
            cancelToken: requestToken,
          );
          final body = response.data;
          if (body == null) throw SourceError('NETWORK', '游戏下载响应为空');
          if (const {301, 302, 303, 307, 308}.contains(response.statusCode)) {
            await body.stream.listen((_) {}).cancel();
            final location = response.headers.value('location');
            if (location == null) throw SourceError('NETWORK', '游戏下载重定向无效');
            target = target.resolve(location);
            continue;
          }
          final type =
              response.headers.value('content-type')?.toLowerCase() ?? '';
          if (response.statusCode != 200 ||
              type.contains('text/') ||
              type.contains('json') ||
              type.contains('html')) {
            await body.stream.listen((_) {}).cancel();
            throw SourceError('NETWORK', '直链下载失败，可重试或选择网盘渠道');
          }
          final length = int.tryParse(
            response.headers.value('content-length') ?? '',
          );
          final encoding = response.headers.value('content-encoding');
          if (encoding != null && encoding != 'identity') {
            await body.stream.listen((_) {}).cancel();
            throw SourceError('NETWORK', '游戏下载响应格式无效');
          }
          await file.parent.create(recursive: true);
          sink = await partial.open(mode: FileMode.write);
          var received = 0;
          Future<void> write() async {
            await for (final chunk in body.stream.timeout(
              const Duration(seconds: 45),
            )) {
              if (cancelToken.isCancelled) {
                throw SourceError('CANCELLED', '已取消');
              }
              await sink!.writeFrom(chunk);
              received += chunk.length;
              if (length != null && received > length) {
                throw SourceError('NETWORK', '游戏文件不完整');
              }
              onProgress(received, length ?? 0);
            }
            await sink!.flush();
          }

          await write();
          if (received == 0 || (length != null && length != received)) {
            throw SourceError('NETWORK', '游戏文件不完整');
          }
          await sink.close();
          sink = null;
          if (cancelToken.isCancelled) throw SourceError('CANCELLED', '已取消');
          // Each channel owns a private directory; a completed file is never overwritten.
          if (await file.exists()) throw SourceError('CONFIG', '游戏文件已存在');
          await partial.rename(file.path);
          return;
        } finally {
          // Dio does not forward stream subscription cancellation to its source.
          requestToken.cancel('game resource finished');
          await requestToken.whenCancel;
          await cancellation.cancel();
        }
      }
      throw SourceError('NETWORK', '游戏下载重定向次数过多');
    } catch (error) {
      if (cancelToken.isCancelled) throw SourceError('CANCELLED', '已取消');
      if (error is SourceError) rethrow;
      throw SourceError('NETWORK', '直链下载失败，可重试或选择网盘渠道');
    } finally {
      await sink?.close();
      if (await partial.exists()) await partial.delete();
      _client.close(force: true);
    }
  }
}

class GameDownloadManager extends ChangeNotifier {
  GameDownloadManager._();
  static final instance = GameDownloadManager._();
  final _store = JsonStore('game_downloads.json');
  final _tasks = <String, GameDownloadTask>{};
  final _unrestored = <Object?>[];
  final _active = <String, CancelToken>{};
  bool _loaded = false;
  Future<void>? _loading;
  final _running = <String, Future<void>>{};
  List<GameDownloadTask> get tasks =>
      _tasks.values.toList()
        ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  GameDownloadTask? task(String key) => _tasks[key];
  bool isActive(String key) => _active.containsKey(key);
  Future<void> load() {
    if (_loaded) return Future.value();
    return _loading ??= _load().whenComplete(() => _loading = null);
  }

  Future<void> _load() async {
    final raw = await _store.load();
    if (raw != null && raw is! List) {
      throw const FormatException('下载记录恢复失败，请前往下载页处理');
    }
    for (final entry in raw is List ? raw : const []) {
      try {
        final task = GameDownloadTask.fromJson(
          (entry as Map).cast<String, dynamic>(),
        );
        if (_tasks.containsKey(task.key)) {
          _unrestored.add(entry);
          continue;
        }
        if (task.status == DownloadStatus.done && !await task.file.exists()) {
          task.status = DownloadStatus.failed;
          task.error = '本地文件已被删除';
        }
        _tasks[task.key] = task;
      } catch (_) {
        // 无法恢复的条目不能定义下载目标，但后续保存必须保留其原始资产信息。
        _unrestored.add(entry);
      }
    }
    _loaded = true;
    DownloadManager.instance.addListener(_networkChanged);
    DownloadScheduler.instance.addListener(_pump);
    notifyListeners();
  }

  void _save() =>
      _store.save([for (final task in tasks) task.toJson(), ..._unrestored]);
  Future<void> flush() => _store.flush();
  Future<void> pauseAndFlush() async {
    for (final task in tasks) {
      if (task.status == DownloadStatus.queued ||
          task.status == DownloadStatus.running) {
        cancel(task.key);
      }
    }
    await Future.wait(_running.values.toList());
    await flush();
  }

  Future<void> enqueue(
    WorkItem item,
    GameResource resource,
    GameChannel channel,
  ) async {
    if (!_loaded) throw SourceError('CONFIG', '游戏下载器尚未就绪');
    if (channel.kind != GameChannelKind.direct) {
      throw SourceError('CONFIG', '该渠道不支持直链下载');
    }
    final task = GameDownloadTask.create(
      item,
      resource,
      channel,
      AppPaths.downloadRoot,
    );
    if (_tasks.containsKey(task.key)) {
      retry(task.key);
      return;
    }
    _tasks[task.key] = task;
    _save();
    await flush();
    notifyListeners();
    _pump();
  }

  void retry(String key) {
    final task = _tasks[key];
    if (task == null || isActive(key) || task.status == DownloadStatus.done) {
      return;
    }
    task.status = DownloadStatus.queued;
    task.error = null;
    task.bytes = 0;
    task.total = 0;
    _save();
    notifyListeners();
    _pump();
  }

  void cancel(String key) {
    final task = _tasks[key];
    if (task == null || task.status == DownloadStatus.done) return;
    task.status = DownloadStatus.paused;
    _active[key]?.cancel('user cancelled');
    _save();
    notifyListeners();
  }

  Future<void> remove(String key) async {
    if (isActive(key)) throw SourceError('CONFIG', '请先取消下载并等待结束');
    // Removing the record keeps the user's downloaded file intact.
    _tasks.remove(key);
    _save();
    await flush();
    notifyListeners();
  }

  void _networkChanged() {
    if (!DownloadManager.instance.networkAllowed) {
      for (final entry in _active.entries) {
        final task = _tasks[entry.key];
        if (task?.status != DownloadStatus.running) continue;
        task!.status = DownloadStatus.queued;
        entry.value.cancel('waiting for Wi-Fi');
      }
    }
    _pump();
  }

  void _pump() {
    if (!DownloadManager.instance.networkAllowed) return;
    for (final task in tasks.where((t) => t.status == DownloadStatus.queued)) {
      if (isActive(task.key)) continue;
      final slot = DownloadScheduler.instance.tryAcquire(task.item.source);
      if (slot == null) continue;
      final token = CancelToken();
      _active[task.key] = token;
      final run = _run(task, token).whenComplete(() {
        _active.remove(task.key);
        _running.remove(task.key);
        _save();
        notifyListeners();
        slot.release();
        _pump();
      });
      _running[task.key] = run;
      unawaited(run);
    }
  }

  Future<void> _run(GameDownloadTask task, CancelToken token) async {
    task.status = DownloadStatus.running;
    task.error = null;
    notifyListeners();
    DownloadLease? lease;
    try {
      lease = await BackgroundDownloads.instance.acquire(cancelToken: token);
      lease.check();
      final sources = SourceManager.instance;
      await awaitCancelled(sources.ready, token);
      final manifest = sources.manifest(task.item.source);
      if (manifest == null || !manifest.isGame) {
        throw SourceError('CONFIG', '游戏站点未加载');
      }
      final link = await sources.resolveGameResource(
        task.item.source,
        task.item.id,
        task.resourceId,
        task.channelId,
        cancelToken: token,
      );
      task.extractionCode = link.extractionCode;
      task.archivePassword = link.archivePassword;
      _save();
      notifyListeners();
      var lastUpdate = DateTime.now();
      await GameFileDownloader().download(
        manifest,
        link,
        task.file,
        cancelToken: token,
        onProgress: (bytes, total) {
          lease?.reportProgress(bytes, total);
          task.bytes = bytes;
          task.total = total;
          if (DateTime.now().difference(lastUpdate).inMilliseconds > 250) {
            lastUpdate = DateTime.now();
            notifyListeners();
          }
        },
      );
      // Publication is the commit point: cancellation during transport cleanup
      // must not turn an already completed file into an unretryable paused task.
      task.status = DownloadStatus.done;
    } catch (error) {
      if (task.status == DownloadStatus.running) {
        final stopped = BackgroundDownloads.interruption(
          token.cancelError ?? error,
        );
        task.status = stopped == null
            ? DownloadStatus.failed
            : DownloadStatus.paused;
        task.error = stopped?.friendly ?? '直链下载失败，可重试或选择网盘渠道';
      }
    } finally {
      await lease?.release();
    }
  }
}
