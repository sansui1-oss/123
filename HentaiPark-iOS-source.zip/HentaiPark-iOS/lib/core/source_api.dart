/// WebKit may transport a JavaScript integer as a Dart double. Compare the
/// finite numeric value; never coerce strings, fractions or other API versions.
bool matchesSourceApi(Object? value, int supported) =>
    value is num && value.isFinite && value == supported;
