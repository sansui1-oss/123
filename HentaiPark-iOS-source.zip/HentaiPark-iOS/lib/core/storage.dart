import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

import 'app_log.dart';
import 'async_tasks.dart';

/// 同目录准备并提交文件；提交前可检查取消/代次，失败不改动原文件。
Future<bool> writeFileAtomic(
  File file,
  List<int> bytes, {
  FutureOr<bool> Function()? canCommit,
}) async {
  final temporary = File('${file.path}.tmp-${const Uuid().v4()}');
  try {
    await temporary.writeAsBytes(bytes, flush: true);
    if (canCommit != null && !await canCommit()) return false;
    await temporary.rename(file.path);
    return true;
  } finally {
    if (await temporary.exists()) await temporary.delete();
  }
}

/// Well-known app directories, resolved once at startup.
class AppPaths {
  static late Directory
  data; // persistent app data (sources, library, settings)
  static late Directory cache; // image cache, can be cleared
  static late Directory downloads; // offline downloads
  static late Directory
  backups; // automatic and manual backups (user-visible on Android)
  static late Directory
  downloadRoot; // new downloads and exports (user-visible on Android)

  static Future<void> init() async {
    final support = await getApplicationSupportDirectory();
    final temp = await getApplicationCacheDirectory();
    data = Directory(p.join(support.path, 'park'));
    cache = Directory(p.join(temp.path, 'park_cache'));
    downloads = Directory(p.join(support.path, 'downloads'));
    final external = await _external();
    backups = Directory(p.join(external?.path ?? support.path, 'backups'));
    downloadRoot = external == null
        ? downloads
        : Directory(p.join(external.path, 'downloads'));
    for (final d in [data, cache, downloads, backups, downloadRoot]) {
      await d.create(recursive: true);
    }
  }

  static File dataFile(String name) => File(p.join(data.path, name));

  /// 仅影响新任务；已下载任务仍保存原目录，避免移动或遗失资产。
  static Future<void> selectDownloadDirectory(String path) async {
    if (path.isEmpty || !p.isAbsolute(path)) {
      throw const FileSystemException('Invalid download directory');
    }
    final directory = Directory(path);
    await directory.create(recursive: true);
    final probe = File(p.join(path, '.park-write-${const Uuid().v4()}'));
    try {
      await probe.writeAsBytes(const [], flush: true);
    } finally {
      if (await probe.exists()) await probe.delete();
    }
    final roots = await exportDirectories();
    roots.add(p.join(directory.absolute.path, 'exports'));
    await writeFileAtomic(
      dataFile('export_directories.json'),
      utf8.encode(jsonEncode(roots.toList())),
    );
    downloadRoot = directory;
  }

  /// 本机导出位置独立于可迁移配置；更换目录不移动或遗失旧文件。
  static Future<Set<String>> exportDirectories() async {
    final file = dataFile('export_directories.json');
    final saved = await file.exists()
        ? jsonDecode(await file.readAsString())
        : const [];
    if (saved is! List ||
        saved.any((value) => value is! String || !p.isAbsolute(value))) {
      throw const FormatException('导出目录记录无效');
    }
    return {
      p.join(downloadRoot.absolute.path, 'exports'),
      ...saved.cast<String>(),
    };
  }

  /// App-specific external storage on Android (visible to file managers, no permission needed).
  static Future<Directory?> _external() async {
    if (!Platform.isAndroid) return null;
    try {
      return await getExternalStorageDirectory();
    } catch (_) {
      return null;
    }
  }
}

/// A JSON document persisted to disk with debounced, atomic writes.
class JsonStore {
  JsonStore(this.name, {this.debounce = const Duration(milliseconds: 400)});

  final String name;
  final Duration debounce;
  Object? _data;
  Timer? _timer;
  final _writing = SerialExecutor();
  static final _failed = <JsonStore>{};
  static final failedWrites = ValueNotifier<int>(0);
  static Timer? _retry;

  static Future<void> retryFailed() async {
    _retry?.cancel();
    _retry = null;
    await Future.wait([
      for (final store in _failed.toList())
        store.flush().catchError((Object _) {}),
    ]);
  }

  void _writeFailed(Object error) {
    _failed.add(this);
    failedWrites.value = _failed.length;
    AppLog.error(error, event: 'storage_save');
    _retry ??= Timer(const Duration(seconds: 5), () {
      unawaited(retryFailed());
    });
  }

  File get _file => AppPaths.dataFile(name);

  Future<Object?> load() async {
    _data = null;
    try {
      if (await _file.exists()) _data = jsonDecode(await _file.readAsString());
    } on FormatException {
      // 每份损坏原件都可能含有可恢复资产；保留失败时停止加载，不能继续覆盖。
      await _file.copy('${_file.path}.broken-${const Uuid().v4()}');
      _data = null;
    }
    return _data;
  }

  void save(Object? data) {
    _data = data;
    _timer?.cancel();
    _timer = Timer(debounce, () {
      // Deferred writes retain _data for a later retry; explicit flush callers still receive errors.
      unawaited(flush().catchError((Object _) {}));
    });
  }

  Future<void> flush() {
    _timer?.cancel();
    _timer = null;
    final text = jsonEncode(_data);
    final file = _file;
    return _writing.run(() async {
      try {
        await writeFileAtomic(file, utf8.encode(text));
        _failed.remove(this);
        failedWrites.value = _failed.length;
        if (_failed.isEmpty) {
          _retry?.cancel();
          _retry = null;
        }
      } catch (error) {
        _writeFailed(error);
        rethrow;
      }
    });
  }
}

/// Stable identity segment: fixed length, safe on all filesystems, and distinct
/// even when IDs differ only by punctuation, Unicode, or letter case.
String safeFileName(String s) => sha256.convert(utf8.encode(s)).toString();
