/// A local display order only. Never changes remote pagination or infers dates
/// from titles, relative time strings, IDs or the time an item was downloaded.
List<T> newestFirst<T>(Iterable<T> items, String Function(T) uploaded) {
  final rows = items.toList().asMap().entries.map((entry) {
    final text = uploaded(entry.value).trim();
    final date = RegExp(r'^\d{4}-\d{2}-\d{2}(?:[T ].*)?$').hasMatch(text)
        ? DateTime.tryParse(text)
        : null;
    return (item: entry.value, index: entry.key, date: date);
  }).toList();
  rows.sort((a, b) {
    final left = a.date, right = b.date;
    if (left == null && right != null) return 1;
    if (left != null && right == null) return -1;
    final compared = left == null || right == null ? 0 : right.compareTo(left);
    return compared == 0 ? a.index.compareTo(b.index) : compared;
  });
  return rows.map((row) => row.item).toList();
}
