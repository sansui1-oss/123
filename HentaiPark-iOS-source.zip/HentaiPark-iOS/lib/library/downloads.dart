import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:dio/dio.dart';
import 'package:drift/drift.dart' show InsertMode;
import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;

import '../core/app_log.dart';
import '../core/async_tasks.dart';
import '../core/localization.dart';
import '../core/models.dart';
import '../core/settings.dart';
import '../core/storage.dart';
import '../data/database.dart';
import '../engine/background_downloads.dart';
import '../engine/cancellation.dart';
import '../engine/source_manager.dart';
import '../images/image_tasks.dart';
import '../images/park_image.dart';
import '../video/local_hls_media.dart';
import '../video/media_download.dart';
import 'download_scheduler.dart';
import 'download_selection.dart';
import 'library.dart';
import 'offline_bundle.dart';

enum DownloadStatus { queued, running, paused, done, failed }

enum DownloadMedia { comic, video, novel, bundle }

/// Pseudo source key of works imported from local CBZ / ZIP files.
const localSource = 'local';

class DownloadTask {
  DownloadTask({
    required this.item,
    required List<Chapter> chapters,
    String? dir,
    this.status = DownloadStatus.queued,
    this.done = 0,
    this.total = 0,
    this.error,
    this.bytes = 0,
    DateTime? createdAt,
    Set<String>? completed,
    required this.media,
    this.videoQuality,
    this.videoSelection,
    Map<String, Map<String, dynamic>>? bundleNodes,
    Map<String, String>? videoFiles,
    this.deletingChapters,
  }) : dir = Directory(
         dir ??
             p.join(
               DownloadManager.instance.root.path,
               safeFileName(item.source),
               safeFileName(item.id),
             ),
       ),
       createdAt = createdAt ?? DateTime.now(),
       chapters = List.of(chapters),
       completed = completed ?? {},
       videoFiles = videoFiles ?? {},
       bundleNodes = bundleNodes ?? {};

  final WorkItem item;
  final List<Chapter> chapters;
  final DownloadMedia media;
  DownloadSelection? videoSelection;
  final Map<String, Map<String, dynamic>> bundleNodes;
  bool get isBundle => media == DownloadMedia.bundle;
  int? videoQuality; // 0 selects the source's preferred quality.
  final Map<String, String>
  videoFiles; // episode id -> MP4 path relative to dir.
  DownloadStatus status;
  int done;
  int total;
  int bytes;
  String? error;
  CancelToken? cancel;
  DownloadLease? lease;

  /// 空列表表示删除整个任务；非空列表表示待完成的章节删除。
  List<String>? deletingChapters;
  final DateTime createdAt;

  /// Chapters whose files are complete (pages.json written), so they can be read offline even
  /// while other chapters of the task are still queued.
  final Set<String> completed;

  /// Where this task's files live. Recorded per task so changing the download root never orphans old downloads.
  final Directory dir;

  /// 读取章节资产时同时校验相对路径与真实路径，禁止清单或链接越出章节。
  Future<File?> chapterFile(String chapterId, String relative) async {
    if (p.isAbsolute(relative)) return null;
    final root = p.normalize(p.absolute(dir.path));
    final chapter = p.join(root, safeFileName(chapterId));
    final target = p.normalize(p.join(chapter, relative));
    if (!p.isWithin(chapter, target)) return null;
    final file = File(target);
    if (!await file.exists()) return null;
    final actualRoot = await dir.resolveSymbolicLinks();
    final actualChapter = await Directory(chapter).resolveSymbolicLinks();
    if (!p.equals(p.join(actualRoot, safeFileName(chapterId)), actualChapter)) {
      return null;
    }
    final actual = await file.resolveSymbolicLinks();
    return p.isWithin(actualChapter, actual) ? File(actual) : null;
  }

  String get uid => item.uid;
  bool get isVideo => media == DownloadMedia.video;
  bool get isNovel => media == DownloadMedia.novel;

  /// 只有未完成的在线漫画允许缺页联网；已完成下载始终按本地内容打开。
  bool get canReadWhileDownloading =>
      media == DownloadMedia.comic &&
      item.source != localSource &&
      status != DownloadStatus.done;
  double get progress => total > 0 ? done / total : 0;

  Map<String, dynamic> toJson() => {
    'item': item.toJson(),
    'chapters': [
      for (final c in chapters) {'id': c.id, 'title': c.title},
    ],
    'status': status == DownloadStatus.running
        ? DownloadStatus.queued.index
        : status.index,
    'done': done,
    'total': total,
    'bytes': bytes,
    'error': error,
    'completed': completed.toList(),
    'media': media.name,
    if (videoQuality != null) 'videoQuality': videoQuality,
    if (videoSelection != null) 'videoSelection': videoSelection!.json,
    if (bundleNodes.isNotEmpty) 'bundleNodes': bundleNodes,
    if (videoFiles.isNotEmpty) 'videoFiles': videoFiles,
    if (deletingChapters != null) 'deletingChapters': deletingChapters,
  };

  factory DownloadTask.fromJson(
    Map<String, dynamic> j, {
    String? dir,
    DateTime? createdAt,
  }) => DownloadTask(
    item: WorkItem.fromStored((j['item'] as Map).cast<String, dynamic>()),
    dir: dir,
    createdAt: createdAt,
    chapters: (j['chapters'] as List)
        .cast<Map>()
        .map((c) => Chapter(c['id'].toString(), c['title'].toString()))
        .toList(),
    status: DownloadStatus.values[(j['status'] as num).toInt()],
    done: (j['done'] as num?)?.toInt() ?? 0,
    total: (j['total'] as num?)?.toInt() ?? 0,
    bytes: (j['bytes'] as num?)?.toInt() ?? 0,
    error: j['error'] as String?,
    completed: ((j['completed'] as List?) ?? const [])
        .map((e) => e.toString())
        .toSet(),
    media: DownloadMedia.values.byName(j['media'] as String),
    videoQuality: (j['videoQuality'] as num?)?.toInt(),
    videoSelection: j['videoSelection'] is Map
        ? DownloadSelection(
            (j['videoSelection'] as Map).cast<String, dynamic>(),
          )
        : null,
    bundleNodes: (j['bundleNodes'] as Map? ?? {}).map(
      (k, v) => MapEntry(k.toString(), (v as Map).cast<String, dynamic>()),
    ),
    videoFiles: (j['videoFiles'] as Map? ?? const {}).map(
      (k, v) => MapEntry(k.toString(), v.toString()),
    ),
    deletingChapters: (j['deletingChapters'] as List?)?.cast<String>(),
  );

  /// Single videos retain their root output; explicit episode catalogs use isolated directories.
  Directory videoDirectory(String episodeId) {
    final detail = WorkDetail(item.json, item.source);
    if (!detail.hasVideoEpisodes &&
        episodeId == detail.videoEpisodes.single.id) {
      return dir;
    }
    return Directory(p.join(dir.path, 'episode_${safeFileName(episodeId)}'));
  }
}

/// Offline downloads. Comic pages are stored raw together with their transform descriptors
/// (JM pages are unscrambled at display time); videos are streamed to an mp4 file.
class DownloadManager extends ChangeNotifier {
  DownloadManager._();
  static final DownloadManager instance = DownloadManager._();

  late AppDatabase _db;
  final Map<String, DownloadTask> _tasks = {};
  final Map<String, DownloadRow> _restoreFailures = {};
  final _restores = SerialExecutor();

  List<({String uid, String source})> get restoreFailures => [
    for (final row in _restoreFailures.values)
      (uid: row.uid, source: row.source),
  ];
  bool hasRestoreFailure(String uid) => _restoreFailures.containsKey(uid);

  /// Root directory for new downloads (user-visible app storage on Android).
  Directory get root => AppPaths.downloadRoot;

  StreamSubscription<List<ConnectivityResult>>? _connectivity;
  bool _onWifi = true;

  /// 按作品身份记录运行任务；跨站和同站额度由共享调度器统一控制。
  final Map<String, DownloadTask> _active = {};
  final Map<DownloadTask, Future<void>> _runs = {};
  final Map<String, Future<void>> _deletions = {};
  final Set<String> _removing = {};
  final _writes = SerialExecutor();
  bool _disposed = false;

  List<DownloadTask> get tasks =>
      _tasks.values.toList()
        ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  DownloadTask? task(String uid) => _tasks[uid];

  Future<void> load(AppDatabase db) async {
    _db = db;
    for (final r in await db.select(db.downloadTasks).get()) {
      try {
        final t = _restoreTask(r);
        _tasks[t.uid] = t;
        _restoreFailures.remove(r.uid);
      } catch (e) {
        _restoreFailures[r.uid] = r;
        AppLog.error(e, event: 'download_restore');
      }
    }
    Library.instance.onChaptersRead.add(_onChaptersRead);
    _settingsListenable.addListener(_settingsChanged);
    DownloadScheduler.instance.addListener(_pump);
    await _watchNetwork();
    for (final task in _tasks.values.toList()) {
      if (task.deletingChapters == null) continue;
      try {
        await _retryDeletion(task);
      } catch (error) {
        AppLog.error(error, event: 'download_delete');
      }
    }
    _pump();
  }

  DownloadTask _restoreTask(DownloadRow row) {
    final task = DownloadTask.fromJson(
      (jsonDecode(row.json) as Map).cast<String, dynamic>(),
      dir: row.dir,
      createdAt: DateTime.fromMillisecondsSinceEpoch(row.createdAt),
    );
    if (task.uid != row.uid || task.item.source != row.source) {
      throw const FormatException('Invalid download identity');
    }
    return task;
  }

  Future<void> retryRestore(String uid) =>
      _restores.run(() => _retryRestore(uid));

  Future<void> _retryRestore(String uid) async {
    if (!_restoreFailures.containsKey(uid)) return;
    final row = await (_db.select(
      _db.downloadTasks,
    )..where((r) => r.uid.equals(uid))).getSingleOrNull();
    if (row == null) {
      _restoreFailures.remove(uid);
      notifyListeners();
      return;
    }
    try {
      final task = _restoreTask(row);
      _tasks[uid] = task;
      _restoreFailures.remove(uid);
      if (task.deletingChapters != null) await _retryDeletion(task);
      _pump();
    } finally {
      notifyListeners();
    }
  }

  /// 无法确定文件归属时只移除记录，保留原始本地文件。
  Future<void> removeRestoreFailure(String uid) =>
      _restores.run(() => _removeRestoreFailure(uid));

  Future<void> _removeRestoreFailure(String uid) async {
    if (!_restoreFailures.containsKey(uid)) return;
    await _writes.run(
      () =>
          (_db.delete(_db.downloadTasks)..where((r) => r.uid.equals(uid))).go(),
    );
    _restoreFailures.remove(uid);
    notifyListeners();
  }

  Future<void> _watchNetwork() async {
    try {
      final c = Connectivity();
      _onWifi = _isUnmetered(await c.checkConnectivity());
      _connectivity = c.onConnectivityChanged.listen((r) {
        final wifi = _isUnmetered(r);
        if (wifi == _onWifi) return;
        _onWifi = wifi;
        _settingsChanged();
        notifyListeners();
      }, onError: (Object e) => AppLog.error(e, event: 'connectivity'));
    } catch (e) {
      AppLog.error(e, event: 'connectivity');
    }
  }

  static bool _isUnmetered(List<ConnectivityResult> r) => r.any(
    (x) => x == ConnectivityResult.wifi || x == ConnectivityResult.ethernet,
  );

  /// False while "Wi-Fi only" is on and the device is on mobile data.
  bool get networkAllowed => !AppSettings.instance.downloadWifiOnly || _onWifi;

  final _settingsListenable = AppSettings.instance.watch(const {
    'downloadConcurrency',
    'downloadSiteConcurrency',
    'downloadTaskConcurrency',
    'downloadWifiOnly',
  });

  void _settingsChanged() {
    if (_disposed) return;
    if (!networkAllowed) {
      for (final t in _active.values) {
        if (t.status != DownloadStatus.running) continue;
        t.status = DownloadStatus.queued;
        t.cancel?.cancel('waiting for Wi-Fi');
        _save([t]);
      }
    }
    _pump();
    notifyListeners();
  }

  /// "Delete after reading": drop downloaded chapters once they are marked read.
  void _onChaptersRead(String uid, List<String> chapterIds) {
    if (!AppSettings.instance.deleteAfterRead) return;
    final t = _tasks[uid];
    if (t == null || t.item.source == localSource) return;
    unawaited(
      deleteChapters(
        uid,
        chapterIds.where(t.completed.contains).toList(),
      ).catchError(
        (Object error) => AppLog.error(error, event: 'download_delete'),
      ),
    );
  }

  @override
  void dispose() {
    _disposed = true;
    _connectivity?.cancel();
    _settingsListenable.removeListener(_settingsChanged);
    DownloadScheduler.instance.removeListener(_pump);
    Library.instance.onChaptersRead.remove(_onChaptersRead);
    for (final t in _active.values) {
      t.status = DownloadStatus.paused;
      t.cancel?.cancel('download manager disposed');
    }
    super.dispose();
  }

  /// Persists the given tasks (all when null). Progress is saved at chapter boundaries, not per page.
  Future<void> flush() async {
    await Future.wait(_deletions.values.toList());
    await _writes.settled;
    // 显式落盘最新任务，使关闭窗口时数据库错误能返回调用者。
    final tasks = _tasks.values.toList();
    await _writes.run(
      () => _db.batch((b) {
        for (final t in tasks) {
          b.insert(
            _db.downloadTasks,
            DownloadTasksCompanion.insert(
              uid: t.uid,
              source: t.item.source,
              json: jsonEncode(t.toJson()),
              dir: t.dir.path,
              createdAt: t.createdAt.millisecondsSinceEpoch,
            ),
            mode: InsertMode.insertOrReplace,
          );
        }
      }),
    );
  }

  Future<void> pauseAndFlush() async {
    pauseAll();
    await Future.wait(_runs.values.toList());
    await flush();
  }

  void _save([Iterable<DownloadTask>? which]) {
    if (_disposed) return;
    final rows = [
      for (final t in which ?? _tasks.values)
        if (identical(_tasks[t.uid], t) && !_deletions.containsKey(t.uid))
          DownloadTasksCompanion.insert(
            uid: t.uid,
            source: t.item.source,
            json: jsonEncode(t.toJson()),
            dir: t.dir.path,
            createdAt: t.createdAt.millisecondsSinceEpoch,
          ),
    ];
    unawaited(
      _writes
          .run(
            () => _db.batch((b) {
              for (final row in rows) {
                b.insert(
                  _db.downloadTasks,
                  row,
                  mode: InsertMode.insertOrReplace,
                );
              }
            }),
          )
          .catchError((Object e) => AppLog.error(e, event: 'download_save')),
    );
    notifyListeners();
  }

  void _notifyProgress(DownloadTask task) {
    task.lease?.reportProgress(task.done, task.total);
    notifyListeners();
  }

  void enqueue(
    WorkItem item,
    List<Chapter> chapters, {
    int? videoQuality,
    DownloadSelection? selection,
    Map<String, Map<String, dynamic>>? bundleNodes,
  }) {
    if (SourceManager.instance.manifest(item.source)?.isLive == true) return;
    if (item.isGame ||
        SourceManager.instance.manifest(item.source)?.isGame == true) {
      throw SourceError('UNSUPPORTED', '游戏资源请使用独立下载渠道');
    }
    if (_disposed || chapters.isEmpty) return;
    if (_restoreFailures.containsKey(item.uid)) return;
    if (item.source == localSource) {
      return; // imported files are already complete
    }
    final media = bundleNodes != null
        ? DownloadMedia.bundle
        : videoQuality != null
        ? DownloadMedia.video
        : SourceManager.instance.manifest(item.source)?.isNovel == true ||
              item.isNovel
        ? DownloadMedia.novel
        : DownloadMedia.comic;
    if (_tasks[item.uid] case final existing?) {
      if (existing.media != media) {
        throw StateError('Download media type mismatch');
      }
    }
    final deleting = _deletions[item.uid];
    if (deleting != null) {
      final existing = _tasks[item.uid];
      final removing = _removing.contains(item.uid);
      final requested = List<Chapter>.of(chapters);
      if (existing != null) {
        existing.status = DownloadStatus.queued;
        _save([existing]);
      }
      unawaited(
        deleting
            .then((_) {
              if (existing == null || removing) {
                enqueue(
                  item,
                  requested,
                  videoQuality: videoQuality,
                  selection: selection,
                  bundleNodes: bundleNodes,
                );
              } else if (!_disposed && identical(_tasks[item.uid], existing)) {
                _addChapters(
                  existing,
                  requested,
                  videoQuality: videoQuality,
                  selection: selection,
                  bundleNodes: bundleNodes,
                );
                _save([existing]);
                _pump();
              }
            })
            .catchError(
              (Object error) => AppLog.error(error, event: 'download_delete'),
            ),
      );
      return;
    }
    final existing = _tasks[item.uid];
    if (existing != null) {
      _addChapters(
        existing,
        chapters,
        videoQuality: videoQuality,
        selection: selection,
        bundleNodes: bundleNodes,
      );
      if (existing.status != DownloadStatus.running) {
        existing.status = DownloadStatus.queued;
      }
    } else {
      _tasks[item.uid] = DownloadTask(
        item: item,
        chapters: chapters,
        media: media,
        videoQuality: videoQuality,
        videoSelection: selection,
        bundleNodes: bundleNodes,
      );
    }
    _save([_tasks[item.uid]!]);
    _pump();
  }

  static void _addChapters(
    DownloadTask task,
    List<Chapter> chapters, {
    int? videoQuality,
    DownloadSelection? selection,
    Map<String, Map<String, dynamic>>? bundleNodes,
  }) {
    if (task.isVideo != (videoQuality != null)) {
      throw StateError('Download media type mismatch');
    }
    if (selection != null) task.videoSelection = selection;
    if (bundleNodes != null) task.bundleNodes.addAll(bundleNodes);
    final known = task.chapters.map((c) => c.id).toSet();
    task.chapters.addAll(chapters.where((c) => known.add(c.id)));
    if (videoQuality != null) {
      task.videoQuality = videoQuality;
    }
  }

  void enqueueVideo(
    WorkItem item,
    List<Chapter> episodes, {
    int quality = 0,
    DownloadSelection? selection,
  }) => enqueue(item, episodes, videoQuality: quality, selection: selection);

  void enqueueBundle(WorkItem item, {Map<String, dynamic>? node}) {
    // 原始帖子附件在执行时重新解析；数据库不保存签名地址和媒体请求头。
    final manifest = SourceManager.instance.manifest(item.source);
    item = WorkItem(
      <String, dynamic>{
          ...item.json,
          if (item.mediaKind == null && manifest != null)
            'mediaKind': manifest.kind.name,
          if (item.json['contentDomain'] == null && manifest != null)
            'contentDomain': manifest.category.name,
        }
        ..remove('media')
        ..remove('blocks'),
      item.source,
    );
    final id = node?['id']?.toString() ?? '_';
    enqueue(
      item,
      [Chapter(id, node?['name']?.toString() ?? item.title)],
      bundleNodes: {id: node ?? {}},
    );
  }

  void pause(String uid) {
    final t = _tasks[uid];
    if (t == null) return;
    t.status = DownloadStatus.paused;
    t.cancel?.cancel();
    _save([t]);
  }

  Future<void> pauseAndWait(String uid) async {
    final task = _tasks[uid];
    if (task == null) return;
    pause(uid);
    await _runs[task];
  }

  void resume(String uid) {
    final t = _tasks[uid];
    if (t?.deletingChapters != null) {
      if (t!.deletingChapters!.isNotEmpty) {
        t.status = DownloadStatus.queued;
        t.error = null;
      }
      unawaited(
        _retryDeletion(t).catchError(
          (Object error) => AppLog.error(error, event: 'download_delete'),
        ),
      );
      return;
    }
    if (t == null || t.status == DownloadStatus.done) return;
    t
      ..status = DownloadStatus.queued
      ..error = null;
    _save([t]);
    _pump();
  }

  void pauseAll() {
    for (final t
        in _tasks.values
            .where(
              (t) =>
                  t.status == DownloadStatus.running ||
                  t.status == DownloadStatus.queued,
            )
            .toList()) {
      pause(t.uid);
    }
  }

  void resumeAll() {
    for (final t
        in _tasks.values
            .where(
              (t) =>
                  t.status == DownloadStatus.paused ||
                  t.status == DownloadStatus.failed,
            )
            .toList()) {
      resume(t.uid);
    }
  }

  /// Deletes some chapters of a task; the task itself goes when nothing is left.
  Future<void> deleteChapters(String uid, List<String> chapterIds) {
    final deleting = _deletions[uid];
    if (deleting != null) {
      return deleting.then((_) => deleteChapters(uid, chapterIds));
    }
    final t = _tasks[uid];
    if (t == null || chapterIds.isEmpty) return Future.value();
    final unfinished = t.deletingChapters;
    if (unfinished != null) {
      if (unfinished.isEmpty) return delete(uid);
      chapterIds = {...unfinished, ...chapterIds}.toList();
      if (t.status == DownloadStatus.failed) {
        t.status = DownloadStatus.paused;
        t.error = null;
      }
    }
    if (t.chapters.every((c) => chapterIds.contains(c.id))) return delete(uid);
    // Stop the current writer while retaining the latest queued/paused intent.
    if (t.status == DownloadStatus.running) {
      t.status = DownloadStatus.queued;
      t.cancel?.cancel('chapters deleted');
    }
    late final Future<void> deletion;
    deletion = _deleteChapters(t, List.of(chapterIds))
        .catchError((Object error, StackTrace stack) {
          _deletionFailed(t, error);
          Error.throwWithStackTrace(error, stack);
        })
        .whenComplete(() {
          if (identical(_deletions[uid], deletion)) _deletions.remove(uid);
          _pump();
        });
    _deletions[uid] = deletion;
    return deletion;
  }

  Future<void> _deleteChapters(DownloadTask t, List<String> chapterIds) async {
    final pending = _runs[t];
    if (pending != null) await pending;
    if (!identical(_tasks[t.uid], t)) return;
    t.deletingChapters = chapterIds;
    await _writeTask(t, t.toJson());
    final owned = await _ownsDirectory(t);
    for (final id in chapterIds) {
      final relative = t.videoFiles[id];
      if (owned && relative != null) {
        final file = await _videoFile(t, relative);
        if (file != null && await file.exists()) await file.delete();
      }
      final dir = t.isVideo
          ? t.videoDirectory(id)
          : Directory(p.join(t.dir.path, safeFileName(id)));
      final root = p.normalize(p.absolute(t.dir.path));
      final target = p.normalize(p.absolute(dir.path));
      if (owned && p.isWithin(root, target) && await dir.exists()) {
        final actualRoot = await t.dir.resolveSymbolicLinks();
        final actual = await dir.resolveSymbolicLinks();
        if (p.equals(p.join(actualRoot, p.basename(target)), actual)) {
          await dir.delete(recursive: true);
        }
      }
    }
    final remaining = t.chapters
        .where((c) => !chapterIds.contains(c.id))
        .toList();
    final completed = t.completed.difference(chapterIds.toSet());
    final videoFiles = Map<String, String>.of(t.videoFiles)
      ..removeWhere((id, _) => chapterIds.contains(id));
    final json = t.toJson()
      ..remove('deletingChapters')
      ..['chapters'] = [
        for (final c in remaining) {'id': c.id, 'title': c.title},
      ]
      ..['completed'] = completed.toList()
      ..['bundleNodes'] = (Map<String, Map<String, dynamic>>.of(t.bundleNodes)
        ..removeWhere((id, _) => chapterIds.contains(id)))
      ..['videoFiles'] = videoFiles;
    await _writeTask(t, json);
    t.completed
      ..clear()
      ..addAll(completed);
    t.videoFiles
      ..clear()
      ..addAll(videoFiles);
    t.chapters.removeWhere((c) => chapterIds.contains(c.id));
    t.bundleNodes.removeWhere((id, _) => chapterIds.contains(id));
    t.deletingChapters = null;
    notifyListeners();
    // 删除期间暂停或补充下载的最新意图也必须持久化。
    await _writeTask(t, t.toJson());
  }

  Future<void> _writeTask(DownloadTask task, Map<String, dynamic> json) =>
      _writes.run(() async {
        await _db
            .into(_db.downloadTasks)
            .insertOnConflictUpdate(
              DownloadTasksCompanion.insert(
                uid: task.uid,
                source: task.item.source,
                json: jsonEncode(json),
                dir: task.dir.path,
                createdAt: task.createdAt.millisecondsSinceEpoch,
              ),
            );
      });

  void _deletionFailed(DownloadTask task, Object error) {
    task.status = DownloadStatus.failed;
    task.error = tr('删除失败，请重试');
    AppLog.error(error, event: 'download_delete');
    notifyListeners();
  }

  Future<void> _retryDeletion(DownloadTask task) =>
      task.deletingChapters!.isEmpty
      ? delete(task.uid)
      : deleteChapters(task.uid, List.of(task.deletingChapters!));

  /// Registers an already complete task (local imports).
  void addCompleted(DownloadTask t) {
    if (hasRestoreFailure(t.uid)) {
      throw SourceError('CONFIG', '下载记录恢复失败，请前往下载页处理');
    }
    _tasks[t.uid] = t;
    _save([t]);
  }

  Future<void> delete(String uid) {
    final pending = _deletions[uid];
    if (pending != null && _removing.contains(uid)) return pending;
    final t = _tasks[uid];
    _removing.add(uid);
    if (t != null) {
      t.status = DownloadStatus.paused;
      t.cancel?.cancel('download deleted');
    }
    late final Future<void> deletion;
    deletion =
        (pending == null
                ? _delete(uid, t)
                : pending
                      .then((_) {}, onError: (Object _) {})
                      .then((_) => _delete(uid, t)))
            .catchError((Object error, StackTrace stack) {
              if (t != null) _deletionFailed(t, error);
              Error.throwWithStackTrace(error, stack);
            })
            .whenComplete(() {
              _removing.remove(uid);
              if (identical(_deletions[uid], deletion)) _deletions.remove(uid);
              _pump();
            });
    _deletions[uid] = deletion;
    return deletion;
  }

  Future<void> _delete(String uid, DownloadTask? t) async {
    final pending = _runs[t];
    if (pending != null) await pending;
    if (t != null) {
      t.deletingChapters = [];
      await _writeTask(t, t.toJson());
    }
    if (t != null && await _ownsDirectory(t) && await t.dir.exists()) {
      await t.dir.delete(recursive: true);
    }
    final deletion = _writes.run(
      () =>
          (_db.delete(_db.downloadTasks)..where((r) => r.uid.equals(uid))).go(),
    );
    await deletion;
    if (identical(_tasks[uid], t)) _tasks.remove(uid);
    notifyListeners();
    _pump();
  }

  void _pump() {
    if (_disposed || !networkAllowed) return;
    for (final next
        in _tasks.values
            .where((t) => t.status == DownloadStatus.queued)
            .toList()) {
      final source = next.item.source;
      if (_active.containsKey(next.uid) ||
          _deletions.containsKey(next.uid) ||
          next.deletingChapters != null) {
        continue;
      }
      final slot = DownloadScheduler.instance.tryAcquire(source);
      if (slot == null) continue;
      _active[next.uid] = next;
      final run = _run(next).whenComplete(() {
        if (identical(_active[next.uid], next)) _active.remove(next.uid);
        _runs.remove(next);
        if (identical(_tasks[next.uid], next)) _save([next]);
        slot.release();
        _pump();
      });
      _runs[next] = run;
      unawaited(run);
    }
  }

  /// Deletion/writing requires the exact task identity below its recorded root,
  /// including the filesystem's resolved path rather than just string prefixes.
  Future<bool> _ownsDirectory(DownloadTask t, {bool create = false}) async {
    final target = p.normalize(p.absolute(t.dir.path));
    final source = p.dirname(target);
    final base = p.dirname(source);
    if (p.basename(target) != safeFileName(t.item.id) ||
        p.basename(source) != safeFileName(t.item.source) ||
        !p.isWithin(base, target)) {
      return false;
    }
    for (final other in _tasks.values) {
      if (identical(other, t)) continue;
      final path = p.normalize(p.absolute(other.dir.path));
      if (p.equals(path, target) ||
          p.isWithin(path, target) ||
          p.isWithin(target, path)) {
        return false;
      }
    }
    for (final path in [source, target]) {
      if (await FileSystemEntity.type(path, followLinks: false) ==
          FileSystemEntityType.link) {
        return false;
      }
    }
    if (create) await t.dir.create(recursive: true);
    if (!await t.dir.exists()) return true;
    final actualBase = await Directory(base).resolveSymbolicLinks();
    final actual = await t.dir.resolveSymbolicLinks();
    return p.equals(
      p.join(actualBase, safeFileName(t.item.source), safeFileName(t.item.id)),
      actual,
    );
  }

  Future<void> _run(DownloadTask t) async {
    final token = CancelToken();
    t
      ..status = DownloadStatus.running
      ..error = null
      ..cancel = token;
    notifyListeners();
    DownloadLease? lease;
    try {
      lease = await BackgroundDownloads.instance.acquire(cancelToken: token);
      t.lease = lease;
      lease.check();
      await awaitCancelled(SourceManager.instance.ready, token);
      _checkRunning(t, token);
      if (SourceManager.instance.manifest(t.item.source)?.isLive == true) {
        throw SourceError('UNSUPPORTED', '直播不支持下载，请使用录制');
      }
      if (!await _ownsDirectory(t, create: true)) {
        throw const FileSystemException('Invalid download directory identity');
      }
      _checkRunning(t, token);
      await File(p.join(t.dir.path, 'work.json'))
          .writeAsString(jsonEncode(t.item.toJson()));
      _checkRunning(t, token);
      if (t.isBundle) {
        await _runBundle(t, token);
      } else if (t.isVideo) {
        await _runVideo(t, token);
      } else if (t.isNovel) {
        await _runNovel(t, token);
      } else {
        await _runComic(t, token);
      }
      _checkRunning(t, token);
      t.status = t.chapters.every((c) => t.completed.contains(c.id))
          ? DownloadStatus.done
          : DownloadStatus.queued;
    } catch (e) {
      if (!identical(_tasks[t.uid], t) ||
          !identical(t.cancel, token) ||
          t.status != DownloadStatus.running) {
        return;
      }
      if (BackgroundDownloads.interruption(token.cancelError ?? e)
          case final stopped?) {
        t
          ..status = DownloadStatus.paused
          ..error = stopped.friendly;
        return;
      }
      if (!networkAllowed) {
        // Lost Wi-Fi with "Wi-Fi only" on: wait for it instead of failing.
        t.status = DownloadStatus.queued;
        return;
      }
      t
        ..status = DownloadStatus.failed
        ..error = e is SourceError ? e.friendly : e.toString();
    } finally {
      t.lease = null;
      await lease?.release();
    }
  }

  void _checkRunning(DownloadTask t, CancelToken token) {
    if (!networkAllowed && t.status == DownloadStatus.running) {
      t.status = DownloadStatus.queued;
      token.cancel('waiting for Wi-Fi');
    }
    if (!identical(_tasks[t.uid], t) ||
        !identical(t.cancel, token) ||
        t.status != DownloadStatus.running ||
        token.isCancelled) {
      if (!token.isCancelled) token.cancel('download stopped');
      throw token.cancelError!;
    }
  }

  Future<void> _runComic(DownloadTask t, CancelToken token) async {
    final sm = SourceManager.instance;
    // Resolve every chapter first so the progress total is known up front.
    final plans = <(Chapter, ChapterImages)>[];
    for (final c
        in t.chapters.where((c) => !t.completed.contains(c.id)).toList()) {
      _checkRunning(t, token);
      final chapterId = c.id == '_' ? null : c.id;
      plans.add((
        c,
        await awaitCancelled(
          sm.chapter(t.item.source, t.item.id, chapterId, cancelToken: token),
          token,
        ),
      ));
      _checkRunning(t, token);
    }
    t.total = plans.fold(0, (n, e) => n + e.$2.pages.length);
    t.done = 0;
    if (plans.isEmpty) return;
    _notifyProgress(t);
    for (final (chapter, images) in plans) {
      _checkRunning(t, token);
      final dir = Directory(p.join(t.dir.path, safeFileName(chapter.id)));
      if (await FileSystemEntity.type(dir.path, followLinks: false) ==
          FileSystemEntityType.link) {
        throw const FileSystemException('Invalid chapter directory');
      }
      await dir.create(recursive: true);
      _checkRunning(t, token);
      final pending = File(p.join(dir.path, 'pending.json'));
      await writeFileAtomic(
        pending,
        utf8.encode(
          jsonEncode({
            'pages': [
              for (final page in images.pages)
                {
                  'url': page.url,
                  'token': page.token,
                  'headers': page.headers,
                  'fallbacks': page.fallbacks,
                  'cacheKey': page.cacheKey,
                  'transform': page.transform,
                  'width': page.width,
                  'height': page.height,
                },
            ],
          }),
        ),
        canCommit: () {
          _checkRunning(t, token);
          return true;
        },
      );
      final manifest = <Map<String, dynamic>>[];
      final chapterId = chapter.id == '_' ? null : chapter.id;
      var next = 0;
      Future<void> worker() async {
        while (next < images.pages.length) {
          _checkRunning(t, token);
          final i = next++;
          final page = images.pages[i];
          final name = '${(i + 1).toString().padLeft(4, '0')}.img';
          final file = File(p.join(dir.path, name));
          if (!await file.exists() || await file.length() == 0) {
            final bytes = await ParkImage.page(
              t.item.source,
              t.item.id,
              chapterId,
              i,
              page,
            ).loadBytes(cancelToken: token, priority: ImagePriority.background);
            _checkRunning(t, token);
            final part = File('${file.path}.part');
            await part.writeAsBytes(bytes, flush: true);
            _checkRunning(t, token);
            await part.rename(file.path);
            t.bytes += bytes.length;
          }
          _checkRunning(t, token);
          manifest.add({
            'index': i,
            'file': name,
            if (page.transform != null) 'transform': page.transform,
            'width': page.width,
            'height': page.height,
          });
          t.done++;
          _notifyProgress(t);
        }
      }

      Object? firstError;
      StackTrace? firstStack;
      Future<void> guardedWorker() async {
        try {
          await worker();
        } catch (error, stack) {
          // 首个失败立即停止同任务的其他页；Future.wait 仍等待它们退出后归还额度。
          // 保留首个原因，避免并发页继续联网或用取消错误覆盖原始错误。
          firstError ??= error;
          firstStack ??= stack;
          if (!token.isCancelled) token.cancel(error);
          rethrow;
        }
      }

      try {
        await Future.wait(
          List.generate(
            AppSettings.instance.downloadConcurrency.clamp(1, 8),
            (_) => guardedWorker(),
          ),
        );
      } catch (_) {
        Error.throwWithStackTrace(firstError!, firstStack!);
      }
      _checkRunning(t, token);
      manifest.sort((a, b) => (a['index'] as int).compareTo(b['index'] as int));
      final file = File(p.join(dir.path, 'pages.json'));
      await writeFileAtomic(
        file,
        utf8.encode(jsonEncode({'title': chapter.title, 'pages': manifest})),
        canCommit: () {
          _checkRunning(t, token);
          return true;
        },
      );
      t.completed.add(chapter.id);
      if (await pending.exists()) await pending.delete();
      _save([t]);
    }
  }

  Future<void> _runNovel(DownloadTask t, CancelToken token) async {
    t.total = t.chapters.length;
    t.done = t.completed.length;
    for (final chapter in t.chapters.toList()) {
      _checkRunning(t, token);
      if (t.completed.contains(chapter.id)) continue;
      final body = await awaitCancelled(
        SourceManager.instance.textChapter(
          t.item.source,
          t.item.id,
          chapter.id == '_' ? null : chapter.id,
          cancelToken: token,
        ),
        token,
      );
      _checkRunning(t, token);
      final dir = Directory(p.join(t.dir.path, safeFileName(chapter.id)));
      if (await FileSystemEntity.type(dir.path, followLinks: false) ==
          FileSystemEntityType.link) {
        throw const FileSystemException('Invalid chapter directory');
      }
      await dir.create(recursive: true);
      final bytes = utf8.encode(jsonEncode(body.toJson()));
      await writeFileAtomic(
        File(p.join(dir.path, 'text.json')),
        bytes,
        canCommit: () {
          _checkRunning(t, token);
          return true;
        },
      );
      _checkRunning(t, token);
      t.completed.add(chapter.id);
      t.done++;
      t.bytes += bytes.length;
      _notifyProgress(t);
      _save([t]);
    }
  }

  Future<TextChapter?> localTextChapter(
    String source,
    String id,
    String? chapterId,
  ) async {
    final t = task('$source:$id');
    final key = chapterKeyOf(chapterId);
    if (t == null ||
        !t.isNovel ||
        !t.completed.contains(key) ||
        !await _ownsDirectory(t)) {
      return null;
    }
    final file = File(p.join(t.dir.path, safeFileName(key), 'text.json'));
    if (!await file.exists()) return null;
    final actualRoot = await t.dir.resolveSymbolicLinks();
    if (!p.isWithin(actualRoot, await file.resolveSymbolicLinks())) return null;
    try {
      final json = jsonDecode(await file.readAsString());
      if (json is! Map) return null;
      return TextChapter.fromJson(json.cast<String, dynamic>());
    } on FormatException {
      return null;
    } on SourceError {
      return null;
    } on FileSystemException {
      return null;
    }
  }

  Future<void> _runBundle(DownloadTask task, CancelToken token) async {
    task.total = task.chapters.length * 1000;
    task.done = 0;
    task.bytes = 0;
    for (final chapter in task.chapters.toList()) {
      _checkRunning(task, token);
      final directory = Directory(
        p.join(task.dir.path, safeFileName(chapter.id)),
      );
      final before = task.done;
      final priorBytes = task.bytes;
      var lastNotify = DateTime.now();
      await OfflineBundle.download(
        task.item,
        directory,
        node: task.bundleNodes[chapter.id],
        cancelToken: token,
        onProgress: (done, total, bytes) {
          _checkRunning(task, token);
          task.done =
              before + (total > 0 ? (done * 1000 ~/ total).clamp(0, 999) : 0);
          task.bytes = priorBytes + bytes;
          final now = DateTime.now();
          if (now.difference(lastNotify).inMilliseconds >= 300 ||
              done == total) {
            lastNotify = now;
            _notifyProgress(task);
          }
        },
      );
      _checkRunning(task, token);
      task.completed.add(chapter.id);
      task.done = before + 1000;
      _save([task]);
    }
  }

  Future<OfflineBundle?> localBundle(
    String source,
    String id,
    String chapterId,
  ) async {
    final task = _tasks['$source:$id'];
    if (task == null || !task.isBundle || !await _ownsDirectory(task)) {
      return null;
    }
    final manifest = await task.chapterFile(chapterId, 'bundle.json');
    return manifest == null ? null : OfflineBundle.read(manifest);
  }

  Future<({File file, String format})?> localBundleResource(
    String source,
    String id,
    String assetId,
  ) async {
    final task = _tasks['$source:$id'];
    if (task == null || !task.isBundle) return null;
    for (final chapter in task.chapters) {
      final bundle = await localBundle(source, id, chapter.id);
      final entry = bundle?.entries
          .where((e) => e['id'] == assetId)
          .firstOrNull;
      if (entry == null) continue;
      final file = await bundle!.file(entry);
      if (file != null) {
        return (file: file, format: entry['format']?.toString() ?? '');
      }
    }
    return null;
  }

  Future<void> _runVideo(DownloadTask t, CancelToken token) async {
    t.total = t.chapters.length * 1000;
    t.done = 0;
    t.bytes = 0;
    for (var index = 0; index < t.chapters.length; index++) {
      _checkRunning(t, token);
      final episode = t.chapters[index];
      final local = await localVideo(
        t.item.source,
        t.item.id,
        episodeId: episode.id,
      );
      _checkRunning(t, token);
      if (local != null) {
        t.done += 1000;
        t.bytes += await offlineMediaBytes(local);
        continue;
      }
      t.completed.remove(episode.id);
      t.videoFiles.remove(episode.id);
      final sources = await awaitCancelled(
        SourceManager.instance.videos(
          t.item.source,
          t.item.id,
          episodeId: episode.id,
          cancelToken: token,
        ),
        token,
      );
      _checkRunning(t, token);
      if (sources.isEmpty) throw SourceError('NOT_FOUND', '视频站点未加载');
      final src =
          t.videoSelection?.resolve(sources, episodeId: episode.id) ??
          sources.firstWhere(
            (s) => t.videoQuality != 0 && s.quality == t.videoQuality,
            orElse: () => sources.firstWhere(
              (s) => s.preferred,
              orElse: () => sources.first,
            ),
          );
      // Preserve the single-video output location so existing validated HLS parts remain reusable.
      final directory = t.videoDirectory(episode.id);
      await directory.create(recursive: true);
      _checkRunning(t, token);
      final extension = downloadMediaExtension(src);
      final file = File(
        p.join(directory.path, 'video_${src.quality}p.$extension'),
      );
      final beforeDone = t.done;
      final beforeBytes = t.bytes;
      var lastNotify = DateTime.now();
      void progress(int done, int total, int bytes) {
        if (token.isCancelled || !identical(_tasks[t.uid], t)) return;
        t.total = t.chapters.length * 1000;
        t.done =
            beforeDone + (total > 0 ? (done * 1000 ~/ total).clamp(0, 999) : 0);
        t.bytes = beforeBytes + bytes;
        if (DateTime.now().difference(lastNotify).inMilliseconds > 300) {
          lastNotify = DateTime.now();
          _notifyProgress(t);
        }
      }

      final manifest = SourceManager.instance.manifest(t.item.source);
      if (manifest == null) throw SourceError('CONFIG', '视频站点未加载');
      await downloadMedia(
        manifest,
        src,
        file,
        cancelToken: token,
        onProgress: progress,
      );
      _checkRunning(t, token);
      t.videoFiles[episode.id] = p.relative(file.path, from: t.dir.path);
      t.completed.add(episode.id);
      t.bytes = beforeBytes + await offlineMediaBytes(file);
      t.done = beforeDone + 1000;
      _save([t]);
    }
    t.total = t.chapters.length * 1000;
  }

  static Future<File?> _videoFile(DownloadTask task, String relative) async {
    if (p.isAbsolute(relative)) return null;
    final root = p.normalize(p.absolute(task.dir.path));
    final target = p.normalize(p.join(root, relative));
    if (!p.isWithin(root, target) ||
        !const {
          '.mp4',
          '.m3u8',
          '.webm',
          '.mkv',
          '.mov',
          '.mp3',
          '.m4a',
          '.aac',
          '.wav',
          '.flac',
          '.ogg',
          '.opus',
        }.contains(p.extension(target).toLowerCase())) {
      return null;
    }
    final file = File(target);
    if (!await file.exists() || await file.length() == 0) return null;
    final actualRoot = await task.dir.resolveSymbolicLinks();
    final actual = await file.resolveSymbolicLinks();
    if (!p.isWithin(actualRoot, actual)) return null;
    if (file.path.endsWith('.m3u8')) {
      try {
        await LocalHlsMedia(file).files();
      } on SourceError {
        return null;
      } on FileSystemException {
        return null;
      }
    }
    return file;
  }

  /// 完整本地章节；允许未完成时按原序号合并已落盘图片和待下载页面。
  Future<List<PageImage>?> localChapter(
    String source,
    String id,
    String? chapterId, {
    bool allowIncomplete = false,
  }) async {
    final t = _tasks['$source:$id'];
    if (t == null || !await _ownsDirectory(t)) return null;
    final chapter = chapterId ?? '_';
    final f = await t.chapterFile(chapter, 'pages.json');
    if (f == null) {
      if (!allowIncomplete) return null;
      final pending = await t.chapterFile(chapter, 'pending.json');
      if (pending == null) return null;
      Map json;
      try {
        json = jsonDecode(await pending.readAsString()) as Map;
      } on FileSystemException {
        // 章节可能刚好完成：写入完整清单后会删除临时清单。
        return localChapter(source, id, chapterId);
      } on FormatException {
        return null;
      }
      final result = <PageImage>[];
      for (final (index, entry) in (json['pages'] as List).indexed) {
        final page = (entry as Map).cast<String, dynamic>();
        final local = await t.chapterFile(
          chapter,
          '${(index + 1).toString().padLeft(4, '0')}.img',
        );
        result.add(
          PageImage({
            ...page,
            if (local != null && await local.length() > 0)
              'url': local.uri.toString(),
          }),
        );
      }
      return result;
    }
    final data = jsonDecode(await f.readAsString()) as Map;
    final result = <PageImage>[];
    for (final e in (data['pages'] as List).cast<Map>()) {
      final m = e.cast<String, dynamic>();
      final file = await t.chapterFile(chapter, m['file'] as String);
      if (file == null) return null;
      result.add(PageImage({...m, 'url': file.uri.toString()}));
    }
    return result;
  }

  Future<File?> localVideo(
    String source,
    String id, {
    String? episodeId,
  }) async {
    final t = task('$source:$id');
    if (t == null) return null;
    if (t.isBundle && episodeId != null) {
      return (await localBundleResource(source, id, episodeId))?.file;
    }
    final key = chapterKeyOf(episodeId);
    if (!t.completed.contains(key)) return null;
    final relative = t.videoFiles[key];
    return relative == null ? null : _videoFile(t, relative);
  }

  /// A detail built from what was downloaded, so offline users can still open and read a work.
  WorkDetail? offlineDetail(String source, String id) {
    final t = _tasks['$source:$id'];
    if (t == null || (t.status != DownloadStatus.done && t.completed.isEmpty)) {
      return null;
    }
    final single = t.chapters.length == 1;
    return WorkDetail({
      ...t.item.json,
      'id': t.item.id,
      'chaptersComplete': false,
      'chapters': single && !t.isVideo
          ? null
          : [
              for (final c in t.chapters) {'id': c.id, 'title': c.title},
            ],
      'singleChapterId': single && t.chapters.first.id != '_'
          ? t.chapters.first.id
          : null,
    }, source);
  }

  bool isChapterDownloaded(String uid, String chapterId) =>
      _tasks[uid]?.completed.contains(chapterId) ?? false;

  /// Queues new chapters found by a library update (auto-download).
  void enqueueNewChapters(WorkItem item, List<Chapter> chapters) {
    if (chapters.isEmpty) return;
    if (SourceManager.instance.manifest(item.source)?.isPlayable == true) {
      enqueueVideo(
        item,
        chapters,
        selection: _tasks[item.uid]?.videoSelection,
        quality: _tasks[item.uid]?.videoQuality ?? 0,
      );
    } else {
      enqueue(item, chapters);
    }
  }
}
