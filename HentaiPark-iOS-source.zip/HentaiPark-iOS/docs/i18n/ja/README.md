[简体中文](../../../README.md) · [繁體中文](../zh-Hant/README.md) · [日本語](README.md) · [한국어](../ko/README.md) · [English](../en/README.md) · [Español](../es/README.md) · [Русский](../ru/README.md) · [العربية](../ar/README.md)

<p align="center"><img src="../../images/banner.svg" alt="HentaiPark · 18+" width="100%"></p>

<p align="center"><strong>成人向けコンテンツをひとつに。探す、読む、観る、集める。</strong></p>

<p align="center">同人誌、成人アニメ、JAV、写真集、動画、小説、ゲームを横断して、お気に入りの続きを楽しめます。</p>

<p align="center">
  <a href="https://github.com/drdon1234/Hentai-Park/releases/latest"><img src="https://img.shields.io/github/v/release/drdon1234/Hentai-Park?label=Download&amp;color=C96442" alt="Download"></a>
  <img src="https://img.shields.io/badge/18%2B-Adult_content-C96442" alt="18+">
  <img src="https://img.shields.io/badge/Android_7.0%2B-333333" alt="Android 7.0+">
</p>

<p align="center"><a href="https://github.com/drdon1234/Hentai-Park/releases/latest">ダウンロード</a> · <a href="#screenshots">紹介動画</a> · <a href="#features">機能</a> · <a href="#faq">FAQ</a> · <a href="https://github.com/drdon1234/Hentai-Park/issues">フィードバック</a></p>

> **18+** 現地の法律で認められる成人のみ利用できます。コンテンツは第三者サイトから取得し、HentaiPark は配信元のコンテンツをホストしません。

## ダウンロードと対応環境

**[ダウンロード](https://github.com/drdon1234/Hentai-Park/releases/latest)**

**Android 7.0+**

[対応環境とインストール](../../PLATFORMS.md)

デスクトップやモバイルのブラウザーから使える [Web のセルフホスト（Beta）](../../WEB_DEPLOYMENT.md)も利用できます。Web は Beta 段階で、使い勝手を引き続き改善しています。各インスタンスは1人用で、リモートアクセスには HTTPS とアクセス用の認証情報が必要です。Web と Android のデータは独立しており、相互の同期やバックアップの取り込みには対応していません。

<a id="screenshots"></a>

## 製品紹介

https://github.com/user-attachments/assets/d648927a-e4d6-48e8-b8c0-b77349ffd607

## はじめ方

1. 「見つける」でカテゴリとサイトを選ぶか、作品、タグ、リンク、品番で検索します。
2. 作品を開いて読む・観る。気に入った作品は「お気に入り」に追加し、オフライン用にダウンロードできます。
3. ホームの「続きから → すべて」で再開し、「お気に入り → 更新」で新しい章を確認します。

必要に応じて「その他 → サイト」でログイン、「その他 → ネットワーク」でプロキシを設定します。

<a id="features"></a>

## 主な機能

| 機能 | できること |
| --- | --- |
| 発見と検索 | 二次元・三次元とメディア種別で絞り込み、複数サイトを検索。リンクや品番から作品へ移動できます。 |
| 読む・観る | 画像付き記事と動画。漫画のスクロール、ページ送り、見開き。動画のエピソード選択、速度変更、続き再生。小説のしおり、注釈、読み上げ。 |
| お気に入りと更新 | グループ整理、進捗保存、新章確認。作者、チャンネル、キーワードを購読できます。 |
| オンラインゲーム | インストール不要のブラウザゲーム。全画面と仮想キーを切り替えられます。 |
| オフラインと書き出し | 漫画、動画、音声、小説、投稿・記事の添付ファイル、ゲームのリソースをダウンロード。CBZ の入出力、完了済み写真集の章を PDF に書き出せます。 |
| ランキングと画像検索 | 同人誌、成人アニメ、JAV のランキングや、画像を使った作品候補の検索。 |
| 作品情報 | 作品情報の閲覧・検索・絞り込み、ランキングの原サイト詳細、詳細・検索サイトの選択。 |
| コメントとライブチャット | 対応サイトのコメント、返信、画像を読み、対応ライブ配信で弾幕を表示します。 |
| 翻訳とフィルター | タイトル、章名、説明、タグ、コメント、本文、テキスト字幕、弾幕を翻訳。現在の言語の辞書を優先し、タグでコンテンツを非表示にできます。 |
| プライバシーとバックアップ | アプリロック、シークレット閲覧、カバーのぼかし、対応環境での画面キャプチャ防止。お気に入り、進捗、購読、設定をバックアップします。 |

## 対応サイトとサービス

[対応サイト一覧・ランキング・画像検索サービスを見る](SITES.md)

<a id="faq"></a>

## 制限と FAQ

酒場には自分の OpenAI 互換 AI サービスが必要です。メッセージ、キャラクター設定、ユーザーペルソナと一致した世界設定をサービスへ送信し、料金が発生する場合があります。対応ルールと読み込み・書き出しは[サイトとサービス](SITES.md)をご覧ください。保存済みリソースと会話は暗号化されない書庫バックアップに含まれ、AI 設定とキーは含まれません。

閲覧、再生、コメント、購読、ダウンロードの対応はサイトごとに異なります。アプリ内の表示を確認してください。サイト更新にはアプリの更新が必要な場合があります。

画像検索では選択したサービスに画像を送信します。端末内の画像検索履歴は暗号化されません。手動ログインではパスワードと Cookie が表示されるため、画面共有にご注意ください。

**サイトやコンテンツにアクセスできない場合は？**

接続を確認し、案内に従ってログイン、年齢確認、サイト認証を行ってください。地域によって VPN やプロキシが必要です。内容と利用権限は配信元が管理します。 対応する誕生日確認は、端末内で成人確認済みの場合に限り固定日付 1999-12-31 を使用し、実際の誕生日は読み取りません。

**コメントや弾幕を送信できますか？**

コメント、返信、ライブ弾幕は閲覧専用です。ゲームのリンク解放に返信が必要な場合は、内容を表示し、確認後にのみ送信します。

**お気に入りと進捗を保存するには？**

「その他 → バックアップ」で .parkbak を保存・復元します。復元はデータを統合し、ダウンロード済みファイルは含みません。Cookie などのサイトのログイン・確認状態は任意で保存でき、別の端末でも利用できます。有効期限切れや端末に紐づくセッションは再確認が必要な場合があります。バックアップは暗号化されません。安全に保管してください。 オンラインゲームのセーブデータは .parkbak に含まれません。ゲーム内の個別入出力は localStorage のみで、IndexedDB は含まれず、出力ファイルは暗号化されません。

**問題を報告するには？**

Issues にバージョン、サイト、再現手順を記載してください。アカウント、Cookie、Token、バックアップ、署名付き URL 全体は公開しないでください。

[ログガイド](DIAGNOSTICS.md)

## Star History

<a href="https://www.star-history.com/#drdon1234/Hentai-Park&amp;Date">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/svg?repos=drdon1234/Hentai-Park&amp;type=Date&amp;theme=dark">
    <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/svg?repos=drdon1234/Hentai-Park&amp;type=Date">
    <img alt="日付ごとの Star 数" src="https://api.star-history.com/svg?repos=drdon1234/Hentai-Park&amp;type=Date">
  </picture>
</a>

---

[AGPL-3.0 · ライセンス](../../../LICENSE) · [第三者表記](../../licenses/README.md) · [対応環境](../../PLATFORMS.md)
