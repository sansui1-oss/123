[简体中文](../../SOURCE_API.md) · [繁體中文](../zh-Hant/SOURCE_API.md) · [日本語](SOURCE_API.md) · [한국어](../ko/SOURCE_API.md) · [English](../en/SOURCE_API.md) · [Español](../es/SOURCE_API.md) · [Русский](../ru/SOURCE_API.md) · [العربية](../ar/SOURCE_API.md)

# サイトプラグイン API

[クイックスタート](#クイックスタート) · [manifest のフィールド](#manifest-のフィールド) · [メソッド](#メソッド) · [ランタイム API](#ランタイム-api) · [エラーコード](#エラーコード) · [多言語対応](#多言語対応) · [公開](#公開)

HentaiPark の各サイトは独立した JavaScript プラグインです。アプリは実行時にプラグインを読み込み、リポジトリからのインストール、更新、有効化・無効化が **アプリを再ビルドせずに** できます。公式プラグインは [`assets/sources/`](../../../assets/sources/) にあり、そのまま例として参考にできます。

本書は簡体字中国語版が正です。サイト固有のルールはプラグインに置き、通信・キャッシュ・画像の共通機能はフレームワークが提供します。フレームワークはサイト名で特別扱いをしません。

## クイックスタート

### 実行環境

- プラグインはアプリ内のヘッドレス WebView で動作し、最新の JS と `DOMParser` が使えます。ネイティブ層が暗号処理、Cookie、ネイティブ HTTP を提供します。ネイティブ HTTP に CORS 制限はなく、ブラウザ通信とメディアは後述の規則に従います。
- 各プラグインのランタイムはサイトが初めて使われたときに起動し、約 5 分使われないか、同時に 6 個を超えると解放されます。manifest は「スクリプトの SHA-256 + ランタイムのバージョン」でキャッシュされるため、アプリ起動時にプラグインは実行されません。起動直後からプラグインが動いている前提にしないでください。
- 同じランタイム（[`assets/runtime/park_runtime.js`](../../../assets/runtime/park_runtime.js)）は Node でも動くので、開発中に実サイトで動作確認できます。Node ホストは開発用で、信頼できないスクリプトのサンドボックスではありません。

### 最小のプラグイン

```js
Park.register({
  key: 'mysite',
  name: '我的站点',
  version: '0.0.1',
  minAppVersion: '0.9.2',
  type: 'comic',
  category: 'doujin',
  homepage: 'https://example.com',
  domains: ['example.com'],
  defaultFeed: 'popular',
  feeds: [{ key: 'popular', label: '热门' }],

  async feed(key, { page }) {
    const doc = Park.html.parse(await this.http.text(`https://example.com/popular?page=${page}`));
    return {
      items: [...doc.querySelectorAll('.gallery')].map((el) => ({
        id: el.dataset.id,
        title: Park.html.text(el.querySelector('.title')),
        cover: el.querySelector('img').src,
      })),
      hasNext: !!doc.querySelector('.next'),
    };
  },
  async detail(id) { /* … */ },
  async chapter(id, chapterId) { /* … */ },
});
```

### Node で試す

Use a temporary ignored local validation script; verify the relevant source flows with real requests.

```js
import { loadSource } from '../tools/source-runner/host.mjs';
const { manifest } = await loadSource('nhentai.js');
console.log(manifest.key, manifest.version);
```

```powershell
npm ci --prefix 'tools/source-runner'
node <local-validation-script>
```

## manifest のフィールド

プレビュー専用作品を返すプラグインだけが `previewContent: true` を宣言します。ランタイムは `capabilities.previewContent` として公開し、サイト・検索・購読画面のプレビューフィルターを制御します。通常のサムネイルは対象外です。未宣言の場合、ボタンは表示しません。

```js
Park.register({
  key: 'mysite',              // 一意で変更不可。[A-Za-z0-9_-] のみ、1〜100 文字、_app は不可
  name: '我的站点',
  version: '0.0.1',
  minAppVersion: '0.9.2',           // 3 つの数字。リポジトリの方が新しいと更新を案内
  type: 'comic',              // comic | video | voice | novel | tavern | game | article：コンテンツの動作を決める
  category: 'doujin',         // doujin | anime | aiDrama | jav | adult | asmr | shortvideo | recording | live | gallery | illustration | novel | tavern | game | other
  color: '#E5355F',           // ブランドカラー：サイトのアイコンとサイトページ
  description: '一句话介绍',
  homepage: 'https://example.com',
  domains: ['example.com'],                   // 所属サイト。「分離とセキュリティ」参照。省略時は homepage などから推定
  linkPatterns: ['example\\.com/g/(\\d+)'],   // 貼り付けたリンクで作品を直接開く。1 番目のグループが作品 ID
  idPattern: '^(\\d+)$',                      // 入力した ID で作品を直接開く
  imageHeaders: { Referer: 'https://example.com/' },  // 表紙と画像の既定ヘッダー
  network: { mode: 'auto', vpnHint: true },  // 「ネットワーク」参照
  media: { mode: 'browser', origin: 'https://example.com', domains: ['media.example.com'] },  // 動画と直接ファイル用のメディア権限
  imageNetwork: { mode: 'browser', origin: 'https://img.example.com', domains: ['img.example.com'] }, // 任意
  imageDecrypt: { /* 任意。「暗号化画像」参照 */ },

  settings: [ /* オプション。「オプション定義」参照 */ ],
  account: { /* 任意。「アカウント」参照 */ },
  defaultFeed: 'ranking',     // サイトページで最初に開くタブ（feeds の key）
  feeds: [ /* サイトページのタブ */ ],
  searchFilters: [ /* 検索フィルター */ ],
  searchHint: '搜索技巧提示',
  i18n: { /* プラグイン独自の UI 翻訳。「多言語対応」参照 */ },

  subscription: { /* 任意：チャンネル・クリエイターの購読。「購読」参照 */ },
  postShortVideos: true,
  updateSubscriptions: { /* 任意：更新の購読。「更新の購読」参照 */ },

  async init() {},              // 任意：ランタイム起動時に 1 回呼ばれる（ドメイン一覧の更新など）
  async onSettingsChanged() {}, // 任意：ユーザーがサイト設定を変えた後に呼ばれる
  // ほかに「メソッド」の各メソッド
});
```

機能（`capabilities`）は実装されたメソッドからランタイムが自動で出力します。手書きしないでください。

### 種類と分類

`type` は作品の読み方・再生・ゲームリソースの扱いを、`category` は「見つける」、サイト管理、検索での分類を決めます。不明または未宣言の分類は「その他」になります。新しいサイトは種類、分類、機能を正確に宣言してください。

| 分類 | 内容 |
| --- | --- |
| `doujin` | 同人誌と漫画 |
| `gallery` | 三次元美図：コスプレ、写真、実写の画像集. 画像サイトは `type: 'comic'` を宣言し、1 つの画像集が 1 作品です。`chapter()` が順に画像を返し、閲覧・お気に入り・ダウンロードを共用します。枚数や過激さでは分類しません |
| `illustration` | 二次元美図：イラスト、アニメの画像集. 画像サイトは `type: 'comic'` を宣言し、1 つの画像集が 1 作品です。`chapter()` が順に画像を返し、閲覧・お気に入り・ダウンロードを共用します。枚数や過激さでは分類しません |
| `anime` | 成人向けアニメ |
| `aiDrama` | AI ショートドラマ。旧 `drama` は受け付けません。サイト自身のチャンネル名はそのまま宣言し、アプリの分類で絞り込むことはしません |
| `jav` | JAV 専門サイト |
| `adult` | 総合成人向け動画（Pornhub、XVideos、91porn など）、`type: 'video'`。分類はグループ分けで、サイトのタグやユーザーの絞り込みの代わりにはなりません |
| `shortvideo` | ショート動画：全画面の縦スクロールフィード（後述） |
| `recording` | 録画アーカイブ（オンデマンド）、`type: 'video'` |
| `live` | ライブ配信, `type: 'video'` |
| `asmr` | 音声作品と ASMR 動画。フォルダー型は `type: 'voice'`、動画型は `type: 'video'` も使用可能 |
| `novel` | 小説、`type: 'novel'` |
| `tavern` | キャラクターカードと世界設定集、`type: 'tavern'` |
| `game` | ゲーム情報とダウンロード資料、`type: 'game'` |
| `onlineGame` | オンラインゲーム、`type: 'game'` |
| `other` | クリエイターコミュニティ |

- **ショート動画**（`type: 'video', category: 'shortvideo'`）：作品、検索、お気に入り、履歴からフィードに直接入ります。1 作品が 1 本の動画で、`videos(id, '_')` が現在のメディアを返し、詳細ページは不要です。`feed` の `hasNext` と `cursor` で終わり付近を自動ページングします。カーソルに認証情報やメディア署名を入れてはいけません。更新すると 1 ページ目から始まり、表示中の 1 本を再生、次の 1 本を一時停止で先読みし、ほかは解放します。検索がないサイトは `search` を宣言しません。
- **投稿動画モード**（`postShortVideos: true`）：サイトと購読対象のページで `media[]` の動画添付を個別に再生します。動画には直接の `url` または空でない `episodeId` が必要です。遅延解決は再生・先読み時に `videos(元の投稿 ID, episodeId)` を呼び、Web ページをメディア URL として扱いません。画像は再生対象外で、添付は `preview`、`format`、`headers` に対応します。ページ送りと更新は現在の feed、絞り込み、対象の `subscription.posts` の範囲を維持します。再生は添付ごとに識別し、お気に入り・履歴・原サイトでの操作は元の投稿 ID を使います。分類は変わらず、独立したランダム動画 API を意味しません。
- **元サイトでしか再生できないまとめサイト**：`type: 'video', category: 'adult'` を宣言したまま、検証済みのメディア API がなければ `videos` を実装せず、ランタイムは `capabilities.videos: false` を出力します。詳細ページのメインボタンは `detail.url` をシステムブラウザで開き、再生・ダウンロード・エピソードは非表示、架空の章の保存や章の更新確認はしません。お気に入りと履歴は使えます。
- **小説** と **ゲーム** は「メソッド」で説明します。

`defaultFeed` は **おすすめ > ランキング > 人気** の順で選び、どれもない場合だけ最新ページなどの有効な入口を使います。検証していない API を作ってはいけません。未指定や不明な key の場合、アプリは key から自動で選びます（`promote` / `recommend` / `featured`、次に `rank` / `toplist`、次に `popular` / `hot` / `trending`）。どれもなければ最初のタブです。

匿名アクセスは可能でもおすすめにログインが必要なソースは `anonymousDefaultFeed: 'ranking'` を宣言します。`feeds` 内で匿名アクセスを実際に確認した項目を指定し、ランキングを優先します。ホームとサイト画面では未ログイン時にこの項目、ログイン時に `defaultFeed` を使用し、ユーザーが明示的に選んだタブは保持します。空の一覧やネットワークエラーをすべて未ログインと判断しないでください。

### オプション定義

`feeds[].options`、`searchFilters`、`settings` は同じ形式です。

```js
{ key: 'sort', label: '排序', type: 'select', default: 'date',
  values: [{ value: 'date', label: '最新' }, { value: 'popular', label: '热门', color: '#f00' }] }
// type：select | multi | number | text | password | switch
// settings では values の代わりに options も使える
```

`feeds` の各項目はサイトページのタブです：`{ key, label, options?: [...] }`。

### 共通フィルターと並べ替え

プラグインは Feed ごとに `commonFilters`、検索用に `searchCommonFilters` を宣言します。アプリは宣言された操作だけを表示し、読み込み済みの作品情報から近似フィルターを行いません。プラグインは条件を実際のサイト検索に対応付け、ページを移動しても条件を保持する必要があります。
閲覧時のフィルターシートでは Feed 固有の項目を先に表示します。全 Feed が完全に同じ共通フィルター機能を宣言した場合は、その機能を下部のサイト共通欄に表示します。Feed ごとに異なる機能は固有項目として扱います。プラグインは実際のサイト検索で対応している条件だけを宣言してください。

```js
feeds: [{ key: 'latest', label: '最新', commonFilters: {
  pages: { range: ['min'], sort: ['asc', 'desc'] },
  likes: { range: true, sort: ['desc'] },
  duration: { range: ['min', 'max'] },
} }],
searchCommonFilters: { pages: { range: ['min', 'max'] } },
```

対象は `pages` / `likes` / `duration` / `score` / `favorites` です。`range: true` は `min` と `max` の両方を有効にし、配列では対応する境界だけを宣言できます。`sort: true` は `asc` と `desc` を有効にし、配列ではサイトが対応する方向を列挙します。ページ数といいね数は 0 以上の整数、時間は秒数です。`feed` または `search` のリクエストに独立した `common` マップを渡します（例：`{ pages: { min: 10, order: 'desc' } }`）。空の境界と並べ替えは省略され、上下どちらかの境界だけでも指定できます。同時に並べ替えられる次元は 1 つです。サイトが実際に対応する能力だけを宣言し、未宣言の次元は拒否してください。

`score` は負数も含むサイトの整数スコア、`favorites` は 0 以上のお気に入り数です。星評価やいいね数とは別です。サイトが対応する境界だけを宣言し、取得済みの結果を近似フィルタリングしないでください。 いずれかを宣言するプラグインは、条件を完全に表示できない旧版へのインストールを防ぐため、`minAppVersion` を `0.10.5` 以上にしてください。

### 動的・連動フィルター

`feeds[].options` と `searchFilters` の単一選択項目は `dynamic: true, values: []` を宣言できます。動的な子項目は `dependsOn: ['range']` で同じグループの親を参照します。key は一意、依存先は存在し循環しないことが必要です。依存関係を宣言できるのは動的項目のみです。

`filterOptions(request)` は候補配列を返します。要求には `scope: 'feed' | 'search'`、`filter`、`values` を含め、一覧には `feed`、検索には任意で `keyword` を渡します。`values` は宣言した直接の親のみで、アカウント情報、設定、他の条件は含めません。親が未選択または空なら子を読み込みません。

検索語に依存する候補は `keywordDependent: true` を宣言します。検索語の変更でその項目と子孫をリセットし、他の条件は保持します。`values` の親の値は文字列・数値・真偽値のみで、複数選択の配列は渡せません。取得した名称は固定UI文言ではなく、コンテンツやタグの翻訳機能を利用できます。

候補は最大500件の `{value, label, color?}` です。value は一意の文字列または有限数、label は空でなく制御文字を含まない256文字以内の原サイト名、color は6桁の16進数です。大きな目録は分割して連動させ、黙って切り捨てません。取得した候補名は自動翻訳しません。

選択値は `feed` の `options`、`search` の `filters` で渡します。プラグインは目録への所属を検証し、ページ送りでも条件を保持します。解析失敗は例外にします。アプリはサイト、一覧/検索、一覧キーまたは検索語、親の値ごとに2分間キャッシュします。親の変更で子の選択と古い応答を破棄し、失敗時は再試行できます。

各ドメインのプラグインは自サイトの目録のみを読み取ります。同ブランドの別ドメイン間でプラグインを呼び出したりCookieを共有しません。共通解析はビルド時のテンプレートで再利用し、独立スクリプトを生成します。生成は `node tools/build_catalog_sources.mjs`、整合性確認は `--check` を使います。

```js
{key: 'category', label: '分类', type: 'select', default: '',
 dynamic: true, dependsOn: ['range'], values: []}

async filterOptions({scope, feed, filter, keyword, values}) {
  return [{value: 'site-category-id', label: 'Site category'}];
}
```

### ネットワーク

- `network.mode: 'auto'`（既定）：まずネイティブ HTTP を使います。本文のない同一オリジン HTTPS GET / HEAD が Cloudflare チャレンジ、HTTP 403・429、または回復可能な接続エラーを受けた場合は、ブラウザで 1 回再試行します。DNS、TLS、タイムアウト、レスポンスストリーム、通常の 5xx は追加の遅延を避けるためブラウザを起動しません。対象はサイトの宣言済みドメイン内に限られ、同一オリジンとリダイレクトの制限は維持されます。
- `network.mode: 'native'`: 永続 Cookie と設定済みプロキシでネイティブ HTTP を使用します。Cloudflare を検出した場合は `CLOUDFLARE` を返し、アプリ内で再試行できます。エラーにサイト内の認証 URL がある場合は、確認操作からページを開けます。

  文書は宣言済みドメイン内で同じスキームとポートを使って移動できます。未指定のリクエスト `origin` は対象サイト URL から決まります。応答には最終 `url` が残ります。

  自動フォールバックは `followRedirects: false`、`connectAddress`、原因未分類のネットワークエラーには使いません。本文のないブラウザ GET / HEAD は通常の試行は最大 3 回で、検証後の再送は別途最大 1 回です。接続障害または HTTP 408、500、502、503、504 だけを再試行します。429 とタイムアウトは再送しません。検証ページへの移動はリクエスト全体で最大 1 回です。起動、要求、文書読み取り、破棄には待機上限があります。独自 API ヘッダー付き要求は通常のページ移動で代替せず `fetch()` を実行します。再利用する HTML のエラーステータスを保持し、`responseType: 'base64'` は元のバイト列の base64 を返します。

- `network.vpnHint: true`：中国本土で VPN やプロキシが必要かもしれないサイトに宣言します。8 秒を超える待機や失敗時に「VPN またはプロキシが必要な場合があります」と表示します。すべてのエラーを VPN のせいにしないでください。
- `network.confirmation: { selector, readySelector, requiredCookies, auto: { clickSelector, checkSelector?, birthDate? }, message }`: サイトの年齢確認を宣言します。`selector` はダイアログ、`auto.clickSelector` はその中の一意の確認ボタン、`readySelector` は表示可能なコンテンツ、`requiredCookies` は確認後に必要な Cookie 名です。アプリの入口で成年を確認した後に限り、非表示ブラウザがクリックを模擬し、ダイアログ消失、コンテンツ表示、Cookie、画面遷移の安定を確認します。規則が不完全、不一致、または自動処理失敗の場合は再試行できます。エラーにサイト内の認証 URL があれば、ページで手動処理した後に完了を押せます。ソースのドメイン制限と Cookie 分離は維持され、操作通知から元の操作を自動再送しません。ログイン、支払い、投稿には使用できません。

`auto.birthDate` には `{dateSelector}` または `{yearSelector, monthSelector, daySelector}` を宣言します。端末内の成人確認後、日付欄とボタンが一意で同一オリジンの同じ年齢確認フォームに属し、他の送信可能な入力がない場合だけ、固定日付 1999-12-31 を入力して送信します。不一致時は操作せず、実際の誕生日は読み取りません。

任意の `auto.checkSelector` は年齢確認内の一意のチェックボックスを選択します。質問形式には `auto.questionnaire: {rowSelector, submitSelector, answers: [{question, answer}]}` を宣言できます。アプリで成人確認済みで、全質問と完全な回答が厳密に一致し、同一フォームで送信ボタンが一意の場合のみ自動送信します。未知・曖昧な質問を推測せず、ログインなど他のフォームに入力しません。
- ネットワークエラーには安全な `diagnostics` フィールド `host`、`transport`、`reason` が付き、TLS 証明書、ハンドシェイク、DNS、接続、タイムアウトを区別します。自動ログにはこれらの許可されたフィールドだけを記録します。`reason: 'TLS_HANDSHAKE_TERMINATED'` はネイティブの `HandshakeException.message` が `Connection terminated during handshake` と完全一致した場合だけで（ハンドシェイク完了前の切断であり、証明書の失敗ではありません）、本文のない HTTPS の GET / HEAD だけが 1 回再試行され、ほかは再試行しません。

### 画像

- `imageNetwork: { mode: 'browser', origin, domains }`：画像ドメインとサブドメインはサイトの Cookie 権限から独立しています。`origin` はサイトまたは画像ドメインに属します。HTTPS 443 と許可ヘッダーを使い、origin がサイトの宣言ドメインに属する場合、同一オリジンの画像でブラウザーのサイトセッションを使用し、別オリジンの画像、外部画像オリジン、動画では認証情報を送らず、許可された画像ドメイン間のリダイレクトに対応します。上限 20 MiB、復号、形式検査、デコード、サイト別キャッシュを維持します。未指定ならネイティブ転送です。 ブラウザーのリダイレクト対応のプラットフォーム制限はメディア権限を参照してください。
- `imageDecrypt` は AES-CBC、UTF-8 の鍵と IV を宣言し、ドメイン一覧は使いません。通常の画像はそのまま扱い、それ以外は復号後に画像形式を検証してからキャッシュします。

```js
imageDecrypt: {
  type: 'aes-cbc',
  key: '0123456789abcdef', // UTF-8 で 16、24、32 バイト
  iv: '0123456789abcdef',  // UTF-8 で 16 バイト
},
```

表紙が HTTP 200 でも使えるとは限りません。デコードできることを確認してください。

### メディア権限（HLS と直接ファイル）

`media` 権限は `this.http`、`network`、サイトの Cookie から独立しています。

再生にはネイティブ・ブラウザとも `media.scope: 'session'` を使い、固定 CDN ドメインを宣言しません。サイトが返す URL と再生中に解析したリソースのみをセッション内で許可します。拡張子ではなく `format` で形式を指定し、TLS と Cookie 分離を維持します。

```js
domains: ['example.com'],
network: { mode: 'native' },
media: { mode: 'native', scope: 'session', origin: 'https://example.com' },
```

- `media.mode` は `'native'` か `'browser'`。`media.origin` はプラグインの所属サイトに含まれ、HTTPS の既定ポート 443 を使い、認証情報・クエリ・フラグメントを含めません。
- `'native'`：サイト Cookie、Authorization、プロキシ認証を使わない独立クライアントで、接続前に各リダイレクトを検査します。許可ヘッダーは `Referer`、`Origin`、`Accept`、`Accept-Language`。最初の二つは言語サブドメインを含む宣言済みサイトに属し、`Origin` は origin のみです。
- 任意の `media.referrerDomains` はネイティブ動画メディア専用で、有効な公開ドメインを最大 16 個指定できます（サブドメインを含む）。上記のサイトドメイン制限の例外として `Referer` の許可先だけを追加します。`Origin`、メディア URL、文書の遷移、Cookie の権限は拡張しません。`imageNetwork` とブラウザメディアでは使用できません。
- 応答はストリーミング中にサイズを制限し、最終アドレスを再確認します。プレイリスト最大 2 MiB、セグメント最大 32 MiB、AES-128 の鍵はちょうど 16 バイト。超過、空の応答、許可されないアドレスはすべて拒否します。


### 分離とセキュリティ

- 各プラグインは **独立した** JS 環境（それぞれ専用のヘッドレス WebView）で動き、互いのグローバルは見えません。ネイティブブリッジは呼び出し元の環境を識別するため、別のプラグインになりすませません。
- 各プラグインは **独立した Cookie 保管場所** を持ち、リクエストは自分の Cookie だけを送り、保存します。
- Secure Cookie は HTTP では送りません。認証ページを開くときやブラウザ Cookie の取り込みは、インストール済みプラグインの `domains` で確認し、取得できるセキュリティ属性と有効期限を保持します。サイトの Cookie を消去するかアンインストールすると、対応するブラウザセッションを閉じ、そのサイトのブラウザ Cookie も消去します。ブラウザのサイト Cookie はシステムで共有されるため、同じサイトを宣言したプラグインも影響を受けます。
- `domains` はプラグインの所属サイト（登録可能ドメイン、サブドメインを含む）を宣言します。これらのサイトの Cookie だけが内蔵ブラウザと同期され（Cloudflare 認証とウェブログインで共用）、ブラウザモードの `network.origin` もこれらに属する必要があります。省略時は `homepage`、`network.origin`、`account.cookieUrl/loginUrl` から推定します。
- 異なるオリジンへのリダイレクトでは元のオリジンの認証ヘッダーを送りません。リクエスト本文を伴う異なるオリジンへのリダイレクトは拒否します。TLS 証明書の検証は常に有効です。
- URL やリポジトリからインストールするとき、アプリはまずネットワークのないサンドボックスでスクリプト情報を読み、名前、バージョン、SHA-256、宣言サイト、リスクを表示し、ユーザーが確認してからインストールします。

### アカウント

```js
account: {
  type: 'password' | 'cookies' | 'session',
  title, hint, required: false,
  fields: [{ key: 'email', label: '邮箱' }, { key: 'password', label: '密码', secret: true }],
  loginUrl?, cookieUrl?, requiredCookies?: ['session_id'],   // ウェブでログインでき、アプリが Cookie を取得
  loginDomains?: ['accounts.google.com', 'appleid.apple.com'],  // 外部ログインのドメイン（ログイン時の遷移のみ）
  localStorageKeys?: ['session_key'],  // cookieUrl と同じオリジンから許可されたキーだけを読み取り login(values) に渡す。値のログ出力は禁止
  async login(values) { return { name } },
  async logout() {},
  async status() { return { loggedIn, name, configured } },
  managedAccount: true,                 // 任意：自動管理の専用アカウントを提供
  async enableManaged() {},             // ユーザーが登録に同意した後だけ呼ばれる
}
```

ログアウト時は、cookieUrl のサイトが localStorageKeys に宣言したキーだけを削除し、他のローカルストレージを保持します。空リストの診断理由は固定値です：UPSTREAM_EMPTY（上流が空）、NO_VIDEO（動画なし）、EMPTY_RESULT（読み込み後も空）、CONTENT_FILTERED（表示ルールで非表示）、SEARCH_ONLY（省データ設定でおすすめを省略）。正常な各ページは記録せず、空状態の変化と復旧のみ記録します。タイトル、検索語、作品 ID、セッション、メディア URL をログに含めないでください。

- アカウントの状態は、初回使用時、ログイン・ログアウト・ウェブログインの後、前回の確認から 10 分を過ぎたときだけ更新し、呼び出しのたびには確認しません。`configured` はアカウントが設定済みであることを示し、現在ログインできているかとは別です。
- `loginDomains`：サイトが実際に使う外部ログインのドメイン（サブドメインを含む）。ユーザーがウェブログインページを開いている間だけ、HTTPS 443 への遷移を許可し、URL 内の認証情報、IP、localhost、`.local` は拒否します。認証ページ、アクセス確認、プラグインのリクエスト、Cookie の取り込みは引き続き `domains` で確認するため、外部ログインのドメインを `domains` に加えて権限を広げてはいけません。ログインページは同じウィンドウでの遷移と `window.opener` を保つポップアップに対応し、ポップアップ内も同じ確認を行い、空白の初期ページは外部遷移を許可しません。外部ページにいる間はログイン完了とみなさず、サイトに戻ってから Cookie を同期します。外部の Cookie はプラグインの保管場所に取り込まず、サイトの Cookie 消去でも消えません。システムの WebView が管理します。外部サービスが組み込みブラウザでのログインを制限する場合もあります。
- `type: 'session'` は既存の認証セッションを取り込みます。秘密のフィールド（例：`session`）を 1 つ宣言し、クリップボードの内容をそのまま保持してプラグインが検証します。ユーザー名・パスワード・Cookie に分割しません。ログインは実際の認可を確認する必要があり、入力形式だけで成功と報告してはいけません。
- `managedAccount: true` と `account.enableManaged()` は任意のアカウント管理機能です。内容を説明し、ユーザーの確認後にのみ有効にします。手動アカウントと管理対象アカウントを別々に保存し、既存の認証情報を上書きしません。アカウント情報は端末内で扱い、文書、診断、配布物に含めないでください。
- パスワード、トークン、プラグインの状態はユーザーの端末上のデータです。文書やログに実際の認証情報を書かないでください。

## 記事とドメイン解決

記事ソースは `type: 'article', category: 'feed'` を宣言し、一覧に `mediaKind: 'article'` を設定します。`detail(id)` の空でない `blocks` は、元の順序で `{type: 'text', text}`、`{type: 'image', url}`、`{type: 'video', id}` を返します。画像は公開 HTTPS、動画 ID は安定した識別子とし、再生時に `videos(id, videoId)` で URL を取得します。`tagLinks` の `{name, url}` は宣言済みドメインに限定し、`searchLink` で処理します。本文と一時メディア URL は通常の詳細キャッシュに保存せず、お気に入りと履歴には概要を保存します。

`Park.createDomainResolver({initialOrigin, accept, discover, verify})` は信頼できる公開ページから候補を取得し、`accept` と `verify` で検証した接続先をソース専用 store に保存します。`resolver.request(this, path, options)` は `{response, origin}` を返し、403、502/503/504、タイムアウト、分類済み接続・DNS エラーで切り替えます。GET、HEAD と `readOnly` および `allowDomainRetry` を明示した公開検索 POST のみ再送します。未許可ヘッダー、証明書エラー、キャンセル、その他の書き込みでは切り替えず、リダイレクトは同一オリジンに限定します。ブラウザとメディアの権限は拡大しません。

## 音声フォルダーと字幕

フォルダー型は `type: 'voice', category: 'asmr'`、動画型は `type: 'video'` を使用できます。`voiceLanguageStatus` は `chineseSpoken`、`chineseSubtitled`、`foreignOriginal`、`unknown`、`voiceMediaForm` は `audioOnly`、`videoOnly`、`mixed`、`unknown` です。出典または完全な一覧で確認できる値のみ指定します。

詳細は `voiceRoot: {id, name, type}` を返せます。`voiceDirectory(workId, directoryId, {page})` は `{items: [node], hasNext}` を返し、種類は `directory`、`audio`、`video`、`subtitle`、`image`、`script`、`other` です。`voiceResource(workId, nodeId)` は `{url, format}`、`videos(workId, nodeId)` は曲の再生先を返し、メディア権限を守ります。字幕言語が明示されている場合のみ `subtitleLanguage: 'zh'` を付けます。音声・動画ノードは、原サイトが対応を明示する字幕を `subtitleIds: [id]` で指定できます。ID は重複のない空でない安定値を最大 50 件とし、同じフォルダー内の字幕のみ受け付けます。同名の LRC・VTT・SRT も対応付けます。単曲の詳細は `voiceSubtitles: {episodeId: [subtitleId]}` で原サイトが明示する字幕を指定できます。単曲の既定 episodeId は `_` です。各リストは URL を含まない空でない重複のない安定した字幕 ID を最大 50 件とし、`voiceResource(workId, subtitleId)` が必要です。画像と TXT 台本を閲覧できます。音声は作品全体、フォルダー、ファイル単位で全ページと関連字幕を保存できます。オフラインマニフェストは固定 ID とローカル相対パスだけを保存し、一時的なメディア URL は保存しません。`Park.createVoiceArchive` は公開 AList の読み取り専用フォルダー用です。同一オリジンの読み取り専用 POST に限り `readOnly: true` でブラウザへの自動フォールバックが可能です。

ディレクトリの読み込み途中や後続ページの失敗時も、読み込み済みの曲目は再生できます。再生リストと字幕の関連付けには再生開始時に読み込み済みの同階層ノードを使い、部分的なディレクトリを完全と扱いません。

## メソッド

メソッド内の `this` は「ランタイム API」を参照してください。すべてのメソッドは `async` にできます。

```js
async feed(key, { page, cursor, options, common }) {} // サイトページのタブ
async search({ keyword, page, cursor, filters, common }) {}
async random() {}                                  // 作品 ID を返す
async detail(id, preview) {}
async chapter(id, chapterId) {}                    // 漫画、ギャラリー
async resolveImage({ id, chapterId, index, token, retry }) {}  // 任意：画像の遅延解決
async thumbnails(id, page) {}                      // 任意：プレビューサムネイルのページ読み込み
async videos(id, episodeId = '_') {}               // 動画
async textChapter(id, chapterId) {}                // 小説
async onlineGame(workId) {}                        // online game
async gameResources(workId) {}                     // ゲーム
async resolveGameResource(workId, resourceId, channelId) {}
```

### `searchSuggestions`

任意の第2引数 `context.dictionary` はローカル辞書の候補 `[{namespace, name, translation}]` を渡します。原語と訳語を照合し、照合時のみ簡体字と繁体字を正規化します。表示名と元サイトの検索語は変更しません。プラグインが検索構文を生成し、候補がない場合は元サイトの候補を取得できます。

`searchSuggestions(keyword, context = {})` を実装すると `capabilities.searchSuggestions` を公開します。最大 20 件の `[{keyword, label, subtitle}]` を返し、`keyword` は入力済みの他の語も保持した完全な検索式にします。接頭辞は対応サイトだけに付け、E-Hentai と nhentai は名前空間を保持し、他は元の語を使います。入力停止後に取得し、消去・検索・破棄で中止し、失敗しても通常検索を妨げません。横断候補は選択サイトのみで、出典を表示してそのサイトで検索します。IME 変換中は取得しません。

### 一覧：`feed` / `search`

```js
{
  items: [WorkItem], page: 1, totalPages: 20, total: 500,
  hasNext: true,
  cursor: '12345',        // 任意：カーソル方式のサイトは次のカーソルを返し、アプリはそのまま返す
}
// またはセクションを返し、セクション表示にする：
{ sections: [{ title: '连载更新', items: [WorkItem] }], hasNext: false }
```

**WorkItem**：`{ id, title, subtitle?, cover, coverBlurred?, coverAspect?, pages?, rating?, likes?, views?, language?, category?, badge?, badgeColor?, duration?, uploaded?, tags?, mediaKind?, workCode?, editions?, commentsAvailable? }`

- `workCode` は配信元で確認された作品番号または共通検索コードで、同じ作品の検索にのみ使用します。`id` を置き換えず、作品の識別、お気に入り、進捗、ダウンロードを統合しません。
- `editions` は配信元が明記する固定の版ラベル（中国語字幕、無修正版の流出など）です。ラベルがない場合に原版と推測してはいけません。表示の翻訳は元のラベルを変更しません。

- `coverAspect`（幅 / 高さ）があると画像の読み込み前にグリッドを配置できます。
- `badgeColor` は分類バッジの色です。
- `mediaKind: 'comic' | 'video' | 'voice' | 'novel' | 'tavern' | 'game' | 'article' | 'mixed' | 'unknown'` は作品自体の種類です。種類が 1 つのプラグインは省略できますが、混在するプラグインは必ず指定します。小説、ゲーム、記事は常に指定し、プラグインを削除しても種類を保持します。
- 投稿形式の結果は `presentation: 'post'`、`text`、`date`、`url` と `media` 配列を持て、投稿カードとして表示されます。`presentation: 'media'` はメディアのグリッドで表示し、タップで作品内のメディアを開きます。投稿にメディアがなくてもかまいません。メディアのアドレスはプラグインが宣言したドメインと権限に従います。

### 詳細：`detail`

WorkItem の全フィールドに加えて：

```js
{
  url, authors: [], description, uploader?, size?, comments?, commentsAvailable?,
  tags: [{ namespace: 'artist', label: '作者', tags: [{ name, keyword, filters?, count? }] }],
  chapters: [{ id, title }] | null,   // null は単一章
  singleChapterId?,                   // 単一章の作品に必要な章 ID
  thumbnails?: [url | { url, width, height, offsetX, offsetY }],   // スプライトに対応
  related?: [WorkItem], series?: [WorkItem], variants?: [WorkItem],
}
```

- `variants` には配信元が提供する、同じ配信元の同一作品の実在する版リンクのみを含め、各版の `id` を独立して保ちます。URL を推測してはいけません。他の配信元の版は `workCode` で検索し、お気に入り、進捗、ダウンロードは独立して保持します。

- タグをタップすると、このサイトで `keyword` と `filters` を使って検索します。タグをサイト独自の構文（例：`artist:"xxx"`）やフィルターのパラメータに対応付けられます。
- 2 番目の引数 `preview` は任意で、`preview.source` と `preview.id` が一致する場合だけ、表示済み・保存済みの公開メタデータが渡されます。プラグインは ID を確認し URL を検証する必要があります。ID を入力して開いた場合は preview がなく、タイトルや表紙が不完全なことがあります。

### 章：`chapter` / `resolveImage` / `thumbnails`

```js
{ pages: [
  { url, headers?, fallbacks?: [url], width?, height?, transform? },  // アドレスが分かっている
  { token: '12' },                                                      // 遅延解決：アプリが resolveImage を呼ぶ
]}
```

- `fallbacks`：予備のミラー。主アドレスが失敗すると順に試します。
- `transform: { type: 'unscramble-strips', segments: N }`：画像が N 本の帯に切られ逆順で保存されている場合に GPU で復元します。オフラインファイルは元画像を保存し、表示時に復元します。
- `resolveImage` は `{ url, headers?, width?, height?, cacheKey? }` を返します。失敗するとアプリは `retry` を増やして再度呼ぶので、プラグインはサーバーを切り替えられます。
- `thumbnails(id, page)` は `{ thumbnails: [...], hasNext }` を返します。

### 動画：`videos`

`[{ quality: 1080, label: '1080P', url, headers?, format?, preferred?, hls? }]` を返します。直接リンクは通常期限があるため、アプリは再生やダウンロードのたびに取得し直します。

- `format: 'hls'` は `hls: {manifest, keys}` を指定できます。`url` はバリアントの実際の HTTPS ベース URL、`manifest` は処理済みの完全な VOD メディアリスト（UTF-8 最大 2 MiB）、`keys` は参照された絶対鍵 URL と Base64 の 16 バイト鍵の対応（最大 32 件）です。ネイティブメディア専用で、既存のアドレス認可と内容検証は維持され、未参照の鍵は拒否します。このフィールドを含む結果はディスクにキャッシュせず、鍵はセッションメモリのみで使用し、store、ログ、作品、カーソルには保存しません。

- 複数話の動画は `detail(id).chapters` で再生順の `[{ id, title }]` を返します。各 `id` は安定している必要があり、画質や一時的なメディア URL で代用してはいけません。アプリは同じ ID でエピソード選択、進捗の保存、ダウンロード、続きからの再生を行い、`videos(id, episodeId)` でその話のリソースを取得します。単話は `singleChapterId`、なければ `'_'` です。
- `format` を省略すると MP4 の直接リンクとして再生・ダウンロードします。HLS は `format: 'hls'` を返し、`media` 権限を宣言する必要があります。
- `type: 'video', category: 'live'` は三次元の公開ライブ配信です。ホームとカテゴリは画像カードのみ。`videos()` は現在の公開ルームの HLS を返し、非公開・有料・オフラインのルームを再生可能として返さないでください。ローリング再生に対応し、再生位置の復元・保存とダウンロードは行いません。録画は明示的な操作で開始し、初期ウィンドウより新しいセグメントのみを保存します。停止・アプリ終了で終了し、再起動後に再開しません。独立したメディアセッションとバックグラウンドタスクで各セグメントを検証・復号して完全なローカルリストを保存します。再接続時にメディアを再解決し、符号化の境界や長時間録画は分割されます。失敗時も保存済み内容は保持します。多重化 MPEG-TS のみ対応し、MAP/fMP4、低遅延 PART、BYTERANGE、GAP は非対応です。
- VOD は `#EXT-X-ENDLIST` のある完全で連続した MPEG-TS または fMP4 が必要です。fMP4 はメディアの前にある単一の `#EXT-X-MAP` 初期化セグメントのみ対応し、切り替えやバイト範囲には非対応です。初期化とメディアを認可・検証してローカルに書き換え、オフライン再生とエクスポートにも初期化セグメントを含めます。ライブは引き続き MPEG-TS のみで、ローリングリストと discontinuity に対応します。両者は `METHOD=AES-128`、`KEYFORMAT=identity` の CBC/PKCS7 を16バイトの鍵で復号します。メディア IV は明示値またはシーケンスから導出し、暗号化された初期化セグメントは明示 IV が必要です。鍵はセッション内のメモリのみです。SAMPLE-AES、他の KEYFORMAT、BYTERANGE、GAP は非対応で、VOD は discontinuity も拒否します。`#EXT-X-TOKEN` は除去します。
- HLS プレイリストと MPEG-TS セグメントは PNG `roUd` ラッパー（非圧縮または zlib 圧縮）に対応します。展開後に解析・検証・復号し、展開後もプレイリスト 2 MiB、セグメント 32 MiB の制限を適用します。プラグインは引き続き `format: 'hls'` を返し、追加権限は不要です。
- 再生時は `127.0.0.1` だけにバインドしたランダムなポートとランダムなトークンを使い、限定された URL 登録から検証済みのセグメントを必要に応じて読み出します。セッションを閉じるとリクエストは取り消されます。HLS のオフラインダウンロードは現在 Android のみで、セグメントごとに検証して SHA-256 を保存し、再開と取り消しができ、最後に Media3 で MP4 にまとめます。完全なファイルだけがオフラインライブラリに入ります。 fMP4 は初期化とメディアを順に保存し、Media3 の TS 変換を使用しません。

### 小説：`textChapter`

小説プラグインは `type: 'novel', category: 'novel'` を宣言し、`textChapter` を実装すると `capabilities.textChapter: true` が出力されます。一覧と詳細では `mediaKind: 'novel'` と `language: 'zh'` または `'en'` を指定します。本物の表紙がなければ `cover: ''` を返し、アプリは架空の画像を要求せずに文字の表紙を表示します。

```js
async textChapter(id, chapterId) {
  // その章の本文全体を返す。paragraphs は空でない文字列の配列で、HTML を含めない。
  return { title: '章节标题', paragraphs: ['第一段正文。', '第二段正文。'] };
}
```

- 複数章の小説は `detail.chapters` で安定した ID とサイトで確認できる読む順序を返します。単編は `chapters: null` と任意の `singleChapterId` を使います。
- 章内のページ分割はプラグインが順に結合し、次の章、掲示板の返信、広告、おすすめ作品を本文に含めてはいけません。`Park.html.paragraphs(node)` は汎用的なテキスト抽出を提供しますが、サイトの境界とページ分割はプラグインが決めます。
- ログイン、課金、権限で本文が切り詰められる場合は `LOGIN_REQUIRED` を投げ、プレビューを完全な章と偽ってはいけません。
- アプリは章ごとに `text.json` をアトミックに書き込み、完全に書き込めた場合だけダウンロード完了とします。読書の進捗とメモは `paragraphs.join('\n\n')` の UTF-16 の位置を使い、文字サイズ、フォント、字下げなどの表示設定は本文や保存位置を変えません。しおりとメモはダウンロードとは別に保存され、バックアップに含まれ、ダウンロードを削除しても残ります。

### オンラインゲーム: `onlineGame`

オンラインゲームのプラグインは `type: 'game', category: 'onlineGame'` を宣言し、作品に `mediaKind: 'game'` を指定します。プレイ時の `onlineGame(workId)` は `{kind: 'html', url, storageId?}` を返します。Flash は `{kind: 'flash', url, player, storageId?}` とし、SWF と同じホストの Ruffle スクリプトを指定します。URL は認証情報のない HTTPS の 443 番ポートに限定します。`storageId` はサイト内の安定した作品 ID で、省略時は workId を使い、認証情報を含めません。


### ゲーム：`gameResources` / `resolveGameResource`

ゲームプラグインは `type: 'game', category: 'game'` を宣言し、作品は `mediaKind: 'game'` を指定して架空の `chapters` を持ちません。ランタイムはメソッドから `capabilities.gameResources` と `capabilities.resolveGameResource` を出力します。

```js
async gameResources(workId) {
  return [{ id: 'resource-id', title: '', version: '1.2', size: '2 GB',
    status: 'valid', testStatus: 'untested',
    channels: [{ id: 'stable-channel-id', kind: 'direct', label: 'game.zip', size: '2 GB' }] }];
}
async resolveGameResource(workId, resourceId, channelId) {
  return { kind: 'direct', url: 'https://files.example/game.zip?temporary-signature',
    filename: 'game.zip', extractionCode: '', archivePassword: '' };
  // クラウドストレージは kind: 'external'、urls: [すべての予備・分割リンク]、url: urls[0] を返す。
}
```

- `gameResources` は安定した ID、メタデータ、チャンネルだけを返し、署名付き URL、パスワード、架空のダウンロード状態を含めてはいけません。`testStatus` は `tested | untested | unknown` で、サイトの表示をそのまま写したものです。`status: 'expired'` のチャンネルは無効になります。
- `resolveGameResource` はユーザーのタップか再試行のときだけ呼ばれ、返す URL は保存もログもされません。パスワードはローカルのダウンロードタスクと一緒に保存できますが、診断には書きません。複数のクラウドリンクを捨ててはいけません。複数返す場合は `urls` と同じ長さの `extractionCodes`（空文字は取得コードなし）を、共通のコードには `extractionCode` を使えます。
- 返信が必要なチャンネルは `requiresReply: true, replyText: '実際の返信内容'` を宣言し、アプリは「返信してリンクを解除」と送信する文面を表示し、ユーザーの確認後にだけ呼びます。プラグインは解決前に最初の投稿を確認し直し、解除済みなら読むだけにします。ユーザーのタップ時に 1 回だけ送信し、送信前にアカウントとスレッドの状態を確実に保存します。結果が不明、繰り返しの試行、動的な認証が必要な場合は、元の投稿の URL とともに `CONFIRM_REQUIRED` を返し、自動で再送してはいけません。一覧、詳細、先読み、バックグラウンド更新では返信しません。
- 直接リンクは `media: { mode: 'native', origin, domains }` を宣言します。ファイルは Cookie を持たない別のクライアントでストリーミング保存し、HTTPS、ホップごとのドメイン確認、長さの確認、取り消し時の後片付け、完成ファイルの保護はフレームワークが担います。中断からの再開はなく、再試行するとアドレスを解決し直して最初からダウンロードします。クラウドストレージは外部アプリで開き、HTTP(S)、FTP(S)、magnet、ed2k、thunder だけを許可し、サイトの Cookie は使いません。ゲームは章、読書の進捗、章の更新を作らず、アプリがファイルを自動でインストール、展開、実行することはありません。

### 購読：`subscription`

チャンネルやクリエイターを購読するプラグインは `subscription` オブジェクトを宣言します。`normalize` と `posts` が両方あるとランタイムは `capabilities.subscription` を出力し、「見つける → 購読」に表示されます。`feeds` も宣言したプラグインは通常の分類にも表示されます。

```js
subscription: {
  hint: '无需登录即可保存订阅；媒体访问取决于原站权限。',
  normalize(input) { return { id: validatedTarget, label: displayName }; },
  async resolve(input) { return { id: validatedTarget, label: displayName }; },
  async targets() { return [{ id: joinedChannelId, label: channelName }]; },
  async posts(target, { cursor }) {
    return { items: [{ id, title, text, date, url, locked, commentsAvailable,
      media: [{ type: 'image', url, preview, previewOnly: false },
              { type: 'video', url, preview, format: 'mp4', headers: {} }] }],
      cursor: nextCursor, hasNext: true };
  },
  async mediaChunk(resource, offset) { return { base64, done }; }, // 任意
}
```

- `normalize` は端末内だけで検証し、未ログインやオフラインでも対象を保存できるようにします。このサイトのユーザー名か管理されたプロフィール URL だけを受け付けます。`resolve` と `targets` は任意で、`targets` があると manifest は `subscription.joinedTargets: true` を出力します。
- コミュニティの独立した入口には `communities: true`、`communityHint`、`communityExample` を宣言し、ランタイムはそのまま公開します。対象は `{ id, label, kind: 'community' }` で、作者と異なる ID が必要です。`targets({ kind: 'community' })` は参加済みコミュニティ、引数なしの `targets()` は既定の対象を返します。コミュニティ API の失敗が作者一覧を壊さないよう別々に処理します。`resolve` は名前とアクセス権の読み取り確認のみで、自動参加は禁止です。
- `posts` のカーソルは不透明な文字列で、最終ページは `hasNext: false`、メディアのないページでもページングを続けられます。`locked` は権限不足、`previewOnly` は公開プレビューであることを示します。サムネイルを全文と偽ってはいけません。

### 公開アルバム：`subscription.media`

アルバムは独立した機能です。読み込み済みの投稿から組み立てず、`subscription.posts` にフォールバックしません。`subscription.media(scope, { page, cursor })` を実装します。公開 feed があり購読対象がないソースでも、`subscription` にこのメソッドだけを宣言できます。ランタイムは `capabilities.subscription` と独立して `capabilities.album` を公開します。

`scope` は feed と絞り込みの `{ feed, options }`、またはユーザー・コミュニティ・チャンネル・グループの `{ target }` / `{ search: { keyword, filters } }` です。対象の解決と走査はソースが担当し、UI にサイト固有条件を置きません。`{ items, cursor, hasNext }` を返し、該当メディアのないページでも続行できます。継続カーソルは必ず進め、重複はエラーです。

各項目には安定した文字列 `id`、`presentation: 'post' | 'work'`、既知なら解析可能な ISO 8601 日付、原サイト順の完全な `media` 配列が必要です。各添付には一意で安定した文字列 `id`、`type: 'image' | 'video'`、実際のコンテンツの `url` または管理対象の `resource` を指定します。`preview` は画像サムネイルです。代わりに下記の管理対象添付形式の `previewResource` を使えますが、別の画像で最大 2 MiB です。表紙や動画 URL をサムネイルに偽装しません。制限付き内容は原サイトのぼかしを維持した公開プレビューのみを `previewOnly: true` で返し、投稿全体がロックされていれば `locked: true` を付けます。

ソースはページをまたぐ添付の補完とメディアグループの統合を行います。クライアントは添付 `id` で同じ作品を統合し、全添付に有限数値の `order` がある場合のみ並べ替えます。日付はローカル日付の両端を含む範囲で絞り込み、範囲指定時は日付不明を除外します。画像・動画の絞り込みや投稿の折りたたみは識別情報を変えません。空の絞り込み結果を有限ページ自動取得した後は手動で続行できます。`presentation: 'work'` は作品詳細、`'post'` は投稿全文を開きます。表紙は画像または明示的なサムネイルのみで、動画再生 URL を使いません。

- `coverBlurred: true` とメディアの `blurred: true` は、サムネイルと全画面の両方で元サイトのぼかしを保持します。制限付き写真をぼかしなしの完全版として表示しないでください。動画プレビューも完全版も HLS マスターを展開し、選択した画質の VOD を再生します。
- 直接リンクを出せない認可済みの添付ファイルは `media[].resource` を使い、`mediaChunk(resource, offset)` を実装します。1 回最大 128 KiB、offset は 128 KiB 単位で、resource には整数の `size` と、認証情報や一時的な参照で変わらない安定した非秘密の文字列 `cacheKey` が必要です。フレームワークは全体サイズと各チャンクを確認し、自分のキャッシュパスにアトミックに書き込みます。1 つの添付は最大 512 MiB で、resource がローカルパスを決めることはできません。署名付きリンクと resource は購読記録に保存しません。
- 元サイトでのフォローや参加を伴う購読は、保存前に操作を明示して利用者の確認を得る必要があります。未検証の書き込み操作は元サイトへ案内し、通知せずにフォロー・参加・支払いを行ってはいけません。

### 更新の購読：`updateSubscriptions`

通常のプラグインは独立した `updateSubscriptions` オブジェクトで「更新を追う」に対応できます。ランタイムは `check` がある場合だけ `capabilities.subscriptionUpdates` を出力し、作品の分類や前述の `capabilities.subscription` には影響しません。メタデータは `dimensions: [{ key, label, hint }]` を含み、タグメニューから元のキーワードとフィルターを渡せます。

- `normalize(dimension, input)` は `{ id, label }` を、`check({ dimension, target }, { cursor })` は `{ items, hasNext, cursor }` を返します。各項目は `{ id, title, kind, workId, chapterId }` で、`kind` は `work | post | chapter` のみ、ID は安定していて空でなく、メディア URL、Cookie、認証情報を含めません。章 ID には作品の識別も含め、別の作品の「第 1 話」が衝突しないようにします。
- `Park.enableUpdateSubscriptions(Park.__pending, rules)` が汎用の対応を提供し、ルールはスクリプトの末尾で明示的に宣言し、`searchFilters`、`seriesPattern` を指定できます。`work` は実際の章一覧、`posts` は既存のチャンネル API、`search` と `filter` は検索を使い、`code` は品番に完全一致、`series` はサイトのドメインで検証したシリーズパスを使います。検索のカーソルはページ番号とサイトのカーソルの両方を保存します。
- `windowed: true` は初回に直近3ページを基準として保存します。その後は1回最大3ページずつカーソルと候補を保存し、既知の項目だけのページまたは末尾まで調べて新規イベントを確定します。章一覧は打ち切らず、候補20,000件超過や解析失敗はエラーにします。
- `query({ dimension, target })` は `{ keyword, filters }` を返し、購読の閲覧と確認で共有します。アルバムは `{ search: { keyword, filters } }` にも対応し、ページ送りでも検索条件を維持します。投稿の短編動画は `resource` 添付に対応し、同じ検索範囲で続けます。
- フォアグラウンドとバックグラウンドはプラグインのランタイム、Cookie の区画、ドメイン制約、確認処理を共有します。バックグラウンドは関係するプラグインだけを起動し、ログイン、サイトでの購読、メディアのダウンロード、権限の回避は行いません。アカウントやプラグインの設定が変わると基準を作り直します（トークンの更新は含みません）。

## ランタイム API

メソッド内では `this` で次を使えます。

| メンバー | 説明 |
| --- | --- |
| `this.http` | `request(opts)`、`get(url, opts)`、`post(url, opts)`、`text(url, opts)`、`json(url, opts)` |
| `this.config` | ユーザーがサイト設定で選んだ値（未設定なら `default`） |
| `this.store` | 永続的なキーと値の保存：`get(key, fallback)` / `set(key, value)`。トークンやドメイン一覧などに使い、`await flush()` で書き込みを確認（失敗すると例外） |
| `this.cookies` | `get(url)` / `set(url, { name: value })` / `clear(url)` |
| `this.log({ code, host, transport, reason })` | 許可されたフィールドだけを書き込み、自由なテキストは残さないので認証情報やアドレスが漏れません |

グローバルなヘルパー：

| ヘルパー | 説明 |
| --- | --- |
| `Park.html.parse(text)` | 標準の `Document` を返し、`querySelector` が使える |
| `Park.html.text(node)` / `unescape(s)` / `strip(html)` / `paragraphs(node)` | テキスト処理 |
| `Park.crypto.md5Hex(text \| text[])` | MD5。配列で一括計算できる |
| `Park.crypto.sha256Hex` / `hmacSha256Hex(key, text)` / `aesEcbDecrypt(base64, key)` / `uuid()` | ネイティブ実装 |
| `Park.crypto.digestBytes('sha1' \| 'sha256', bytes)` | 最大 2 MiB の 0〜255 の整数配列 |
| `Park.crypto.randomBytes(length)` | 安全な乱数バイト。length は 1〜65536 |
| `Park.url.parse(value, base, domains)` / `site(source, value, base?)` / `response(source, response, requested)` | 許可ドメインとサブドメインの HTTPS 443 URL を解析し、認証情報を拒否、フラグメントを除去、失敗時は `null`。`site` は源の `domains` を使用。`response` は最終 URL を確認し、共有された源の基底 URL を変更せず、不正なら `BLOCKED`。パス、ページ、作品、検索条件はプラグインで確認し、クエリキーや CDN ノード名の固定リストを避けます。 |
| `Park.utils.rateLimiter(ms)` | `wait()` を返し、リクエスト間の最小間隔を保証 |
| `Park.utils.mapLimit(items, n, fn)` / `lruMap(n)` / `parseCount('1.2万')` / `formatDate(ts)` | `mapLimit` の並列数は正の安全な整数、`lruMap` の容量は非負の安全な整数である必要があります。容量がゼロの場合は項目を保持しません。不正な値はエラーになります。他のヘルパーは件数と日付の変換用です。 |
| `Park.error(code, message, extra?)` | エラーコード付きのエラーを作る。「エラーコード」参照 |

`Park.crypto.aesGcmDecrypt(ciphertext, key, iv)` は 16 進数の暗号文（末尾の 16 バイト認証タグ込み、最大 4096 バイト）、16/24/32 バイト鍵、12 バイト IV を受け取り、平文バイト配列を返します。認証失敗時は未認証の平文を返さず例外になります。

### `http.request(opts)`

```js
await this.http.request({
  url, method: 'GET', headers: {}, params: { q: 'x' },   // params は URL に付く
  json: {...} | form: {...} | body: 'raw' | bodyBase64: '...',
  timeout: 15000,
  responseType: 'text' | 'base64',
});
// → { status, headers, body, url, ok, json() }
```

- `text()` / `json()` は 2xx 以外で例外を投げます（404 → `NOT_FOUND`）。Cookie は自動で保存され、リダイレクト先ごとに選び直されます。
- `bodyBase64` はバイナリの本文（最大 2 MiB）で、`body` やブラウザモードとは併用できません。テキストのリクエストと同じドメイン分離、TLS、リダイレクトの規則に従います。プラグインが自分でブラウザ通信、WebSocket、任意のファイルアクセスを開くことはできません。

## エラーコード

`throw Park.error(code, message, extra)` で投げると、アプリはコードに応じて案内します。

| code | アプリの対応 |
| --- | --- |
| `CLOUDFLARE` | 「認証する」：内蔵ブラウザを開く |
| `CONFIRM_REQUIRED` | 「確認する」：プラグインが宣言したアクセス確認をユーザーが終えるのを待つ（`extra.url` が確認ページ） |
| `LOGIN_REQUIRED` | 「ログインする」：サイト設定のアカウント欄を開く |
| `NOT_FOUND` | 「コンテンツがありません」を表示 |
| `BLOCKED` | 「アクセス制限」を表示（IP の遮断、上限到達など）。画像は再試行しない |
| `NETWORK` | 「ネットワークに接続できません」と理由、「再試行」を表示 |
| `HTTP` / `PARSE` / `UNSUPPORTED` / `CONFIG` | プラグインのメッセージと「再試行」を表示 |

### 構造化されたメッセージ

`message` は **中国語のテンプレート** で、そのまま翻訳キーになります。変わる部分は文字列に連結せず `extra.params` に入れます。

```js
throw Park.error('HTTP', '站点返回 HTTP {status}', { params: { status: res.status }, status: res.status });
throw Park.error('NOT_FOUND', '影片不存在');
```

アプリはまずプラグインの `i18n`、次にアプリ共通の語彙でテンプレートを翻訳し、`params` を差し込みます。連結した文字列は翻訳できず、中国語以外のユーザーには中国語のまま表示されます。`extra` の `status`、`url`、`diagnostics` はこれまでどおり使えます。

### ホームのキャッシュとエラーの意味

- `feed` のリアルタイム結果は全フィールドを保持します。アプリ専用の再構築可能なディスクキャッシュは、許可リストの作品データ、投稿本文、添付へのアクセス情報、対応する詳細フィールドを保存し、更新前にも内容を開けます。有効期限付きメディア URL やリソース参照を含むことがあり、期限切れは更新が必要です。ダウンロードやバックアップの代わりではありません。キャッシュ識別はサイト、アカウント、設定、要求範囲を分離します。認証情報を返却内容・ID・カーソルに入れず、キャッシュのアクセス情報を診断や購読記録へ転記しません。
- 古いキャッシュは明確な `NETWORK` / `TIMEOUT` エラーのときだけオフラインの内容として表示し、キャッシュであることを示します。ログイン、確認、人による認証、解析、設定の失敗はそれぞれのエラーを投げる必要があり、フレームワークがネットワーク障害に見せかけることはありません。ユーザーが自分で更新して失敗した場合も実際のエラーを表示します。

## 多言語対応

アプリの UI は `zh-Hans`、`zh-Hant`、`ja`、`ko`、`en`、`es`、`ru`、`ar`（アラビア語は右から左）に対応します。プラグイン内の人が読む静的な文言（名前、説明、タブ名、オプション、検索のヒント、アカウントの説明、エラーメッセージ）はすべて **簡体字中国語の原文** で書き、原文が翻訳キーになります。

プラグインは manifest の `i18n` に自分の翻訳を持ちます。

```js
Park.register({
  i18n: {
    'zh-Hant': { '发行日期': '發行日期', '影片不存在': '影片不存在' },
    'en': { '发行日期': 'Release date', '影片不存在': 'Video not found', '站点返回 HTTP {status}': 'The site returned HTTP {status}' },
    // ja、ko、es、ru、ar も同様
  },
  key: 'mysite',
  // …
});
```

- 検索の順序：プラグインの `i18n` の現在の言語 → プラグインの `en`（簡体字中国語の UI を除く）→ アプリの共通語彙（`assets/i18n/`、例：「並べ替え」「最新」「人気」）→ 原文。
- アプリにない、そのプラグインだけの語句だけを `i18n` に書き、共通の語句はアプリの翻訳を使います。プレースホルダー `{name}` は原文と一致させます。
- リモートの内容（作品名、作者、タグ、紹介文）、ユーザーの入力、保存されるプロトコルのキーはそのままにし、UI の文言として翻訳しません。
- `i18n` の変更もプラグインの変更なので、バージョンを上げる必要があります。古いプラグインのユーザーは更新するまで以前の文言を見ます。

アプリ自体の UI 文言は `tr('已选 {count}', { 'count': count })` か `context.tr` で呼び、8 言語のリソースは `assets/i18n/` にあります。追加や変更のときはすべての言語を更新し、プレースホルダーを揃えてください。

## 公開

### リポジトリ

リポジトリは 1 つの `index.json` で、任意の静的ホスティングに置けます。ユーザーは「その他 → サイト → サイトを追加」にアドレスを入力して閲覧、インストール、更新できます。

```json
{
  "name": "我的站点仓库",
  "apiVersion": 2,
  "sources": [
    {
      "key": "mysite",
      "name": "我的站点",
      "version": "0.0.1",
      "minAppVersion": "0.9.2",
      "description": "一句话介绍",
      "url": "https://example.com/sources/mysite.js",
      "sha256": "スクリプトの UTF-8 原文の 64 桁 16 進 SHA-256",
      "apiVersion": 2
    }
  ]
}
```

`url` はスクリプトの完全なアドレスで、`index.json` からの相対の `file` も使えます。サードパーティのリポジトリはユーザーの確認後に手動でインストールします。`sha256` は任意で、ある場合はダウンロード内容を検証します。

### バージョンと更新の規則

- プラグインは minAppVersion（例：0.9.2）を宣言し、公式インデックスと一致させる必要があります。現在の apiVersion は 2 で、HentaiPark 0.9.2 以降が必要です。更新と URL インストールは置き換え前に互換性を確認し、非対応の場合は既存プラグインを保持します。自動通知では更新可能なものとアプリ更新が必要なものを分けます。「このバージョンを通知しない」は表示中のアプリ・プラグインのバージョンだけに適用され、再起動後も保持されます。手動確認には影響しません。

- バージョンはドット区切りで先頭ゼロのない 3 つの非負整数（例：`0.0.1`）で、各部分を数値で比較します。欠けた部分、余分な部分、プレリリースの接尾辞は受け付けません。
- 公式の更新ではスクリプトの UTF-8 原文の `sha256`（空白の除去や改行の変換をしない）が必要で、スクリプトが宣言した `key`、`version` はインデックスと一致する必要があります。`apiVersion` は現在のアプリのランタイムと完全に一致しなければ更新を拒否します。
- プラグインとアプリのバージョンは別々に管理します。プラグインのスクリプト（`i18n` を含む）を変更したら、スクリプトと `assets/sources/index.json` の両方でバージョンを上げます。公開ツールはダウングレードと、同じバージョンで内容が違うものを拒否します。

### アプリ内の公式更新

- 「その他 → サイト」と「その他 → このアプリについて → 更新」の「起動時にプラグインの更新を確認」は既定でオンです。起動ごとに公式インデックスだけを読み、新しいバージョンがあれば案内し、ユーザーの確認後にダウンロード、検証、インストールします。フォアグラウンドへの復帰時は 12 時間の間隔を保ち、失敗しても確認時刻を記録します。自動確認をオフにしても手動で確認できます。確認するのはインストール済みの内蔵と公式のプラグインだけで、新しいプラグインを自動でインストールしたり、同じ key のサードパーティプラグインを引き継いだりはしません。
- インストール時は識別、バージョン、取得元、API、ダイジェストを再検証し、初期化と状態の保存が成功して初めて完了します。失敗すると古いスクリプトとユーザーの状態を残し、インストール中に中断した場合は次回起動時に復元します。起動時にアプリ同梱のスクリプトで既存のプラグインを上書きすることはありません。スクリプトがない場合は登録情報とユーザーデータを残し、ユーザーが復元や更新を選ぶのを待ちます。「内蔵バージョンに戻す」は確認後、現在のアプリに同梱されたバージョンに戻します。
- アプリ自体の更新も既定で確認します。Android ではユーザーの確認後、端末に合う公式 APK をアプリ内でダウンロードし、サイズ、SHA-256、パッケージ名、バージョン、署名を検証してからシステムのインストーラーを開きます。進捗、取り消し、再試行に対応し、公式のリリースページを予備の入口とします。

### 公式プラグインの公開

公式プラグインは `assets/sources/index.json` で管理します。`tools/publish_sources.mjs` が一覧とランタイム宣言をオフラインで照合し、不変のスクリプト URL と SHA-256 を含む公開インデックスを生成します。ログインやサイトのメソッドは実行しないため、実際のリクエストによる検証は別途必要です。ビルドと公開の手順は[開発ガイド](../../DEVELOPMENT.md)を参照してください。

### ビルドで生成されるプラグイン

Telegram プラグインの唯一の実装は `assets/sources/telegram_entry.mjs` で、`assets/sources/telegram.js` はビルドで生成されるため手で編集してはいけません。

```powershell
npm ci --prefix 'tools/source-runner'
node tools/build_subscription_sources.mjs
```

[@mtproto/core 6.3.0](https://github.com/alik0211/mtproto-core)（GPL-3.0、[ライセンス](../../licenses/mtproto-core.txt)、依存関係の一覧は [サードパーティライセンス](../../licenses/telegram-dependencies.txt)）を使います。サイトの対応部分が転送、暗号、保存を置き換え、ライブラリ既定の WebSocket、ブラウザの localStorage、デバッグログは使いません。

### `webVideo(id, episodeId)`


Web 再生の Cloudflare 認証は独立した一時セッションで処理します。認証フレームは正確な `challenges.cloudflare.com` のみ許可し、そのホストへのメインフレーム移動は許可しません。年齢確認の `network.confirmation` はソースが宣言したドメインだけに適用し、外部プレーヤーには適用しません。自動処理できない場合は手動操作用にページを残し、プレーヤーの Cookie は入出力しません。`CONFIRM_REQUIRED` はプラグインの説明を保持し、アプリ内の確認ページで明示的に完了した後にソースのセッションを同期します。元の操作は再送しません。

iXXX と TubeSafari の対応済み配信元はネイティブ再生を優先し、続き再生とオフライン保存に対応します。未対応の配信元はアプリ内ウェブ再生を使用します。ウェブ再生ではサイトの確認が必要な場合があり、アプリのダウンロードと正確な続き再生には対応しません。Android のウェブ再生には独立セッション対応の新しい Android System WebView が必要です。

ランタイムは `capabilities.webVideo` を自動で公開します。`webVideo` のみを実装する場合はアプリ内ウェブページを開きます。`videos` と `webVideo` の両方を実装する場合はネイティブ再生を優先し、`videos` が `UNSUPPORTED` を返した場合だけウェブ再生に切り替えます。HTTP、ネットワーク、Cloudflare、ログイン、解析、削除、キャンセルのエラーはそのまま表示します。ダウンロードには解析できたネイティブメディアが必要で、ウェブページには切り替えません。

```js
return { url: "https://player.example.com/watch/1", navigationDomains: ["player.example.com"], frameDomains: [] };
// Native HTTP only: this.http.get(url, { followRedirects: false })
```

## ランキングと独立配信

`rankings` は `key`、`label`、`category`、`metric`、`options` で定義します。専用プラグインは `rankingOnly: true` とし、`feeds` を宣言しません。`ranking(board, {page, offset, cursor, options})` は作品ページを返し、項目には `id`、元の `rank`、`title`、`cover`、任意の `keyword`、`subtitle`、HTTPS商品 `url` を含めます。同順位を保持します。既存ソースは `feed` を指定して選択肢を継承し、`feed()` を再利用できます。作品フィールドを保持し、`workId` と不足する順位を補って詳細を開きます。販売ランキングは指定カテゴリを検索します。

ソースとカタログは `main` で管理します。`sources`、`reverse-search`、`metadata` は通常サイト、画像検索専用、作品情報専用プラグインを配信します。ランキングと作品情報は `metadata` に統合され、独立ランキングチャネルは廃止されました。各ブランチは固定コミット URL と SHA-256 の索引のみ保持します。アプリは3チャネルを個別に読み込み、不一致と重複 key を拒否し、更新前に確認します。タグ翻訳は `tag-translations` です。

```powershell
node tools/publish_sources.mjs --commit '<SHA>' --channel metadata --output '<本地输出文件>'
```

## コメントとコンテンツリンク

`comments` を実装すると `capabilities.comments` が自動的に公開されます。`resolveContentLink` と `searchLink` も同名の能力を公開します。検証済みの読み取りだけを宣言してください。コメントや返信の投稿、評価、通報操作は含みません。

公式コメント実装には Reddit、myfans、Fansly、GalgameX、XVideos、Pornhub Shorties、PicACG、SpankBang、X / Twitter、Telegram が含まれます。閲覧範囲は元サイトの権限に従います。X / Twitter と Telegram はログインが必要で、Telegram はディスカッションが有効な投稿に対応します。直接表示できない添付には正確な元コメントへのリンクを残します。

```js
// WorkItem / WorkDetail / SubscriptionPost: { ..., commentsAvailable?: boolean }
comments(workId, {page = 1, cursor = null, parentId = null, sort = 'default', context = {}})
// context: {url?, episodeId?, board?}
// result: {items, hasNext, page?, cursor?, total?, reset?, sorts?: [{value, label}]}
// item: {id, author: {name, avatar?, url?, badges?: []}, body,
//        date?, likes?, rating?, spoiler?, parentId?, replyCount?,
//        repliesAvailable?, replies?: [item]}
// body: [{type: 'text' | 'link' | 'image' | 'quote', text?, url?}]
resolveContentLink(url) // null | {type: 'work', id} | {type: 'search', url} | {type: 'external', url}
searchLink(url, request) // WorkPage
```

- `WorkItem`、`WorkDetail`、`SubscriptionPost` の任意のトップレベルフィールド `commentsAvailable?: boolean` は、その作品でコメントが有効かを示します。厳密な真偽値 `false` はコメント入口を非表示にし、`true` でもソースの `capabilities.comments` が必要です。省略または真偽値以外は不明として、ソースの能力に従って表示します。件数 0 はコメントの無効化を意味しません。読み取り時に元投稿のコメントが無効だと判明した場合は、空の一覧で隠さず `UNSUPPORTED` を送出します。
- `workId` はソース内の作品識別子です。`context` は元のページ、エピソード、ランキングの情報を保持します。コメントを作品とエピソードごとに分離してください。
- `id` は安定した空でない文字列です。`author.name` は空でも構いませんが、名前を作らないでください。本文には空でないテキストまたは有効な画像が必要です。画像だけのコメントも保持します。`date` は原サイトの表示または ISO 時刻、`likes` と `replyCount` は非負数、`rating` は 0–5、`spoiler` はネタバレの印です。
- `replies` は同じ構造を使い、`parentId` は親を示します。親本文に子返信を混ぜないでください。`replyCount` は原サイトの返信数です。`parentId` による読み取りを検証した場合のみ `repliesAvailable: true` を設定します。既定値は false で、件数だけでは追加読み込みを許可しません。 サイトが件数を提供しない場合、`replyCount: 0` と `repliesAvailable: true` は併存できます。件数を捏造したり、読み込み済み件数で入口を無効化したりせず、「返信を表示」を提供します。入れ子の返信を読む際、リクエストの `parentId` には選択したコメントの `id` を渡します。
- `hasNext` はサイトの応答に基づきます。カーソルに認証情報を含めず、次回はそのまま渡します。ID の重複、総数への到達、終了通知で停止し、未検証のページ送りは false にします。`sorts` は検証済みの並び順だけを返し、`label` は UI の翻訳キーです。
- ページングのスナップショットが変わった場合は `reset: true`、再取得した実際の `page`（通常 1）、新しいカーソルを返し、既存一覧を置き換えます。最初のページを後続ページとして返さないでください。業務エラー、ログイン要求、解析エラーを空一覧で隠さず、対応するエラーを送出します。

`Park.comments.html(html, baseUrl)` はテキスト、改行、リンク、画像、引用を安全な断片へ変換し、実行可能な内容を除去します。`Park.comments.text(text)` は平文中の明示的な HTTP(S) URL をリンクに分離します。`Park.comments.url(value, baseUrl)` は有効な HTTP(S) URL、または null を返します。画像、プロフィール、本文の URL に userinfo を含めてはいけません。フレームワークは構造化データを描画し、原サイトの HTML を実行しません。サイト固有の解析はプラグインで行い、通信は `this.http` を使います。

`resolveContentLink` は正確なホスト、検証済みのパスとパラメーターを識別し、対象外は null を返します。作品は `type: 'work'`、原サイト検索は `type: 'search'`、その他の安全なページは `type: 'external'` を使えます。プロフィール、コメントのアンカー、日付、投稿番号、再生時刻を作品と誤認しないでください。`searchLink` は完全な元 URL を受け取り、検索語、フィルター、分類、ページングを保持して既存の WorkPage を返します。検索語だけを取り出して他の条件を捨てたり、書き込み用エンドポイントへアクセスしたりしないでください。未認識リンクには元ページを開く手段を残します。

## 読み取り専用のライブチャット

`capabilities.liveChat` は `liveChat(id)` と `liveChatEvent(state, event)` の両方を実装した場合のみ宣言します。公式対応は CAM4、XLoveCam、Stripchat、SOOP です。`chat.domains` はホストとポートの独立した許可リストで、ページ・画像・メディアの権限を継承しません。`host` は 443 のみを許可します。非標準ポートは `host:port` で明示し、1024–65535 の範囲に限定します。`*.host:port` は指定ポートの一階層のサブドメインだけに一致し、元のホスト、多階層のサブドメイン、他のポートには一致しません。HTTPS/SSE と WSS のみを許可し、平文通信、ユーザー情報、フラグメントは禁止します。ゲスト初期化の一時トークンを別のホストやポートへリダイレクトしてはいけません。

`liveChat` は `transport: "sse" | "websocket"`、`url`、任意の `headers`、`state` を返します。ゲスト初期化には `this.chatHttp.request({url, method, headers, body|json})` を使用し、現在の呼び出しとキャンセルを共有します。Cookie はソースごとに分離し、トークン、接続 URL、状態、メッセージはメモリ内だけに保持します。

- `protocols`：WebSocket 専用。重複のない空でない RFC token 文字列を最大 8 個、各 128 文字以内で指定します。
- `binary: true`：WebSocket 専用。UTF-8 バイナリフレームで送受信しますが、プラグインの `event.data` と `send` は文字列のままです。各フレームは最大 65536 バイトで、UTF-8 を厳密に検証します。既定はテキストフレームです。
- `heartbeatIntervalMs`：任意の 10000–60000 の整数。接続成功後、この間隔で `{type: "tick"}` を同じ直列イベントキューに送ります。停止やページ離脱時に解除します。tick は接続ハンドシェイクや SSE 受信のタイムアウトを延長しません。

接続の確立とプロトコルハンドシェイクには、合計で固定の 25 秒の期限があります。`heartbeatIntervalMs` を宣言しない WebSocket は 30 秒間隔のネイティブ ping/pong を使用します。宣言した場合は代わりにプラグインの tick で接続を維持し、実際の転送エラーや切断イベントで切断を判断します。どちらもチャット文がないだけでは切断と判断せず、ローカルの tick もサーバーの生存証明にはなりません。SSE のサーバーデータ受信タイムアウトは引き続き 90 秒です。

`liveChatEvent` は `{type: "open"}` または `{type: "message", data, event?}` または `{type: "tick"}` を受け取り、SSE のイベント名を保持します。新しい `state` と任意の `connected`、`error`、`messages`、`send` を返します。メッセージは安定した `id`、プレーンテキストの `text`、任意の `author`、`isHistory` を持ちます。履歴は重複排除にのみ使用します。`send` は検証済みの認証・購読・ハートビート応答専用で、ユーザー投稿 API は提供しません。

ホストはフレーム、キュー、キャッシュ、再試行回数を制限します。再接続では新しいゲストトークンを取得し、失敗時には再試行を表示します。無効化、画面遷移、バックグラウンド移行、アプリロック、プレーヤー破棄時には即座にキャンセルし、古い結果を拒否します。作品コメント、履歴ページング、録画の時間軸コメントは含みません。

```js
chat: {domains: ["chat.example.com"]},
async liveChat(id) {
  return {transport: "websocket", url: "wss://chat.example.com/room", state: {}};
},
liveChatEvent(state, event) {
  return {state, connected: true, messages: [
    {id: "message-id", text: "message", author: "author", isHistory: false}
  ], send: []};
}
```

## 作品情報とマグネットリンク

- `metadataOnly: true`: 情報専用プラグインは `metadataSearch` と `metadataDetail` が必須で、`metadataMagnets`、通常の `feeds`・`search` とフィルターも宣言できます。結果は情報詳細のみを開き、横断メディア検索・再生・お気に入り・ダウンロードには入りません。通常の `detail` や再生機能は宣言しません。サイト解析はプラグイン内に置きます。 `rankings` も宣言できます。市場ランキングは `section: 'market'` を指定します。
- `metadataSearch(keyword, context?)` は最大100件の `{id, code, title, url, cover?}` を返します。`code` は実際の品番を使い、タイトルから推測しません。該当なしは `[]`、認証・解析失敗は例外です。複数候補は利用者が選びます。 省略可能な `context.category` は現在のカテゴリです。複数カテゴリの市場プラグインは検索範囲を限定し、返す ID に元サイトのチャンネル識別を保持します。ランキングプラグインも実装できます。
- `metadataDetail(id, context?)` は候補の必須項目と任意の `description`、`releaseDate`、`duration`、`director`、`studio`、`publisher`、`series`、`rating`、`actors: string[]`、`tags: string[]`、`images: (string | {url: string, thumbnail?: string})[]` を返します。不明な文字列と配列は空にし、情報を捏造しません。作品 URL は宣言ドメイン内、画像は資格情報・ポートなしの公開 HTTPS に限定します。 `metadataDetail(id, context?)` は任意のランキング情報 `{url, board}` を受け取ります。独立ランキングも自サイトの作品 ID から実際の情報を返せます。URL のドメインと ID との対応を検証し、外部 URL を信用しないでください。著者は任意の `authors: string[]` です。 `description` はプレーンテキストを推奨します。ランタイムは HTML から安全にテキストを抽出し、`br` とブロックの改行を保持し、スクリプトとフォームを無視します。
- 元サイトの用途に合わせ、`images` は URL 文字列または `{url, thumbnail?}` を受け取ります。`url` は拡大表示用、`thumbnail` は一覧のサムネイルです。別サイズがない場合は同じ URL を使用します。大画像 URL で重複を除き、対応するサムネイルを保持します（最大100件）。両方に同じ HTTPS 検証を適用します。一覧と詳細の表紙も元サイトに合わせ、ファイル名の推測や会員制限の回避は行いません。画像オブジェクトにはアプリ 0.11.0 以降が必要です。
- `metadataMagnets(id)` は最大500件の `{url, name, size?, date?, tags?: string[]}` を返します。有効な `magnet:?xt=urn:btih:...` のみ許可し、ハッシュで重複排除します。情報と磁力リンクは個別に読み込み・再試行し、切替や閉じる操作で旧要求を中止します。コピーと外部起動は利用者操作時のみ、JAV 検索には実際の品番を使います。

`browseLayout: 'list'` または `'grid'` はサイト内、カテゴリ、絞り込み結果、検索の表示を指定します。小説はテキスト一覧、記事と投稿は専用の表示、音声フォルダは元の階層を維持します。ホームと分野ページは常にカードを使い、表紙がない場合は内容別のアイコンを表示します。


フォームの action、隠しフィールド、ページ送り、リダイレクトはサイトから取得し、固定のパス・フィールド・パラメータ一覧で制限しません。ネイティブ媒体ヘッダーは `requestHeaders: {'x-cdn-auth': {scope: 'playback-origin'}}` とし、拡張子によらず現在の再生元と同一オリジンの許可済みリソースだけに送ります。

## 酒場

酒場ソースは `type: 'tavern', category: 'tavern'` を宣言し、一覧項目に `mediaKind: 'tavern'` と `tavernKind: 'character' | 'lorebook'` を設定します。`tavernAsset(id)` の実装で能力が自動公開されます。完全な JSON は `{kind, format: 'json', data}`、標準カード情報を含む PNG は `{kind: 'character', format: 'png', url}` を返します。URL と全リダイレクトは宣言ドメイン内の認証情報を含まない公開 HTTPS に限り、上限は 12 MiB です。表紙のみの画像や外部スクリプトを使わないでください。
