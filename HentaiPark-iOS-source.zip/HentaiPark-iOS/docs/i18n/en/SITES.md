[简体中文](../../SITES.md) · [繁體中文](../zh-Hant/SITES.md) · [English](SITES.md) · [日本語](../ja/SITES.md) · [한국어](../ko/SITES.md) · [Español](../es/SITES.md) · [Русский](../ru/SITES.md) · [العربية](../ar/SITES.md)

# Supported sites and services

[Back to project home](README.md)

> **18+** Adults only, where permitted by local law. Content comes from third-party sites; HentaiPark does not host it.

Reading, playback, comments, subscriptions and downloads vary by site. Check what the app offers for each site. Site updates may require an app upgrade.

Update checks ask before removing withdrawn official plugins, their settings, login sessions and stored files. Downloaded content is retained, and personal plugins are unaffected.

## Supported sites

| Category | Sites / services |
| --- | --- |
| Voice and ASMR | Hentai ASMR · ASMRHoney · Literotica Audio · ASMR Gay · ASMR Moon · EroASMR · JASMR |
| Gossip | MRDS · Heiliao · 51CG |
| Photo galleries | PixiBB · XiuRen · PornPics · CosplayTele · NudeCosplay |
| Illustrations | Danbooru · yande.re · Gelbooru |
| Doujinshi / comics | E-Hentai · 禁漫天堂 · nhentai · 绅士漫画 · 哔咔漫画 |
| Hentai anime | Hanime1 · Hanime.tv · Rule34Video · Iwara · HentaiHaven |
| JAV | MissAV · JableTV · 123AV · SupJav |
| Adult videos | Pornhub · XVideos · xHamster · 91porn · SpankBang · Eporner · Thumbzilla · iXXX · TubeSafari · 肉视频 |
| Short videos | Tik.porn · Fyptt · SOOP 短视频 · Pornhub Shorties · SWAG 短视频 · PopkonTV 短视频 · RedGifs · Fansly |
| AI dramas | 黄豆短剧 · 91短剧 · 黄果短剧 · 肉视频短剧 |
| Recordings | KoreanBJ.club 录播 · SOOP 录播 · PopkonTV 录播 · CamwhoresBay 亚洲录播 |
| Live streams | Stripchat 亚洲直播 · CAM4 · SOOP · XloveCam · SinParty |
| Creator communities | Pixiv · Reddit · X / Twitter · myfans.jp · pixivFANBOX · Telegram |
| Novels | Cool18 · Book18 · Canovel · 69story · Literotica · Lush Stories · StoriesOnline |
| Tavern | Chub AI · Character Tavern · RisuRealm |
| Game resources | KUN Galgame · GalgameX · 次元茶馆 |
| Online games | itch.io · Gamcore |

Folder-based audio uses work cards in browsing and search, with a headphone icon when no cover is available. Open a folder to browse its hierarchy. Joined playback loads audio and subtitles when you select a track; a combined timeline appears once all track durations are known. Brief buffering may occur between tracks.

ASMRHoney supports video collections, nested collections, and image attachments. Online games reuse unchanged large resources and still require a network connection to check versions; some games unpack or initialize on every launch.

On mobile, game resources open in a dialog with links, extraction codes and archive passwords when available. Copy individual fields or everything to download on a computer; direct links also offer an explicit download option on the current device.

Audio supports downloading a whole work, a folder or a file with associated subtitles. Short videos, subscription posts and articles can save text and images, audio or video accessible from the source. Open saved content offline from Downloads; missing files are reported without fetching them online. Preview-only content remains a preview. HLS with separate audio and video saves both tracks and exports as a ZIP; keep all files together. For unfinished video tasks, choose another source in Downloads while keeping completed episodes.

## Rankings

| Category | Sites / services |
| --- | --- |
| Market rankings | FANZA、MGStage、FC2、天然むすめ、パコパコママ、Caribbeancom、一本道、DLsite、Toranoana |
| Site rankings | E-Hentai、JM、nhentai、WNACG、Hanime1、MissAV、JableTV、SupJav、JavMenu |

## Reverse image search

| Category | Sites / services |
| --- | --- |
| Reverse image search | Google Lens · Yandex · Baidu · trace.moe · AnimeTrace · IQDB · E-Hentai · AVScan |

The selected image is uploaded to a search service only after you start the search. Results are candidates and need to be checked.

## Work information and magnets

| Service | Capabilities |
| --- | --- |
| JavBus · JavDB | Work information, preview images, magnets |

Use Search work information on a category page to access its market-ranking providers and additional sites such as JavBus and JavDB. Market information providers offer search, filters and details in the app. Studio works retain their site identity; public catalog searches may be slower. Ranking details prefer the original provider by default, with an option to select another provider. Search can use all sites, the category preference or one site. JAV details offer code copying and copying or opening magnets. Choose detail and search providers in the ranking settings at the top right, separately from content filters. FC2 may require login for search and details.

Only information supplied by the provider is shown; images and magnets may be unavailable. Magnets require a compatible external app; this app does not download torrent content. JavBus may require a VPN or proxy and regional age verification inside the app.

Switch between JavBus and JavDB on the information page; ratings appear when supplied by the provider.

## Tavern conversations

Browse Chub AI, Character Tavern and RisuRealm, or separately import PNG/JSON character cards, JSON lorebooks and conversation files exported by this app from Saved and conversations. Character Tavern supports sorting, included or excluded tags, token length, lorebook and original-content filters. RisuRealm uses only its public search pages and documented guest download API; it publishes no separate NSFW filter, so original adult markers are preserved.

After configuring an OpenAI-compatible AI service, choose a greeting, set a name and persona for the conversation, and attach lorebooks. Edit messages, delete a message and those after it, branch from a message, regenerate and switch reply variants, or continue the last reply. Markdown text is supported; scripts and automatic image loading are disabled. Conversation exports include character resources, lorebooks, persona and messages, but no API key. These files are unencrypted; keep them safe.

Incognito prevents changes to both new and existing conversations from being saved. Once enabled for an open conversation, disabling it does not backfill private messages. Explicit imports, exports and resource saves still write data. Messages, character settings, persona and matched lore are sent to your selected AI service and may incur charges. Context includes input and output; history is trimmed using a conservative estimate. Output-limit warnings let you adjust settings and retry or continue.

Lorebooks support keywords, constant entries, case and whole-word matching, secondary-key logic, probability, scan depth, recursion, budget, priority and insertion before or after character settings. Regex keys, groups, cooldown, delay, sticky rules and other insertion positions are unsupported and trigger a warning when detected; original data is retained. Complex SillyTavern extension cards may behave differently.

In normal mode, conversations and input drafts save automatically and can be resumed from history or the character card. Rollback keeps the selected message and removes later ones; branching preserves the original in a separate conversation. AI settings include a custom system prompt that defaults to the interface language. Defaults are 65,536 context tokens and 4,096 output tokens; saved limits stay unchanged. Abrupt termination may lose the most recent unsaved content.
