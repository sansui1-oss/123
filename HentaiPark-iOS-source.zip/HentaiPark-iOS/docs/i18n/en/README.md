[简体中文](../../../README.md) · [繁體中文](../zh-Hant/README.md) · [日本語](../ja/README.md) · [한국어](../ko/README.md) · [English](README.md) · [Español](../es/README.md) · [Русский](../ru/README.md) · [العربية](../ar/README.md)

<p align="center"><img src="../../images/banner.svg" alt="HentaiPark · 18+" width="100%"></p>

<p align="center"><strong>An adult content client. Discover, read, watch and collect in one place.</strong></p>

<p align="center">Browse doujinshi, hentai anime, JAV, photo galleries, videos, novels and games, then pick up where you left off.</p>

<p align="center">
  <a href="https://github.com/drdon1234/Hentai-Park/releases/latest"><img src="https://img.shields.io/github/v/release/drdon1234/Hentai-Park?label=Download&amp;color=C96442" alt="Download"></a>
  <img src="https://img.shields.io/badge/18%2B-Adult_content-C96442" alt="18+">
  <img src="https://img.shields.io/badge/Android_7.0%2B-333333" alt="Android 7.0+">
</p>

<p align="center"><a href="https://github.com/drdon1234/Hentai-Park/releases/latest">Download</a> · <a href="#screenshots">Product demo</a> · <a href="#features">Features</a> · <a href="#faq">FAQ</a> · <a href="https://github.com/drdon1234/Hentai-Park/issues">Feedback</a></p>

> **18+** Adults only, where permitted by local law. Content comes from third-party sites; HentaiPark does not host it.

## Download and platforms

**[Download](https://github.com/drdon1234/Hentai-Park/releases/latest)**

**Android 7.0+**

[Platforms and installation](../../PLATFORMS.md)

You can also [self-host Web (Beta)](../../WEB_DEPLOYMENT.md) for desktop and mobile browsers. Web is still in beta and its experience is being improved. Each instance is for one user; remote access requires HTTPS and an access credential. Web and Android keep separate data, with no cross-platform sync or backup import between them.

<a id="screenshots"></a>

## Product demo

https://github.com/user-attachments/assets/d648927a-e4d6-48e8-b8c0-b77349ffd607

## Get started

1. In Discover, choose a category and browse sites, or search by work, tag, link or video code.
2. Open a work to read or watch. Add it to Favorites, or download it for offline use.
3. Resume from Home → Continue → All, and check new chapters in Favorites → Updates.

Configure sign-in under More → Sites and proxies under More → Network when needed.

<a id="features"></a>

## Features

| Feature | What you get |
| --- | --- |
| Discover and search | Filter by 2D, 3D and media type; search across sites, or jump to a work using a link or code. |
| Read and watch | Gossip articles and video; scrolling, paged and two-page comics; video episodes, speed and resume; novel bookmarks, notes and read-aloud. |
| Favorites and updates | Organize favorites, keep your progress, check new chapters and follow creators, channels or keywords. |
| Online games | Play browser games without installing packages, with fullscreen and optional virtual controls. |
| Offline and export | Download comics, videos, audio, novels, posts, article attachments and game resources; import and export CBZ, and export completed gallery chapters as PDF. |
| Rankings and image search | Browse doujinshi, anime and JAV rankings, or use an image to find candidate works. |
| Work information | Browse, search and filter work information, open original-site ranking details, and choose detail and search sites. |
| Site comments and live chat | Read comments, replies and images from supported sites, and show live chat in supported streams. |
| Translation and filters | Translate titles, chapter names, descriptions, tags, comments, text, text subtitles and live chat; current-language dictionaries take priority. Hide content by tag. |
| Privacy and backup | App lock, incognito browsing, blurred covers and screenshot blocking on supported platforms; back up favorites, progress, subscriptions and settings. |

## Supported sites and services

[View all sites, rankings and reverse image search services](SITES.md)

<a id="faq"></a>

## Limitations and FAQ

Tavern requires your own OpenAI-compatible AI service. Messages, character settings, user persona and matched lore are sent to that service and may incur charges. See [Sites and services](SITES.md) for supported lorebook rules and import/export. Saved resources and conversations enter unencrypted library backups; AI settings and keys are excluded.

Reading, playback, comments, subscriptions and downloads vary by site. Check what the app offers for each site. Site updates may require an app upgrade.

Image search sends images to the selected service; local image search history is unencrypted. Passwords and cookies are visible during manual sign-in, so take care when sharing your screen.

**A site will not open or content is unavailable?**

Check your connection, then sign in, confirm your age or complete site verification as prompted. Some regions may require a VPN or proxy; content and access are controlled by the original site. For supported birthday checks, the app uses the fixed date 1999-12-31 only after local adult confirmation; it does not read your real birthday.

**Can I send comments or live chat?**

Comments, replies and live chat are read-only. When a game resource site requires a reply to unlock a link, the reply is shown first and sent only after you confirm.

**How do I keep favorites and progress?**

Export or restore .parkbak under More → Backup. Restore merges data and excludes downloaded files. Site sign-in and confirmation state, including cookies, can be included optionally for use on another device. Expired or device-bound sessions may require verification again. Backups are unencrypted; store them securely. Online game saves are excluded from .parkbak. The separate in-game import/export covers localStorage only, not IndexedDB; exported files are unencrypted.

**How do I report an issue?**

Use Issues and include the app version, site and steps to reproduce. Redact accounts, cookies, tokens, backups and full signed URLs.

[Log guide](DIAGNOSTICS.md)

## Star History

<a href="https://www.star-history.com/#drdon1234/Hentai-Park&amp;Date">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/svg?repos=drdon1234/Hentai-Park&amp;type=Date&amp;theme=dark">
    <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/svg?repos=drdon1234/Hentai-Park&amp;type=Date">
    <img alt="Stars over time" src="https://api.star-history.com/svg?repos=drdon1234/Hentai-Park&amp;type=Date">
  </picture>
</a>

---

[AGPL-3.0 · License](../../../LICENSE) · [Third-party notices](../../licenses/README.md) · [Platforms](../../PLATFORMS.md)
