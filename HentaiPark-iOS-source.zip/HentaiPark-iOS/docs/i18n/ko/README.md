[简体中文](../../../README.md) · [繁體中文](../zh-Hant/README.md) · [日本語](../ja/README.md) · [한국어](README.md) · [English](../en/README.md) · [Español](../es/README.md) · [Русский](../ru/README.md) · [العربية](../ar/README.md)

<p align="center"><img src="../../images/banner.svg" alt="HentaiPark · 18+" width="100%"></p>

<p align="center"><strong>성인 콘텐츠를 한곳에서. 탐색, 감상, 독서와 즐겨찾기까지.</strong></p>

<p align="center">동인지, 성인 애니메이션, JAV, 화보, 영상, 소설과 게임을 둘러보고 보던 곳에서 이어 보세요.</p>

<p align="center">
  <a href="https://github.com/drdon1234/Hentai-Park/releases/latest"><img src="https://img.shields.io/github/v/release/drdon1234/Hentai-Park?label=Download&amp;color=C96442" alt="Download"></a>
  <img src="https://img.shields.io/badge/18%2B-Adult_content-C96442" alt="18+">
  <img src="https://img.shields.io/badge/Android_7.0%2B-333333" alt="Android 7.0+">
</p>

<p align="center"><a href="https://github.com/drdon1234/Hentai-Park/releases/latest">다운로드</a> · <a href="#screenshots">제품 소개</a> · <a href="#features">기능</a> · <a href="#faq">FAQ</a> · <a href="https://github.com/drdon1234/Hentai-Park/issues">문제 제보</a></p>

> **18+** 현지 법률이 허용하는 성인만 이용할 수 있습니다. 콘텐츠는 외부 사이트에서 제공하며 HentaiPark는 원본 콘텐츠를 호스팅하지 않습니다.

## 다운로드 및 플랫폼

**[다운로드](https://github.com/drdon1234/Hentai-Park/releases/latest)**

**Android 7.0+**

[플랫폼 및 설치 안내](../../PLATFORMS.md)

[Web 배포](../../WEB_DEPLOYMENT.md) · `drdon1234/hentai-park`

<a id="screenshots"></a>

## 제품 소개

https://github.com/user-attachments/assets/d648927a-e4d6-48e8-b8c0-b77349ffd607

## 시작하기

1. 「탐색」에서 분류와 사이트를 선택하거나 작품, 태그, 링크 또는 품번으로 검색하세요.
2. 작품을 열어 읽거나 재생하세요. 좋아하는 작품을 「즐겨찾기」에 추가하거나 오프라인으로 다운로드하세요.
3. 홈의 「이어 보기 → 전체」에서 이어 보고 「즐겨찾기 → 업데이트」에서 새 장을 확인하세요.

필요하면 「더 보기 → 사이트」에서 로그인하고 「더 보기 → 네트워크」에서 프록시를 설정하세요.

### Web 자체 호스팅 (Docker Compose)

데스크톱과 모바일 브라우저에서 사용하는 단일 사용자 인스턴스입니다. Docker 대상은 linux/amd64입니다. 코드를 푸시하고 Release platforms 워크플로가 성공한 후에 첫 이미지를 받을 수 있습니다. 게시 전에는 상세 문서의 로컬 빌드를 사용하세요.

```sh
git clone https://github.com/drdon1234/Hentai-Park.git
cd Hentai-Park
cp clients/web/.env.example clients/web/.env
```

템플릿을 복사한 후 `clients/web/.env`를 편집하여 `WEB_IMAGE=drdon1234/hentai-park:latest`, 무작위 `AUTH_TOKEN`(16자 이상), 실제 HTTPS `WEB_ALLOWED_ORIGIN`을 설정하세요.

```sh
docker compose -f clients/web/compose.yaml pull
docker compose -f clients/web/compose.yaml up -d --no-build
```

기본 바인딩은 `127.0.0.1:8787`입니다. HTTPS 리버스 프록시로 접속하고 `AUTH_TOKEN`으로 잠금을 해제합니다. 기본 사용자 이름은 없습니다. `park-data` 명명 볼륨에 `/data`가 저장되며 다운로드는 `/data/downloads`에 있습니다. 업데이트는 `pull`과 `up -d --no-build`, 중지는 `stop`을 사용하세요. 일반 중지에 `down -v`를 사용하지 마세요.

[상세 배포, 게시 전 로컬 빌드 및 디렉터리 권한](../../WEB_DEPLOYMENT.md)

<a id="features"></a>

## 주요 기능

| 기능 | 사용 경험 |
| --- | --- |
| 탐색과 검색 | 2D, 3D 및 미디어 유형 필터와 여러 사이트 검색. 링크나 품번으로 작품에 바로 이동합니다. |
| 읽기와 감상 | 이미지 기사와 영상, 만화 스크롤·페이지·양면 보기, 영상 회차·배속·이어 보기, 소설 책갈피·주석·읽어주기. |
| 즐겨찾기와 업데이트 | 그룹 정리, 진행 상황 저장, 새 장 확인과 작가·채널·키워드 구독. |
| 온라인 게임 | 설치 없이 웹 게임을 실행하고 전체 화면과 가상 키를 전환할 수 있습니다. |
| 오프라인과 내보내기 | 만화, 영상, 음성, 소설, 게시물·기사 첨부 파일, 게임 리소스 다운로드. CBZ 가져오기·내보내기와 완료한 화보 장의 PDF 내보내기. |
| 순위와 역검색 | 동인지, 성인 애니메이션, JAV 순위와 이미지로 작품 후보 찾기. |
| 작품 정보 | 작품 정보 탐색·검색·필터링, 순위 작품의 원본 사이트 상세 보기와 상세·검색 사이트 선택. |
| 원본 댓글과 채팅 | 지원 사이트의 댓글·답글·이미지를 읽고 지원 라이브 방송의 채팅을 표시합니다. |
| 번역과 필터 | 제목, 장 이름, 소개, 태그, 댓글, 본문, 텍스트 자막과 실시간 채팅 번역. 현재 언어 사전을 우선 사용하며 태그로 콘텐츠를 숨깁니다. |
| 개인정보와 백업 | 앱 잠금, 시크릿 탐색, 표지 흐림과 지원 플랫폼의 화면 캡처 차단. 즐겨찾기, 진행 상황, 구독과 설정 백업. |

## 지원 사이트 및 서비스

[전체 사이트, 순위 및 이미지 역검색 서비스 보기](SITES.md)

<a id="faq"></a>

## 제한 사항 및 FAQ

선술집에는 직접 설정한 OpenAI 호환 AI 서비스가 필요합니다. 메시지, 캐릭터 설정, 사용자 페르소나와 일치하는 세계관 내용이 서비스로 전송되며 비용이 발생할 수 있습니다. 지원 규칙과 가져오기·내보내기는 [사이트 및 서비스](SITES.md)를 확인하세요. 저장한 리소스와 대화는 암호화되지 않은 서재 백업에 포함되며 AI 설정과 키는 제외됩니다.

읽기, 재생, 댓글, 구독과 다운로드 지원은 사이트마다 다릅니다. 앱 내 표시를 확인하세요. 사이트 업데이트에 앱 업그레이드가 필요할 수 있습니다.

이미지 검색은 선택한 서비스에 이미지를 전송하며 기기 내 검색 기록은 암호화되지 않습니다. 수동 로그인 시 비밀번호와 Cookie가 표시되므로 화면 공유에 주의하세요.

**사이트나 콘텐츠가 열리지 않나요?**

네트워크를 확인하고 안내에 따라 로그인, 연령 확인 또는 사이트 인증을 완료하세요. 지역에 따라 VPN이나 프록시가 필요할 수 있으며 콘텐츠와 접근 권한은 원본 사이트에서 결정합니다. 지원되는 생일 확인은 기기에서 성인 확인을 마친 경우에만 고정 날짜 1999-12-31을 사용하며 실제 생일은 읽지 않습니다.

**댓글이나 채팅을 보낼 수 있나요?**

댓글, 답글, 라이브 채팅은 읽기 전용입니다. 게임 리소스 해제에 답글이 필요하면 내용을 먼저 보여 주고 확인 후에만 전송합니다.

**즐겨찾기와 진행 상황을 보관하려면?**

「더 보기 → 백업」에서 .parkbak을 내보내거나 복원하세요. 복원은 데이터를 병합하며 다운로드 파일은 포함하지 않습니다. Cookie 등 사이트 로그인·확인 상태는 선택적으로 포함하여 다른 기기에서도 사용할 수 있습니다. 만료되거나 기기에 연결된 세션은 다시 확인해야 할 수 있습니다. 백업은 암호화되지 않으므로 안전하게 보관하세요. 온라인 게임 저장은 .parkbak에 포함되지 않습니다. 게임 내 별도 가져오기·내보내기는 localStorage만 지원하며 IndexedDB는 포함하지 않고 파일은 암호화되지 않습니다.

**문제를 제보하려면?**

Issues에 앱 버전, 사이트와 재현 단계를 알려 주세요. 계정, Cookie, Token, 백업과 전체 서명 URL은 숨겨 주세요.

[로그 안내](DIAGNOSTICS.md)

---

[AGPL-3.0 · 라이선스](../../../LICENSE) · [제3자 고지](../../licenses/README.md) · [플랫폼](../../PLATFORMS.md)
